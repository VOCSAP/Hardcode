class ZCL_HARDCODE_SHM_ROOT definition
  public
  final
  create public
  shared memory enabled .

public section.

  interfaces IF_SHM_BUILD_INSTANCE .

  methods CONSTRUCTOR
    importing
      !IV_REPID type CLIKE .
  methods HARDCODE_GET
    importing
      !IV_VERSION_PRIMARY_ONLY type XSDBOOLEAN default ABAP_TRUE
    returning
      value(RT_HARDCODE) type ZCL_HARDCODE=>TT_HARDCODE .
protected section.
private section.

data mt_hardcode TYPE zcl_hardcode=>tt_hardcode.
data mv_repid TYPE ztec_t_hc_vers-repid.
ENDCLASS.



CLASS ZCL_HARDCODE_SHM_ROOT IMPLEMENTATION.


METHOD constructor.
*&---------------------------------------------------------------------*
*& Méthode         : CONSTRUCTOR                                       *
*& Classe          : ZCL_HARDCODE_SHM_ROOT                             *
*& Description     : Création Instance SHM sur Hardcode                *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation Attributs
  " -----------------------------------------------------------

  " Récupération de tous les Hardcodes
  me->mt_hardcode = zcl_hardcode=>_hardcode_get( iv_repid ).

  " Initialisation Attribut
  me->mv_repid = iv_repid.

ENDMETHOD.


METHOD hardcode_get.
*&---------------------------------------------------------------------*
*& Méthode         : IF_SHM_BUILD_INSTANCE~BUILD                       *
*& Classe          : ZCL_HARDCODE_SHM_ROOT                             *
*& Description     : Génération Version                                *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Retourne les Hardcodes
  " -----------------------------------------------------------

  " Retourne les Hardcodes
  rt_hardcode[] = me->mt_hardcode[].

  IF iv_version_primary_only EQ abap_true.
    " Uniquement Version Primaire
    ""  --> Suppression des Autres Versions
    DELETE rt_hardcode WHERE version_primary NE abap_true.

  ENDIF.

ENDMETHOD.


METHOD if_shm_build_instance~build.
*&---------------------------------------------------------------------*
*& Méthode         : IF_SHM_BUILD_INSTANCE~BUILD                       *
*& Classe          : ZCL_HARDCODE_SHM_ROOT                             *
*& Description     : Création Instance SHM                             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *


ENDMETHOD.
ENDCLASS.
