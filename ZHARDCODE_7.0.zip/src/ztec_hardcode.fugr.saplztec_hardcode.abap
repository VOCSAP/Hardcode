*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZTEC_HARDCODETOP.                 " Global Data
  INCLUDE LZTEC_HARDCODEUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZTEC_HARDCODEF...                 " Subroutines
* INCLUDE LZTEC_HARDCODEO...                 " PBO-Modules
* INCLUDE LZTEC_HARDCODEI...                 " PAI-Modules
* INCLUDE LZTEC_HARDCODEE...                 " Events
* INCLUDE LZTEC_HARDCODEP...                 " Local class implement.
* INCLUDE LZTEC_HARDCODET99.                 " ABAP Unit tests
