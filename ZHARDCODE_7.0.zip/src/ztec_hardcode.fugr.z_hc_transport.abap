FUNCTION z_hc_transport.

*"----------------------------------------------------------------------
*& Copyright © 13/01/2016, Olivier Véhier                              *
*&                                                                     *
*& Permission is hereby granted, free of charge, to any person         *
*& obtaining a copy of this software and associated documentation      *
*& files (the "Software"), to deal in the Software without restriction *
*& including without limitation the rights to use, copy, modify,       *
*& merge, publish, distribute, sublicense, and/or sell copies of the   *
*& Software, and to permit persons to whom the Software is furnished   *
*& to do so, subject to the following conditions:                      *
*&                                                                     *
*& The above copyright notice and this permission notice shall be      *
*& included in all copies or substantial portions of the Software.     *
*&                                                                     *
*& THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,     *
*& EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES     *
*& OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND            *
*& NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS *
*& BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN  *
*& ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN   *
*& CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE    *
*& SOFTWARE.                                                           *
*&                                                                     *
*& Except as contained in this notice, the name of Olivier Véhier      *
*& shall not be used in advertising or otherwise to promote the sale,  *
*& use or other dealings in this Software without prior written        *
*& authorization from Olivier Véhier.                                  *
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(IV_REPID) TYPE  REPID
*"     VALUE(IT_HC_VERSION) TYPE  ZTEC_T_HC_VERS_TT
*"     VALUE(IT_HC_PARAMETER) TYPE  ZTEC_T_HC_PARAM_TT
*"     VALUE(IT_HC_ATTRIBUTE) TYPE  ZTEC_T_HC_ATTR_TT
*"     VALUE(IT_HC_SOURCE_CODE) TYPE  ZTEC_T_HC_ATTRIBUTE_SOURCE
*"       OPTIONAL
*"     VALUE(IV_DIRECT_UPDATE) TYPE  XSDBOOLEAN OPTIONAL
*"  EXPORTING
*"     VALUE(ES_RETURN) TYPE  BAPIRET2
*"----------------------------------------------------------------------

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lr_ranges_value TYPE zcl_hardcode_maintain=>tt_attribute_range_value,
    lt_source_code  TYPE stringtab,
    lt_hc_attribute TYPE ztec_t_hc_attr_tt,
    lt_hc_parameter TYPE ztec_t_hc_param_tt.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_attribute_logical_key TYPE zcl_hardcode_maintain=>ts_attribute_logical_key.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_error_update           TYPE xsdboolean,
    lv_version_guid           TYPE zvtec_t_hc-version_guid,
    lv_parameter_guid         TYPE zvtec_t_hc-parameter_guid,
    lv_attribute_guid_regroup TYPE zvtec_t_hc-attribute_guid_regroup.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Pré-Traitement
  " -----------------------------------------------------------

  " Initialisation table locale
  lt_hc_attribute[] = it_hc_attribute[].
  lt_hc_parameter[] = it_hc_parameter[].

  " Tri pour Perf
  SORT lt_hc_parameter BY version_guid.
  SORT lt_hc_attribute BY parameter_guid attribute_guid_regroup attribute_guid.

  TRY.
      TRY.
          " -----------------------------------------------------------
          " Log MàJ
          " -----------------------------------------------------------

          " Trace MàJ utilisateur
          DATA(lo_runtime) = NEW zcl_runtime_and_memory_util( ).

          " Début Trace
          lo_runtime->start(
              iv_measure_id    = 'HARDCODE_UPDATE'          "#EC NOTEXT
              iv_measure_objid = CONV #( iv_repid )
              iv_measure_desc  = CONV #( |{ sy-uname }| )
          ).

          " Fin Trace
          lo_runtime->stop( 'HARDCODE_UPDATE' ).            "#EC NOTEXT
          lo_runtime->save_to_db( abap_true ).

        CATCH cx_root.
          " Erreur création Instance Trace

      ENDTRY.

      " -----------------------------------------------------------
      " Suppression des Hardcodes présents
      " -----------------------------------------------------------

      " Récupération Instance Hardcode MàJ
      DATA(lo_hardcode_maintain) = NEW zcl_hardcode_maintain( iv_repid ).

      " Suppression Hardcode
      lo_hardcode_maintain->version_del( ).

      " Sauvegarde la Suppression
      lo_hardcode_maintain->save_to_db( abap_true ).

      IF iv_direct_update EQ abap_false.
        " -----------------------------------------------------------
        " Intégration des Hardcodes
        " -----------------------------------------------------------

        LOOP AT it_hc_version ASSIGNING FIELD-SYMBOL(<lfs_s_version>).

          TRY.
              " Ajout de la Version
              lv_version_guid = lo_hardcode_maintain->version_add(
                iv_version_id = <lfs_s_version>-version_id
                iv_is_primary = <lfs_s_version>-version_primary
              ).

              " Récupération première itération des Paramètres de la Version
              READ TABLE lt_hc_parameter WITH KEY version_guid = <lfs_s_version>-version_guid
                                     TRANSPORTING NO FIELDS BINARY SEARCH.
              IF sy-subrc NE 0.
                " Aucune occurence
                ""  --> Passe à la Version suivante
                CONTINUE.

              ENDIF.

              " Parcours l'ensemble des Paramètres de la Versin
              LOOP AT lt_hc_parameter ASSIGNING FIELD-SYMBOL(<lfs_s_parameter>)
                                           FROM sy-tabix.

                IF <lfs_s_parameter>-version_guid NE <lfs_s_version>-version_guid.
                  " On a changé de Version
                  ""  --> Arrêt de la boucle
                  EXIT.

                ENDIF.

                " Ajout du Paramètre
                lv_parameter_guid = lo_hardcode_maintain->parameter_add(
                  iv_version_guid   = lv_version_guid
                  iv_parameter_name = <lfs_s_parameter>-parameter_name
                ).

                " Récupération première itération des Attributs du Paramètre
                READ TABLE lt_hc_attribute WITH KEY parameter_guid = <lfs_s_parameter>-parameter_guid
                                       TRANSPORTING NO FIELDS BINARY SEARCH.
                IF sy-subrc NE 0.
                  " Aucun Attribut
                  ""  --> Passe au Paramètre suivant
                  CONTINUE.

                ENDIF.

                " Parcours chaque Attribut du Paramètre
                LOOP AT lt_hc_attribute ASSIGNING FIELD-SYMBOL(<lfs_s_attribute>)
                                             FROM sy-tabix.

                  IF <lfs_s_attribute>-parameter_guid NE <lfs_s_parameter>-parameter_guid.
                    " On change de Paramètre
                    ""  --> Arrêt de la boucle
                    EXIT.

                  ENDIF.

                  IF <lfs_s_attribute>-attribute_guid_regroup EQ <lfs_s_attribute>-attribute_guid.
                    " Entrée principal de l'Attribut
                    ""  --> Initialisation Clef de l'Attribut
                    ls_attribute_logical_key-attribute_name = <lfs_s_attribute>-attribute_name.
                    ls_attribute_logical_key-attribute_key1 = <lfs_s_attribute>-attribute_key1.
                    ls_attribute_logical_key-attribute_key2 = <lfs_s_attribute>-attribute_key2.
                    ls_attribute_logical_key-attribute_key3 = <lfs_s_attribute>-attribute_key3.
                    ls_attribute_logical_key-attribute_key4 = <lfs_s_attribute>-attribute_key4.

                    ""  --> Recherche Code Source
                    READ TABLE it_hc_source_code WITH TABLE KEY attribute_guid_regroup = <lfs_s_attribute>-attribute_guid_regroup
                                                      ASSIGNING FIELD-SYMBOL(<lfs_s_source_code>).
                    IF sy-subrc EQ 0.
                      " Correspondance trouvée
                      ""  --> Initialisation table
                      lt_source_code[] = <lfs_s_source_code>-source_code[].

                    ENDIF.

                  ELSE.
                    " Entrée multiples
                    ""  --> Ajout valeur Range
                    APPEND VALUE #(
                      attribute_sign = <lfs_s_attribute>-attribute_sign
                      attribute_opti = <lfs_s_attribute>-attribute_opti
                      attribute_low  = <lfs_s_attribute>-attribute_low
                      attribute_high = <lfs_s_attribute>-attribute_high
                    ) TO lr_ranges_value.

                  ENDIF.

                  AT END OF attribute_guid_regroup.
                    " Dernier itération de l'Attribut
                    ""  --> Ajout de l'Attribut
                    lo_hardcode_maintain->attribute_add(
                      iv_parameter_guid        = lv_parameter_guid
                      is_attribute_logical_key = ls_attribute_logical_key
                      ir_ranges_value          = lr_ranges_value
                      it_source_code           = lt_source_code
                    ).

                    ""  --> Réinitialisation
                    CLEAR   : ls_attribute_logical_key.
                    REFRESH : lr_ranges_value, lt_source_code.

                  ENDAT.

                ENDLOOP.

              ENDLOOP.      "Fin Boucle Paramètre

            CATCH zcx_hardcode_maintain.
              " Erreur ajout HC
              ""  --> Initialisation témoin en erreur
              lv_error_update = abap_true.

          ENDTRY.

        ENDLOOP.            "Fin Boucle Version

        IF lv_error_update EQ abap_false.
          " Ajout correct
          ""  --> MàJ DB
          lo_hardcode_maintain->save_to_db( abap_true ).

        ENDIF.

      ENDIF.

      IF lv_error_update  EQ abap_true
      OR iv_direct_update EQ abap_true.
        " -----------------------------------------------------------
        " MàJ Direct
        " -----------------------------------------------------------

        " MàJ Version
        MODIFY ztec_t_hc_vers FROM TABLE it_hc_version.

        " MàJ Attributs
        MODIFY ztec_t_hc_attr FROM TABLE it_hc_attribute.

        " MàJ Paramètres
        MODIFY ztec_t_hc_param FROM TABLE it_hc_parameter.

        " Mise à jour
        COMMIT WORK.

      ENDIF.

      " -----------------------------------------------------------
      " SHM - Rechargement
      " -----------------------------------------------------------

      " Récupération instance SHM
      DATA(lo_hc_shm) = zcl_hardcode_shm=>get_instance( iv_repid ).
      IF lo_hc_shm IS BOUND.
        " Modification dans toutes les Instances
        lo_hc_shm->hardcode_reload( ).

      ENDIF.

    CATCH zcx_hardcode_maintain INTO DATA(lo_cx_hardcode_maintain).
      " Une erreur est survenue
      ""  --> Retourne le Message d'Erreur
      WHILE lo_cx_hardcode_maintain->previous IS BOUND.
        lo_cx_hardcode_maintain ?= lo_cx_hardcode_maintain->previous.
      ENDWHILE.
      es_return-id         = lo_cx_hardcode_maintain->if_t100_message~t100key-msgid.
      es_return-number     = lo_cx_hardcode_maintain->if_t100_message~t100key-msgno.
      es_return-message_v1 = lo_cx_hardcode_maintain->if_t100_message~t100key-attr1.
      es_return-message_v2 = lo_cx_hardcode_maintain->if_t100_message~t100key-attr2.
      es_return-message_v3 = lo_cx_hardcode_maintain->if_t100_message~t100key-attr3.
      es_return-message_v4 = lo_cx_hardcode_maintain->if_t100_message~t100key-attr4.

    CATCH cx_root.
      " Une erreur est survenue
      RETURN.

  ENDTRY.

ENDFUNCTION.
