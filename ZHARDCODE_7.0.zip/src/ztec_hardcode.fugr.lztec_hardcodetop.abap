FUNCTION-POOL ZTEC_HARDCODE.                "MESSAGE-ID ..

* INCLUDE LZTEC_HARDCODED...                 " Local class definition
