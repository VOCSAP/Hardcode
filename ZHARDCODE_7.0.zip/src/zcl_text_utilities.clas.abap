class ZCL_TEXT_UTILITIES definition
  public
  final
  create public .

public section.

  class-methods TEXT_EXIST
    importing
      !IV_SEARCH type CLIKE
      !IV_STRING type CLIKE
      !IV_LENGTH type I
    returning
      value(RV_EXIST) type XSDBOOLEAN .
  class-methods TEXT_SPLIT_FOR_MESSAGE
    importing
      !IV_TEXT type STRING
    returning
      value(RS_RETURN) type EDIMESSAGE .
protected section.
private section.
ENDCLASS.



CLASS ZCL_TEXT_UTILITIES IMPLEMENTATION.


METHOD text_exist.
*&---------------------------------------------------------------------*
*& Méthode         : TEXT_EXIST                                        *
*& Classe          : ZCL_TEXT_UTILITIES                                *
*& Description     : Texte - Recherche de texte                        *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 06/12/2021                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF iv_string IS INITIAL.
    " Chaîne vide
    ""  --> Valeur recherchée non trouvée // Arrêt du traitement
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Recherche
  " -----------------------------------------------------------

  " Chaine existe ?
  IF iv_length GT 0.
    rv_exist = xsdbool( find( val = iv_string sub = iv_search len = iv_length ) GE 0 ).

  ELSE.
    rv_exist = xsdbool( find( val = iv_string sub = iv_search ) GE 0 ).

  ENDIF.

ENDMETHOD.


METHOD text_split_for_message.
*&---------------------------------------------------------------------*
*& Méthode         : TEXT_SPLIT_FOR_MESSAGE                            *
*& Classe          : ZCL_TEXT_UTILITIES                                *
*& Description     : Texte - Découpe message                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 06/12/2021                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_text      TYPE string,
    lv_length    TYPE int4,
    lv_iteration TYPE numc1.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
                 <lfs_field> TYPE any.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Découpe Texte dans Variable Message (50 caractères)
  " -----------------------------------------------------------

  " Initialisation texte
  lv_text = iv_text.

  IF strlen( lv_text ) LE 50.
    " Taille < 50 carac.
    ""  --> Texte tiens dans une seule variable
    rs_return-msgv1 = lv_text.

  ELSE.
    " Taille > 50 carac.
    WHILE lv_iteration LT 4.

      " Incrémente le compteur
      ADD 1 TO lv_iteration.

      " Initialisation pointeur sur la Variable Message
      ASSIGN COMPONENT |MSGV{ lv_iteration }|               ##NOTEXT
          OF STRUCTURE rs_return TO <lfs_field>.
      IF sy-subrc NE 0.
        " Aucune correspondance
        ""  --> Arrêt de la boucle
        EXIT.

      ENDIF.

      " Initialisation du Texte
      <lfs_field> = lv_text.

      " Réduction du Texte
      lv_length = strlen( <lfs_field> ).
      lv_text = lv_text+lv_length.

    ENDWHILE.

  ENDIF.

ENDMETHOD.
ENDCLASS.
