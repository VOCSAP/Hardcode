class ZCL_HARDCODE_CLUSTER definition
  public
  final
  create private .

public section.

  class-methods SOURCE_CODE_ADD
    importing
      !IV_ATTRIBUTE_GUID_REGROUP type ZTEC_HC_ATTRIBUTE_GUID_REGROUP
      !IT_SOURCE_CODE type STRINGTAB
      !IV_COMPRESS_DATA type XSDBOOLEAN default ABAP_TRUE
      !IV_COMMIT type XSDBOOLEAN default ABAP_TRUE
    returning
      value(RV_ADDED) type XSDBOOLEAN .
  class-methods SOURCE_CODE_GET
    importing
      !IV_ATTRIBUTE_GUID_REGROUP type ZTEC_HC_ATTRIBUTE_GUID_REGROUP
    returning
      value(RT_SOURCE_CODE) type STRINGTAB .
  class-methods SOURCE_CODE_DEL
    importing
      !IV_ATTRIBUTE_GUID_REGROUP type ZTEC_HC_ATTRIBUTE_GUID_REGROUP
      !IV_COMMIT type XSDBOOLEAN optional .
protected section.
private section.
ENDCLASS.



CLASS ZCL_HARDCODE_CLUSTER IMPLEMENTATION.


METHOD source_code_add.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_ztec_t_hc_attr_c TYPE ztec_t_hc_attr_c.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_source_code     TYPE xstring,
    lv_source_code_zip TYPE xstring.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF iv_attribute_guid_regroup IS INITIAL.
    " Clef non valorisée
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Initialisation Attributs de Création / Modification
  " -----------------------------------------------------------

  " Réécupération Témoin de Création
  SELECT SINGLE created_at, created_by
    FROM ztec_t_hc_attr_c
   WHERE srtfd EQ @iv_attribute_guid_regroup
    INTO (@ls_ztec_t_hc_attr_c-created_at, @ls_ztec_t_hc_attr_c-created_by).
  IF sy-subrc NE 0.
    " Entrée non existante
    ""  --> Initialisation Témoin de Création
    ls_ztec_t_hc_attr_c-created_by = sy-uname.
    GET TIME STAMP FIELD ls_ztec_t_hc_attr_c-created_at.

  ENDIF.

  " -----------------------------------------------------------
  " Transformation en chaîne Binaire
  " -----------------------------------------------------------

  " Transformation en XSTRING
  CALL TRANSFORMATION id
               SOURCE data = it_source_code
           RESULT XML lv_source_code.

  IF iv_compress_data EQ abap_true.
    TRY.
        " -----------------------------------------------------------
        " Compression du Code Source
        " -----------------------------------------------------------

        " Création nouvelle instance
        DATA(lo_abap_zip) = NEW cl_abap_zip( ).
        lo_abap_zip->support_unicode_names = abap_true.

        " Ajout du Code Source
        lo_abap_zip->add(
            name    = zcl_b2b_invoice_cluster=>mc_zip_content_name
            content = lv_source_code
        ).

        " Compression
        lv_source_code_zip = lo_abap_zip->save( ).

        " Initialisation indiquant que les données sont compressées
        ls_ztec_t_hc_attr_c-is_compressed = abap_true.

      CATCH cx_root.
        " Une erreur est survenue
        ""  --> Utilisation de la version non compressées des données
        CLEAR : ls_ztec_t_hc_attr_c-is_compressed.
        lv_source_code_zip = lv_source_code.

    ENDTRY.

  ELSE.
    " Pas de compression
    lv_source_code_zip = lv_source_code.

  ENDIF.

  IF NOT lv_source_code_zip IS INITIAL.
    " -----------------------------------------------------------
    " Charge le Code Source dans le Cluster
    " -----------------------------------------------------------

    " Initialisation données
    ls_ztec_t_hc_attr_c-mandt     = sy-mandt.
    ls_ztec_t_hc_attr_c-srtfd     = iv_attribute_guid_regroup.
    ls_ztec_t_hc_attr_c-data_size = xstrlen( lv_source_code_zip ).

    TRY.
        " Export du Code Source
        EXPORT code_source = lv_source_code_zip
            TO DATABASE ztec_t_hc_attr_c(td)
                   FROM ls_ztec_t_hc_attr_c
                     ID ls_ztec_t_hc_attr_c-srtfd.

        " Retourne booléen
        rv_added = boolc( sy-subrc EQ 0 ).

        IF iv_commit EQ abap_true.
          " Commit
          COMMIT WORK.

        ENDIF.

      CATCH cx_root INTO DATA(lo_cx_exception).
        " Erreur ajout Cluster
        ""  --> Lève une exception
*        RAISE EXCEPTION TYPE zcx_hardcode_cluster
*          EXPORTING
*            previous = lo_cx_exception.

    ENDTRY.

  ENDIF.

ENDMETHOD.


METHOD source_code_del.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Suppression
  " -----------------------------------------------------------

  DELETE FROM ztec_t_hc_attr_c WHERE srtfd EQ iv_attribute_guid_regroup.

  IF iv_commit EQ abap_true.
    COMMIT WORK.

  ENDIF.

ENDMETHOD.


METHOD source_code_get.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_textid           TYPE scx_t100key,
    ls_ztec_t_hc_attr_c TYPE ztec_t_hc_attr_c.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        lo_cx_exception TYPE REF TO cx_root.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_source_code_xml TYPE xstring.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Charge le Code Source depuis le Cluster
      " -----------------------------------------------------------

      " Import du Code Source
      IMPORT code_source = lv_source_code_xml
        FROM DATABASE ztec_t_hc_attr_c(td)
                   TO ls_ztec_t_hc_attr_c
                   ID iv_attribute_guid_regroup.
      IF sy-subrc NE 0.
        " Le Code Source n'existe pas
        ""  --> Arrêt du traitement
        RETURN.

      ENDIF.

      IF ls_ztec_t_hc_attr_c-is_compressed EQ abap_true.
        " -----------------------------------------------------------
        " Décompression du Code Source
        " -----------------------------------------------------------

        " Création nouvelle instance
        DATA(lo_abap_zip) = NEW cl_abap_zip( ).
        lo_abap_zip->support_unicode_names = abap_true.

        " Chargement dossier compressée
        lo_abap_zip->load(
          EXPORTING
            zip             = lv_source_code_xml
          EXCEPTIONS
            zip_parse_error = 1
            OTHERS          = 2
        ).
        IF sy-subrc EQ 0.
          " Décompression
          lo_abap_zip->get(
            EXPORTING
              index                   = 1
            IMPORTING
              content                 = lv_source_code_xml
            EXCEPTIONS
              zip_index_error         = 1
              zip_decompression_error = 2
              OTHERS                  = 3
          ).

        ENDIF.
        IF sy-subrc NE 0.
          " Une erreur est survenue
          ""  --> Lève une exception
          ls_textid-msgid = sy-msgid.
          ls_textid-msgno = sy-msgno.
          ls_textid-attr1 = sy-msgv1. ls_textid-attr2 = sy-msgv2.
          ls_textid-attr1 = sy-msgv3. ls_textid-attr2 = sy-msgv3.
          RETURN.
*          RAISE EXCEPTION TYPE zcx_hardcode_cluster
*            EXPORTING
*              textid = ls_textid.

        ENDIF.

      ENDIF.

      " -----------------------------------------------------------
      " Désérialization du Code Source
      " -----------------------------------------------------------

      " Désérialization du Code Source
      CALL TRANSFORMATION id
               SOURCE XML lv_source_code_xml
                   RESULT data = rt_source_code.

    CATCH cx_root INTO lo_cx_exception.
      " Une erreur est survenue lors de la récupération du Code Source
      ""  --> Lève une Exception
*      RAISE EXCEPTION TYPE zcx_hardcode_cluster
*        EXPORTING
*          previous = lo_cx_exception.

  ENDTRY.

ENDMETHOD.
ENDCLASS.
