class ZCL_HARDCODE definition
  public
  final
  create private

  global friends ZCL_HARDCODE_SHM_ROOT .

public section.

  types:
    BEGIN OF ts_attribute_value,
        attribute_name TYPE ztec_t_hc_attr-attribute_name.
            INCLUDE TYPE ztec_s_hc_attribute_value.
    TYPES :
    END OF   ts_attribute_value .
  types:
    tt_attribute_value TYPE SORTED TABLE OF ts_attribute_value
                                      WITH UNIQUE KEY primary_key components attribute_name KEY1 KEY2 KEY3 KEY4 .
  types:
    BEGIN OF ts_hardcode.
        INCLUDE TYPE zvtec_t_hc.
        TYPES :
        t_source_code TYPE stringtab,
      END OF   ts_hardcode .
  types:
    tt_hardcode TYPE SORTED TABLE OF zcl_hardcode=>ts_hardcode
                      WITH NON-UNIQUE KEY primary_key COMPONENTS version_id
                                                                        parameter_name
                                                                        attribute_name
                                                                        attribute_key1
                                                                        attribute_key2
                                                                        attribute_key3
                                                                        attribute_key4
                             WITH NON-UNIQUE SORTED KEY second_key COMPONENTS attribute_guid_regroup
                                                                              attribute_guid .

  data MT_HARDCODE type TT_HARDCODE read-only .
  constants MC_MY_MSGID type SY-MSGID value 'ZHARDCODE' ##NO_TEXT.
  constants MC_VERSION_DEFAULT type ZTEC_T_HC_VERS-VERSION_ID value '00001' ##NO_TEXT.
  constants:
    BEGIN OF mc_transport,
      register_table TYPE string VALUE 'ZTEC_T_HC_TRANS' ##NO_TEXT,
       xpra_program TYPE string VALUE 'ZTEC_HARDCODE_XPRA_TRANSPORT' ##NO_TEXT,
    END OF mc_transport .

  class-methods HARDCODE_DISPLAY
    importing
      !IV_REPID type REPID .
  class-methods GET_INSTANCE
    importing
      !IV_REPID type SY-REPID
    returning
      value(RO_INSTANCE) type ref to ZCL_HARDCODE
    raising
      ZCX_HARDCODE .
  methods ATTRIBUTE_VALUE_GET
    importing
      !IV_VERSION_ID type ZTEC_HC_VERSION_ID optional
      !IV_PARAMETER_NAME type ANY
      !IV_ATTRIBUTE_NAME type ANY
      !IV_KEY1 type ANY optional
      !IV_KEY2 type ANY optional
      !IV_KEY3 type ANY optional
      !IV_KEY4 type ANY optional
    returning
      value(RS_VALUE) type ZTEC_S_HC_ATTRIBUTE_VALUE
    raising
      ZCX_HARDCODE .
  methods PARAMETER_VALUE_GET
    importing
      !IV_VERSION_ID type ZTEC_HC_VERSION_ID optional
      !IV_PARAMETER_NAME type ANY
    returning
      value(RT_VALUE) type TT_ATTRIBUTE_VALUE
    raising
      ZCX_HARDCODE .
  class-methods CODE_INJECTION .
protected section.
private section.

  types:
    BEGIN OF ty_hardcode_instance,
      repid    TYPE        sy-repid,
      instance TYPE REF TO zcl_hardcode,
    END OF   ty_hardcode_instance .
  types:
    ty_t_hardcode_instance TYPE SORTED TABLE OF ty_hardcode_instance
                  WITH UNIQUE KEY primary_key COMPONENTS repid .

  data MV_REPID type ZTEC_T_HC_VERS-REPID .
  data MV_VERSION_PRIMARY type ZTEC_HC_VERSION_ID .
  data MV_PRIMARY_VERSION_ONLY type FLAG .
  data MO_HARDCODE_SHM type ref to ZCL_HARDCODE_SHM .
  class-data MT_HARDCODE_INSTANCE type TY_T_HARDCODE_INSTANCE .

  methods CONSTRUCTOR
    importing
      value(IV_REPID) type ZTEC_HC_REPID
      value(IV_VERSION_PRIMARY_ONLY) type FLAG default ABAP_TRUE
    raising
      ZCX_HARDCODE .
  methods DATA_LOAD
    importing
      !IV_REPID type CLIKE
      !IV_LOAD_FROM_SHM type XSDBOOLEAN default ABAP_TRUE
      !IV_VERSION_PRIMARY_ONLY type XSDBOOLEAN
    raising
      ZCX_HARDCODE .
  class-methods __RAISE_EXCEPTION
    importing
      !IO_EXCEPTION type ref to CX_ROOT optional
      value(IV_MSGID) type SY-MSGID default ZCL_HARDCODE=>MC_MY_MSGID
      value(IV_MSGNO) type SY-MSGNO optional
      value(IV_MSGV1) type ANY optional
      value(IV_MSGV2) type ANY optional
      value(IV_MSGV3) type ANY optional
      value(IV_MSGV4) type ANY optional
    preferred parameter IO_EXCEPTION
    raising
      ZCX_HARDCODE .
  class-methods _HARDCODE_GET
    importing
      !IV_REPID type CLIKE
      !IV_VERSION_PRIMARY_ONLY type XSDBOOLEAN optional
    returning
      value(RT_HARDCODE) type ZCL_HARDCODE=>TT_HARDCODE .
  methods _VALIDITY_CHECK
    returning
      value(RV_VALID) type XSDBOOLEAN .
ENDCLASS.



CLASS ZCL_HARDCODE IMPLEMENTATION.


METHOD attribute_value_get.
*&---------------------------------------------------------------------*
*& Méthode         : ATTRIBUTE_VALUE_GET                               *
*& Classe          : ZCL_HARDCODE                                      *
*& Description     : Récupération Valeur de l'Attribut                 *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    lsr_range TYPE ztec_s_hc_attribute_range.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_version_id TYPE ztec_hc_version_id.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_s_harcode> TYPE zcl_hardcode=>ts_hardcode.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation variables
  " -----------------------------------------------------------

  IF  iv_version_id           IS  INITIAL
  AND mv_primary_version_only EQ abap_false.
    " Numéro de version manquant
    ""  --> Lève une exception
    IF 1 = 2. MESSAGE e401(zhardcode). ENDIF.
    me->__raise_exception( iv_msgno = 401 ).

  ELSEIF NOT iv_version_id       IS INITIAL
     AND mv_primary_version_only EQ abap_false.
    " Numéro de Version fournie et plusieurs Versions traitées
    ""  --> Utilisation de la Version fournie
    lv_version_id = iv_version_id.

  ELSE.
    " Autre cas
    ""  --> Utilisation de la version primaire
    lv_version_id = me->mv_version_primary.

  ENDIF.

  " -----------------------------------------------------------
  " Récupération des valeurs associées aux clefs
  " -----------------------------------------------------------

  IF iv_key4 IS SUPPLIED.
    " La quatrième clef est fournie
    ""  --> Recherche première itération correspondante
    READ TABLE me->mt_hardcode WITH TABLE KEY version_id     = lv_version_id
                                              parameter_name = iv_parameter_name
                                              attribute_name = iv_attribute_name
                                              attribute_key1 = iv_key1
                                              attribute_key2 = iv_key2
                                              attribute_key3 = iv_key3
                                              attribute_key4 = iv_key4
                                    ASSIGNING <lfs_s_harcode>.

  ELSEIF iv_key3 IS SUPPLIED.
    " La troisième est fournie
    ""  --> Recherche première itération correspondante
    READ TABLE me->mt_hardcode WITH KEY version_id     = lv_version_id
                                        parameter_name = iv_parameter_name
                                        attribute_name = iv_attribute_name
                                        attribute_key1 = iv_key1
                                        attribute_key2 = iv_key2
                                        attribute_key3 = iv_key3
                              ASSIGNING <lfs_s_harcode> BINARY SEARCH.

  ELSEIF iv_key2 IS SUPPLIED.
    " La deuxième clef est fournie
    ""  --> Recherche première itération correspondante
    READ TABLE me->mt_hardcode WITH KEY version_id     = lv_version_id
                                        parameter_name = iv_parameter_name
                                        attribute_name = iv_attribute_name
                                        attribute_key1 = iv_key1
                                        attribute_key2 = iv_key2
                              ASSIGNING <lfs_s_harcode> BINARY SEARCH.

  ELSEIF iv_key1 IS SUPPLIED.
    " La première clef est fournie
    ""  --> Recherche première itération correspondante
    READ TABLE me->mt_hardcode WITH KEY version_id     = lv_version_id
                                        parameter_name = iv_parameter_name
                                        attribute_name = iv_attribute_name
                                        attribute_key1 = iv_key1
                              ASSIGNING <lfs_s_harcode> BINARY SEARCH.

  ELSE.
    " Aucune Clef
    ""  --> Recherche première itération correspondante
    READ TABLE me->mt_hardcode WITH KEY version_id     = lv_version_id
                                        parameter_name = iv_parameter_name
                                        attribute_name = iv_attribute_name
                              ASSIGNING <lfs_s_harcode> BINARY SEARCH.

  ENDIF.

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF NOT <lfs_s_harcode> IS ASSIGNED.
    " Aucune valeur correspondante
    ""  --> Lève une Exception
    IF 1 = 2. MESSAGE e402(zhardcode). ENDIF.
    me->__raise_exception( iv_msgno = 402 ).

  ENDIF.

  " -----------------------------------------------------------
  " Traitement des données
  " -----------------------------------------------------------

  IF <lfs_s_harcode>-attribute_guid_regroup NE <lfs_s_harcode>-attribute_guid.
    " Remonte à l'entrée de référence
    READ TABLE me->mt_hardcode WITH KEY second_key COMPONENTS attribute_guid_regroup = <lfs_s_harcode>-attribute_guid_regroup
                                                              attribute_guid         = <lfs_s_harcode>-attribute_guid_regroup
                                                    ASSIGNING <lfs_s_harcode>.
    IF sy-subrc NE 0.
      " Inconsisténce dans la table des Hardcodes
      ""  --> Lève une Exception
      IF 1 = 2. MESSAGE e004(zhardcode). ENDIF.
      me->__raise_exception( iv_msgno = 004 ).

    ENDIF.

  ENDIF.

  " Initialisation des données de retour
  rs_value-key1        = <lfs_s_harcode>-attribute_key1.
  rs_value-key2        = <lfs_s_harcode>-attribute_key2.
  rs_value-key3        = <lfs_s_harcode>-attribute_key3.
  rs_value-key4        = <lfs_s_harcode>-attribute_key4.
  rs_value-source_code = <lfs_s_harcode>-t_source_code.

  IF <lfs_s_harcode>-attribute_as_range EQ abap_true.
    " Traitement particulier si Range présent
    READ TABLE me->mt_hardcode WITH KEY second_key COMPONENTS attribute_guid_regroup = <lfs_s_harcode>-attribute_guid_regroup
                                                 TRANSPORTING NO FIELDS.
    IF sy-subrc EQ 0.
      LOOP AT me->mt_hardcode ASSIGNING FIELD-SYMBOL(<lfs_s_harcode_2>)
                               USING KEY second_key
                                    FROM sy-tabix.

        CLEAR : lsr_range.

        IF <lfs_s_harcode_2>-attribute_guid_regroup NE <lfs_s_harcode>-attribute_guid_regroup.
          " On ne traite plus le même Attribut
          ""  --> Arrêt de la boucle
          EXIT.

        ENDIF.

        IF <lfs_s_harcode_2>-attribute_guid_regroup EQ <lfs_s_harcode_2>-attribute_guid.
          " Ligne de référence
          ""  --> Passe à l'itération suivante
          CONTINUE.

        ENDIF.

        " Ajout valeurs du Range
        lsr_range-low    = <lfs_s_harcode_2>-attribute_low.
        lsr_range-sign   = <lfs_s_harcode_2>-attribute_sign.
        lsr_range-high   = <lfs_s_harcode_2>-attribute_high.
        lsr_range-option = <lfs_s_harcode_2>-attribute_opti.

        " Ajout de l'entrée
        APPEND lsr_range TO rs_value-range.

      ENDLOOP.

    ENDIF.

  ENDIF.

ENDMETHOD.


METHOD code_injection.
*&---------------------------------------------------------------------*
*& Méthode         : CODE_INJECTION                                    *
*& Classe          : ZCL_HARDCODE                                      *
*& Description     : Injection Code Source                             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 29/08/2018                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Non implémentée
  " -----------------------------------------------------------
  "   Difficulté d'implémentation :
  "     - Il faut créer une couche d'encapsulation de l'appel
  "       pour gérer les valeurs d'Import / Export
  " -----------------------------------------------------------

**  zcl_dynamic_source_code=>execute( ).
*
*  DATA : lt_mara TYPE mara_tt.
*  TYPES :
*      BEGIN OF ts_dyn,
*        name TYPE string,
*        itab TYPE REF TO data,
*      END OF   ts_dyn.
*
*  TYPES : tt_dyn TYPE STANDARD TABLE OF ts_dyn
*          WITH NON-UNIQUE KEY primary_key COMPONENTS name.
*
*  DATa : lt_dyn TYPE tt_dyn.
*
*  SELECT * FROM mara INTO TABLE @lt_mara.
*  SELECT * FROM mara INTO TABLE @lt_dyn[ 1 ]-itab.
*
*

ENDMETHOD.


METHOD constructor.
*&---------------------------------------------------------------------*
*& Copyright © 13/01/2016, Olivier Véhier                              *
*&                                                                     *
*& Permission is hereby granted, free of charge, to any person         *
*& obtaining a copy of this software and associated documentation      *
*& files (the "Software"), to deal in the Software without restriction *
*& including without limitation the rights to use, copy, modify,       *
*& merge, publish, distribute, sublicense, and/or sell copies of the   *
*& Software, and to permit persons to whom the Software is furnished   *
*& to do so, subject to the following conditions:                      *
*&                                                                     *
*& The above copyright notice and this permission notice shall be      *
*& included in all copies or substantial portions of the Software.     *
*&                                                                     *
*& THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,     *
*& EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES     *
*& OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND            *
*& NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS *
*& BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN  *
*& ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN   *
*& CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE    *
*& SOFTWARE.                                                           *
*&                                                                     *
*& Except as contained in this notice, the name of Olivier Véhier      *
*& shall not be used in advertising or otherwise to promote the sale,  *
*& use or other dealings in this Software without prior written        *
*& authorization from Olivier Véhier.                                  *
*&---------------------------------------------------------------------*
*& Méthode         : CONSTRUCTOR                                       *
*& Classe          : ZCL_HARDCODE                                      *
*& Description     : Constructeur                                      *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_cx_exception TYPE REF TO cx_root.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Récupération des Hardcodes
      " -----------------------------------------------------------

      " Initialisation Attribut
      me->mv_repid = iv_repid.

      " Récupération des Hardcods
      me->data_load(
          iv_repid                = iv_repid
          iv_load_from_shm        = abap_true
          iv_version_primary_only = iv_version_primary_only
      ).

    CATCH zcx_hardcode INTO lo_cx_exception.
      " Une exception est survenue
      ""  --> Lève l'exception
      me->__raise_exception( lo_cx_exception ).

  ENDTRY.

ENDMETHOD.


METHOD data_load.
*&---------------------------------------------------------------------*
*& Méthode         : DATA_LOAD                                         *
*& Classe          : ZCL_HARDCODE                                      *
*& Description     : Chargement des données                            *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
        lv_load_from_db TYPE xsdboolean.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Chargement des données
  " -----------------------------------------------------------

  IF iv_load_from_shm EQ abap_true.
    " Charge depuis la SHM
    TRY.
        ""  --> Charge les Hardcodes depuis la SHM
        me->mo_hardcode_shm = zcl_hardcode_shm=>get_instance( iv_repid ).

        me->mt_hardcode = me->mo_hardcode_shm->hardcode_get(
          iv_version_primary_only
        ).

        ""  --> Libère le Token de Lecture
        me->mo_hardcode_shm->hardcode_finish( ).

      CATCH zcx_hardcode_shm.
        " Erreur chargement depuis la SHM
        ""  --> Initialisation Indicateur chargement depuis la DB
        lv_load_from_db = abap_true.

    ENDTRY.

  ELSE.
    " Charge depuis la DB
    ""  --> Initialisation Indicateur chargement depuis la DB
    lv_load_from_db = abap_true.

  ENDIF.

  IF lv_load_from_db EQ abap_true.
    " -----------------------------------------------------------
    " Charge les Hardcodes depuis la DB
    " -----------------------------------------------------------

    " Récupération Hardcode en DB
    me->mt_hardcode = zcl_hardcode=>_hardcode_get(
        iv_repid                = iv_repid
        iv_version_primary_only = iv_version_primary_only
    ).

  ENDIF.

  " -----------------------------------------------------------
  " Contrôle présence de données
  " -----------------------------------------------------------

  IF me->mt_hardcode[] IS INITIAL.
    " Aucune données
    ""  --> Lève une exception
    IF 1 = 2. MESSAGE e001(zhardcode). ENDIF.
    me->__raise_exception(
        iv_msgno = 001                                      "#EC NOTEXT
        iv_msgv1 = iv_repid
    ).

  ENDIF.

  " -----------------------------------------------------------
  " Détermination Version Primaire
  " -----------------------------------------------------------

  ""  --> Initialisation Indicateur chargement Version Primaire Uniquement
  me->mv_primary_version_only = iv_version_primary_only.

  ""  --> Détermination de la Version Primaire
  me->mv_version_primary = me->mt_hardcode[ version_primary = abap_true ]-version_id.

ENDMETHOD.


METHOD get_instance.
*&---------------------------------------------------------------------*
*& Méthode         : GET_INSTANCE                                      *
*& Classe          : ZCL_HARDCODE                                      *
*& Description     : Récupération Instance                             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_hardcode_instance TYPE ty_hardcode_instance.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        lo_cx_exception TYPE REF TO cx_root.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Récupération de l'instance correspondant au Programme
      " -----------------------------------------------------------

      ro_instance = zcl_hardcode=>mt_hardcode_instance[ repid = iv_repid ]-instance.

      IF ro_instance->_validity_check( ) NE abap_true.
        " Instance non valide (Obsolète)
        ""  --> Recharge les données Hardcodes
        CREATE OBJECT ro_instance
          EXPORTING
            iv_repid = iv_repid.

        ""  --> MàJ table Buffer
        zcl_hardcode=>mt_hardcode_instance[ repid = iv_repid ]-instance = ro_instance.

      ENDIF.

    CATCH cx_sy_itab_line_not_found.
      " Aucune instance trouvée pour ce Programme
      ""  --> Création nouvelle
      ls_hardcode_instance-repid = iv_repid.
      TRY.
          CREATE OBJECT ls_hardcode_instance-instance
            EXPORTING
              iv_repid = iv_repid.

        CATCH zcx_hardcode INTO lo_cx_exception.
          " Une erreur est survenue
          ""  --> Retourne l'exception
          zcl_hardcode=>__raise_exception( lo_cx_exception ).

      ENDTRY.

      ""  --> Ajout de l'entrée
      INSERT ls_hardcode_instance INTO TABLE zcl_hardcode=>mt_hardcode_instance.

      ""  --> Retourne l'Instance
      ro_instance = ls_hardcode_instance-instance.

  ENDTRY.

ENDMETHOD.


METHOD hardcode_display.
*&---------------------------------------------------------------------*
*& Méthode         : HARDCODE_DISPLAY                                  *
*& Classe          : ZCL_HARDCODE                                      *
*& Description     : Récupération Instance                             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Affichage des Hardcodes
  " -----------------------------------------------------------

  SUBMIT ztec_hardcode WITH p_repid = iv_repid
                       WITH p_ucomm = 'DISPLAY'  ##NO_TEXT
                        AND RETURN.

ENDMETHOD.


METHOD parameter_value_get.
*&---------------------------------------------------------------------*
*& Méthode         : PARAMETER_VALUE_GET                               *
*& Classe          : ZCL_HARDCODE                                      *
*& Description     : Récupération Valeurs du Paramètres                *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_value TYPE ts_attribute_value.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_version_id TYPE ztec_hc_version_id.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation variables
  " -----------------------------------------------------------

  IF  iv_version_id           IS  INITIAL
  AND mv_primary_version_only EQ abap_false.
    " Numéro de version manquant
    ""  --> Lève une exception
    IF 1 = 2. MESSAGE e401(zhardcode). ENDIF.
    me->__raise_exception( iv_msgno = 401 ).

  ELSEIF NOT iv_version_id       IS INITIAL
     AND mv_primary_version_only EQ abap_false.
    " Numéro de Version fournie et plusieurs Versions traité
    ""  --> Utilisation de la Version fournie
    lv_version_id = iv_version_id.

  ELSE.
    " Autre cas
    ""  --> Utilisation de la version primaire
    lv_version_id = me->mv_version_primary.

  ENDIF.

  " -----------------------------------------------------------
  " Récupération des valeurs
  " -----------------------------------------------------------

  " Récupération position première occurence du Paramètre
  READ TABLE me->mt_hardcode WITH KEY version_id     = lv_version_id
                                      parameter_name = iv_parameter_name
                            TRANSPORTING NO FIELDS BINARY SEARCH.
  IF sy-subrc NE 0.
    " Aucune correspondance
    ""  --> Lève une Exception
    IF 1 = 2. MESSAGE e402(zhardcode). ENDIF.
    me->__raise_exception( iv_msgno = 402 ).

  ENDIF.

  " Parcours l'ensemble des données correspondant au paramètre
  LOOP AT me->mt_hardcode ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode>)
                               FROM sy-tabix.

    CLEAR : ls_value.

    IF <lfs_s_hardcode>-version_id      NE lv_version_id
    OR <lfs_s_hardcode>-parameter_name NE iv_parameter_name.
      " On ne traite plus le même paramètre
      ""  --> Arrêt de la boucle
      EXIT.

    ENDIF.

    IF <lfs_s_hardcode>-attribute_guid_regroup NE <lfs_s_hardcode>-attribute_guid.
      " Il ne s'agit pas d'une ligne de référence
      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    " Recherche si entrée déjà existante
    READ TABLE rt_value WITH TABLE KEY attribute_name = <lfs_s_hardcode>-attribute_name
                                       key1           = <lfs_s_hardcode>-attribute_key1
                                       key2           = <lfs_s_hardcode>-attribute_key2
                                       key3           = <lfs_s_hardcode>-attribute_key3
                                       key4           = <lfs_s_hardcode>-attribute_key4
                          TRANSPORTING NO FIELDS.
    IF sy-subrc EQ 0.
      " Valeurs déjà récupérée
      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    " Initialisation des données
    ls_value-attribute_name = <lfs_s_hardcode>-attribute_name.

    TRY.
        " Récupération des données
        MOVE-CORRESPONDING me->attribute_value_get(
            iv_version_id         = <lfs_s_hardcode>-version_id
            iv_parameter_name     = <lfs_s_hardcode>-parameter_name
            iv_attribute_name     = <lfs_s_hardcode>-attribute_name
            iv_key1               = <lfs_s_hardcode>-attribute_key1
            iv_key2               = <lfs_s_hardcode>-attribute_key2
            iv_key3               = <lfs_s_hardcode>-attribute_key3
            iv_key4               = <lfs_s_hardcode>-attribute_key4
        ) TO ls_value.

      CATCH zcx_hardcode_maintain.
        " Erreur lors de la récupération
        ""  --> Passe à l'itération suivante
        CONTINUE.

    ENDTRY.

    " Ajout de l'entrée
    INSERT ls_value INTO TABLE rt_value.

  ENDLOOP.

ENDMETHOD.


METHOD _hardcode_get.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Récupération des Hardcodes
  " -----------------------------------------------------------

  IF iv_version_primary_only EQ abap_true.
    " Charge uniquement la version courante
    ""  --> Récupération des Hardcodes
    SELECT * FROM zvtec_t_hc
       INTO CORRESPONDING FIELDS OF TABLE rt_hardcode
            WHERE repid           EQ iv_repid
              AND version_primary EQ abap_true.

  ELSE.
    " Charge toutes les versions
    SELECT * FROM zvtec_t_hc
       INTO CORRESPONDING FIELDS OF TABLE rt_hardcode
            WHERE repid EQ iv_repid.

  ENDIF.

  IF sy-subrc NE 0.
    " Aucune données
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Récupératin Texte Source
  " -----------------------------------------------------------

  " Récupération Identifiant des Textes Sources
  SELECT srtfd FROM ztec_t_hc_attr_c
    FOR ALL ENTRIES IN @rt_hardcode
                 WHERE srtfd EQ @rt_hardcode-attribute_guid_regroup
            INTO TABLE @DATA(lt_strfd_source_code).
  IF sy-subrc EQ 0.
    " Au moins un Code Source
    ""  --> Récupération du Code Source
    LOOP AT lt_strfd_source_code ASSIGNING FIELD-SYMBOL(<lfs_s_strfd_source_code>).

      TRY.
          " Initialisation du Texte de l'Attribut
          rt_hardcode[
            attribute_guid_regroup = <lfs_s_strfd_source_code>-srtfd
            attribute_guid         = <lfs_s_strfd_source_code>-srtfd
          ]-t_source_code = zcl_hardcode_cluster=>source_code_get( <lfs_s_strfd_source_code>-srtfd ).

        CATCH cx_sy_itab_line_not_found cx_root.
      ENDTRY.

    ENDLOOP.

  ENDIF.

ENDMETHOD.


METHOD _validity_check.
*&---------------------------------------------------------------------*
*& Méthode         : _VALIDITY_CHECK                                   *
*& Classe          : ZCL_HARDCODE                                      *
*& Description     : Contrôle Validité                                 *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle Validité
  " -----------------------------------------------------------

  IF NOT me->mo_hardcode_shm IS BOUND.
    " Hardcode non chargé depuis la SHM
    ""  --> Hardcode Valide
    rv_valid = abap_true.
    RETURN.

  ENDIF.

  " Contrôle Validité de l'instance SHM
  rv_valid = me->mo_hardcode_shm->hardcode_validity_check( ).

ENDMETHOD.


METHOD __raise_exception.
*&---------------------------------------------------------------------*
*& Méthode         : __RAISE_EXCEPTION                                 *
*& Classe          : ZCL_HARDCODE                                      *
*& Description     : Usage Interne : Lève une Exception                *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_text_id TYPE scx_t100key.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Génération de l'Exception
  " -----------------------------------------------------------

  IF io_exception IS BOUND.
    " Lève l'exception
    RAISE EXCEPTION TYPE zcx_hardcode
      EXPORTING
        previous = io_exception.

  ELSE.
    " Initialisation structure
    ls_text_id-msgid = iv_msgid.
    ls_text_id-msgno = iv_msgno.
    ls_text_id-attr1 = iv_msgv1.
    ls_text_id-attr2 = iv_msgv2.
    ls_text_id-attr3 = iv_msgv3.
    ls_text_id-attr4 = iv_msgv4.

    " Lève l'exception
    RAISE EXCEPTION TYPE zcx_hardcode
      EXPORTING
        textid = ls_text_id.

  ENDIF.

ENDMETHOD.
ENDCLASS.
