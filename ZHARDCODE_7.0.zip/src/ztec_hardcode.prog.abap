*&---------------------------------------------------------------------*
*& Report  ZTEC_HARDCODE
*&---------------------------------------------------------------------*
*& Gestion Hardcode
*&---------------------------------------------------------------------*
*& Copyright © 13/01/2016, Olivier Véhier                              *
*&                                                                     *
*& Permission is hereby granted, free of charge, to any person         *
*& obtaining a copy of this software and associated documentation      *
*& files (the "Software"), to deal in the Software without restriction *
*& including without limitation the rights to use, copy, modify,       *
*& merge, publish, distribute, sublicense, and/or sell copies of the   *
*& Software, and to permit persons to whom the Software is furnished   *
*& to do so, subject to the following conditions:                      *
*&                                                                     *
*& The above copyright notice and this permission notice shall be      *
*& included in all copies or substantial portions of the Software.     *
*&                                                                     *
*& THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,     *
*& EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES     *
*& OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND            *
*& NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS *
*& BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN  *
*& ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN   *
*& CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE    *
*& SOFTWARE.                                                           *
*&                                                                     *
*& Except as contained in this notice, the name of Olivier Véhier      *
*& shall not be used in advertising or otherwise to promote the sale,  *
*& use or other dealings in this Software without prior written        *
*& authorization from Olivier Véhier.                                  *
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*& Créé le      : 13/01/2016                                           *
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*

***------------------------------------------------------------------***
**                             INCLUDE                                **
***------------------------------------------------------------------***

" Include déclaration des données / types
INCLUDE ztec_hardcode_top.

" Include déclaration écran de sélection
INCLUDE ztec_hardcode_sel.

" Include déclaration Classes définition
INCLUDE ztec_hardcode_c01.

" Include déclaration Classes implémentation
INCLUDE ztec_hardcode_c02.

" Include déclaration Routines
INCLUDE ztec_hardcode_f01.

***==================================================================***
**                          INITIALIZATION                            **
***==================================================================***
INITIALIZATION.
  " Création de l'instance principale
  go_main = lcl_main=>initialization( ).

***==================================================================***
**                       AT SELECTION-SCREEN                          **
***==================================================================***
AT SELECTION-SCREEN.
  " Action utilisateur
  go_main->at_selection_screen( ).

***==================================================================***
**                     AT SELECTION-SCREEN OUTPUT                     **
***==================================================================***
AT SELECTION-SCREEN OUTPUT.
  " Lors de l'affichage de l'écran
  go_main->at_selection_screen_output( ).
