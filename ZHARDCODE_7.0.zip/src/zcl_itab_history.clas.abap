class ZCL_ITAB_HISTORY definition
  public
  final
  create private .

public section.

  types:
    BEGIN OF ts_history_version,
        version TYPE mdmversion,
        t_data  TYPE REF TO data,
      END OF   ts_history_version .
  types:
    tt_history_version TYPE SORTED TABLE OF ts_history_version
                    WITH NON-UNIQUE KEY primary_key COMPONENTS version .
  types:
    BEGIN OF ts_history_public,
        BEGIN OF version_current,
          version_current TYPE ZCL_ITAB_HISTORY=>TS_HISTORY_VERSION-VERSION,
          t_data_current  TYPE REF TO data,
        END OF version_current,
        t_history TYPE zcl_itab_history=>tt_history_version,
      END OF   ts_history_public .

  data MS_HISTORY_PUBLIC type ZCL_ITAB_HISTORY=>TS_HISTORY_PUBLIC read-only .
  constants:
    BEGIN OF mc_history,
        version_origin_v0 TYPE zcl_itab_history=>ts_history_version-version VALUE 0,
        version_max       TYPE zcl_itab_history=>ts_history_version-version VALUE 999999999,
      END OF mc_history .

  class-methods FACTORY
    importing
      !IT_DATA type ref to DATA
      !IV_HISTORY_VERSION_MAX type NUMERIC optional
      !IV_STORE_ORIGINAL_AS_V0 type XSDBOOLEAN optional
    returning
      value(RO_INSTANCE) type ref to ZCL_ITAB_HISTORY .
  methods HISTORY_VERSION_CREATE
    returning
      value(RV_SUBRC) type SY-SUBRC .
  methods HISTORY_VERSION_GET
    importing
      !IV_VERSION type NUMERIC
    exporting
      !EV_SUBRC type SY-SUBRC
      !ET_DATA type ANY TABLE
    returning
      value(RT_DATA) type ref to DATA .
  methods HISTORY_VERSION_DELETE
    importing
      !IR_VERSION type UCON_VERSION_NR_RANGE .
protected section.
private section.

  types:
    BEGIN OF ts_history_private,
            version_max  TYPE ZCL_ITAB_HISTORY=>TS_HISTORY_VERSION-VERSION,
      t_data_input TYPE REF TO data,
    END OF   ts_history_private .

  data MS_HISTORY_PRIVATE type ZCL_ITAB_HISTORY=>TS_HISTORY_PRIVATE .

  methods CONSTRUCTOR
    importing
      !IT_DATA type ref to DATA
      !IV_HISTORY_VERSION_MAX type numeric optional .
  methods _HISTORY_SAVE
    importing
      !IV_VERSION type ZCL_ITAB_HISTORY=>TS_HISTORY_VERSION-VERSION optional
      !IV_VERSION_V0 type XSDBOOLEAN optional
    returning
      value(RV_SUBRC) type SY-SUBRC .
  methods _HISTORY_REDETERMINE_VERSION
    returning
      value(RV_VERSION_LAST) type ZCL_ITAB_HISTORY=>TS_HISTORY_VERSION-VERSION .
ENDCLASS.



CLASS ZCL_ITAB_HISTORY IMPLEMENTATION.


METHOD constructor.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation attribut
  " -----------------------------------------------------------

  " Initialisation Nb de Verison max.
  me->ms_history_private-version_max = iv_history_version_max.

  " Initialise référence sur les données
  me->ms_history_private-t_data_input = it_data.

ENDMETHOD.


METHOD factory.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_history_version_max TYPE zcl_itab_history=>ts_history_private-version_max.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF iv_history_version_max IS INITIAL.
    " Pas de Version transmises
    ""  --> Initialise numéro de Version max
    lv_history_version_max = 99999999.

  ELSE.
    " Version max. transmise
    "" --> Utilisation de l'entrée
    lv_history_version_max = iv_history_version_max.

  ENDIF.

  " -----------------------------------------------------------
  " Retourne instance
  " -----------------------------------------------------------

  " Création instance
  ro_instance = NEW #(
    it_data                = it_data
    iv_history_version_max = lv_history_version_max
  ).

  IF iv_store_original_as_v0 EQ abap_true.
    " Conserve la version d'origine sous la Version 0
    ro_instance->_history_save( iv_version_v0 = abap_true ).

  ENDIF.

ENDMETHOD.


METHOD history_version_create.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Création nouvelle version d'historique
  " -----------------------------------------------------------

  me->_history_save( ).

ENDMETHOD.


METHOD history_version_delete.

***------------------------------------------------------------------***
**                             RANGES                                 **
***------------------------------------------------------------------***
  DATA :
        lr_version TYPE ucon_version_nr_range.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Pré-Traitement
  " -----------------------------------------------------------

  " Copie local
  lr_version[] = ir_version[].

  IF line_exists( lr_version[ option = space ] ) OR line_exists( lr_version[ sign = space ] ).
    " Au moins une entrée sans Signe || Option
    ""  --> Force avec sélection par défaut
    LOOP AT ir_version ASSIGNING FIELD-SYMBOL(<lfs_s_version>).

      IF <lfs_s_version>-sign EQ space.
        " Inclusion / Exclusion vide
        ""  --> Force à Inclusion
        <lfs_s_version>-sign = if_trba_selection_c=>gc_sign_incl.

      ENDIF.

      IF <lfs_s_version>-option EQ space.
        " Option non renseigné
        ""  --> Force à égale
        <lfs_s_version>-option = if_trba_selection_c=>gc_option_eq.

      ENDIF.

    ENDLOOP.

  ENDIF.

  " -----------------------------------------------------------
  " Suppression des Versions demandées
  " -----------------------------------------------------------

  " Suppression des Versions (sauf la V0)
  DELETE me->ms_history_public-t_history WHERE version IN lr_version[] AND version NE zcl_itab_history=>mc_history-version_origin_v0.

  " -----------------------------------------------------------
  " Redétermine les numéros de Version
  " -----------------------------------------------------------

  " Rédetermine les numéros de Versions
  me->_history_redetermine_version( ).

ENDMETHOD.


METHOD history_version_get.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_t_data>        TYPE ANY TABLE,
    <lfs_t_data_output> TYPE ANY TABLE.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Retourne les données historisées
  " -----------------------------------------------------------

  " Récupération de la Version demandée
  READ TABLE me->ms_history_public-t_history WITH TABLE KEY version = iv_version
                                                  ASSIGNING FIELD-SYMBOL(<lfs_s_history>).
  IF sy-subrc NE 0.
    " Aucune correspondance
    ""  --> Arrêt du traitement
    ev_subrc = 4.
    RETURN.

  ENDIF.

  " Initialisation pointeur sur les données
  ASSIGN <lfs_s_history>-t_data->* TO <lfs_t_data>.
  IF sy-subrc EQ 0.
    " Création objet
    CREATE DATA rt_data LIKE <lfs_t_data>.

  ENDIF.
  IF sy-subrc EQ 0.
    " Initialisation pointeur sur données de sortie
    ASSIGN rt_data->* TO <lfs_t_data_output>.

  ENDIF.
  IF sy-subrc EQ 0.
    " Retourne les données
    <lfs_t_data_output> = <lfs_t_data>.

    IF et_data IS SUPPLIED.
      " Retourne les données sous forme "direct"
      et_data = CORRESPONDING #( <lfs_t_data_output> ).

    ENDIF.

  ENDIF.

ENDMETHOD.


METHOD _history_redetermine_version.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_version            TYPE zcl_itab_history=>ts_history_version-version,
    lv_has_origin_version TYPE xsdboolean.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
        <lfs_s_history_new> TYPE zcl_itab_history=>ts_history_version.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Rédetermine les numéros de Versions
  " -----------------------------------------------------------

  LOOP AT me->ms_history_public-t_history ASSIGNING FIELD-SYMBOL(<lfs_s_history>).

    IF <lfs_s_history>-version EQ zcl_itab_history=>mc_history-version_origin_v0.
      " Version d'Origine || Cohérence version
      ""  --> Version d'Origine
      lv_has_origin_version = abap_true.

      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    " Initialisation indice Version
    lv_version = SWITCH #( lv_has_origin_version
      WHEN abap_true THEN sy-tabix - 1
      ELSE sy-tabix
    ).

    IF <lfs_s_history>-version EQ lv_version.
      " Version d'Origine || Cohérence version
      ""  --> Initialisation FS pour détermination Version
      ASSIGN <lfs_s_history> TO <lfs_s_history_new>.

      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    " Ajout de la Version
    INSERT VALUE #(
      version = lv_version
      t_data  = <lfs_s_history>-t_data
    ) INTO TABLE me->ms_history_public-t_history ASSIGNING <lfs_s_history_new>.

    " Suppression de l'entrée
    DELETE me->ms_history_public-t_history USING KEY loop_key.

  ENDLOOP.

  " -----------------------------------------------------------
  " Rédetermine Version courrante
  " -----------------------------------------------------------

  IF <lfs_s_history_new> IS ASSIGNED.
    " Initialisation Version courante
    me->ms_history_public-version_current-t_data_current  = <lfs_s_history_new>-t_data.
    me->ms_history_public-version_current-version_current = <lfs_s_history_new>-version.

  ELSE.
    " Pas de Version
    ""  --> Réinitialisation données Version courrante
    CLEAR : me->ms_history_public-version_current-t_data_current.

  ENDIF.

ENDMETHOD.


METHOD _history_save.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_version TYPE zcl_itab_history=>ts_history_public-version_current-version_current.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_t_data>       TYPE ANY TABLE,
    <lfs_t_data_input> TYPE ANY TABLE.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Pré-Traitement
  " -----------------------------------------------------------

  IF iv_version_v0 EQ abap_true.
    " Version V0
    lv_version = zcl_itab_history=>mc_history-version_origin_v0.

  ELSEIF NOT iv_version IS INITIAL.
    " N° de Version transmis
    ""  --> Utilisation de ce N° de Version
    lv_version = iv_version.

  ELSE.
    " Pas de n° de Version
    ""  --> Utilisation du N° Version courrant
    lv_version = me->ms_history_public-version_current-version_current.

  ENDIF.

  " -----------------------------------------------------------
  " Création nouvelle version d'historique
  " -----------------------------------------------------------

  " Initialisation pointeur
  ASSIGN me->ms_history_private-t_data_input->* TO <lfs_t_data_input>.
  IF sy-subrc NE 0.
    " Erreur
    ""  --> Arrêt du traitement
    rv_subrc = 4.
    RETURN.

  ENDIF.

  IF iv_version IS INITIAL AND iv_version_v0 EQ abap_false.
    " Historisation sous numérotation automatique
    ""  --> Incrémentation de la Version
    ADD 1 TO lv_version.

  ENDIF.

  IF lv_version GT me->ms_history_private-version_max.
    " Version max. dépassée
    "" --> Suppression de la première Version
    DELETE me->ms_history_public-t_history WHERE version EQ 1.

    ""  --> Réorganisation
    me->_history_redetermine_version( ).

    ""  --> Ramène à la Version max.
    lv_version = me->ms_history_private-version_max.

  ENDIF.

  " Création entrée || Récupération entrée
  READ TABLE me->ms_history_public-t_history WITH TABLE KEY version = lv_version
                                                  ASSIGNING FIELD-SYMBOL(<lfs_s_history>).
  IF sy-subrc NE 0.
    " Entrée inexistante
    ""  --> Création nouvelle entrée
    INSERT VALUE #(
      version = lv_version
    ) INTO TABLE me->ms_history_public-t_history ASSIGNING <lfs_s_history>.

  ENDIF.

  " -----------------------------------------------------------
  " Historisation de la Version
  " -----------------------------------------------------------

  " Modifie le numéro de Version courant
  me->ms_history_public-version_current-version_current = lv_version.

  " Initialisation nouvelle instance pour stockage des données
  CREATE DATA <lfs_s_history>-t_data LIKE <lfs_t_data_input>.
  IF sy-subrc EQ 0.
    " Instance créé
    ""  --> Initialisation pointeur sur les données
    ASSIGN <lfs_s_history>-t_data->* TO <lfs_t_data>.

  ENDIF.
  IF sy-subrc EQ 0.
    " Pointeur initialisé
    ""  --> Modification des données
    <lfs_t_data> = <lfs_t_data_input>.

  ENDIF.
  IF sy-subrc NE 0.
    " Erreur
    ""  --> Arrêt du traitement
    rv_subrc = 8.
    RETURN.

  ENDIF.

  IF iv_version IS INITIAL AND iv_version_v0 EQ abap_false.
    ""  --> Identifie la version courante
    me->ms_history_public-version_current-t_data_current  = <lfs_s_history>-t_data.

  ENDIF.

ENDMETHOD.
ENDCLASS.
