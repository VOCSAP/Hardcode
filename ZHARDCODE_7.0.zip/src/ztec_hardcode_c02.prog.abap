*&---------------------------------------------------------------------*
*& Include         : ZTEC_HARDCODE_C02                                 *
*& Programme Cadre : ZTEC_HARDCODE                                     *
*&---------------------------------------------------------------------*
*& Gestion Hardcode                                                    *
*& Include Implémentation Classes                                      *
*&---------------------------------------------------------------------*
*& Créé le      : 13/01/2016                                           *
*&                                                                     *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*

*----------------------------------------------------------------------*
*       CLASS LCL_MAIN_TREE_TOOLBAR_EVENT IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main_tree_toolbar_event IMPLEMENTATION.

  METHOD factory.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Création de l'instance
    " -----------------------------------------------------------

    " Toolbar Principale
    CREATE OBJECT ro_instance
      EXPORTING
        io_toolbar = io_toolbar.

    " -----------------------------------------------------------
    " Souscription aux évènements
    " -----------------------------------------------------------

    " Handler  Aide à la recherche
    SET HANDLER ro_instance->handler_dropdown_clicked  FOR ro_instance->mo_toolbar.
    SET HANDLER ro_instance->handler_function_selected FOR ro_instance->mo_toolbar.

  ENDMETHOD.

  METHOD constructor.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation des attributs
    " -----------------------------------------------------------

    me->mo_toolbar = io_toolbar.

  ENDMETHOD.

  METHOD handler_function_selected.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Traitement suite à clique sur Toolbar
    " -----------------------------------------------------------

    " Suivant le code fonction
    CASE fcode.

      WHEN me->mc_function-copy.
        " Copier
        RAISE EVENT on_copy.

      WHEN me->mc_function-cancel.
        " Annulation
        RAISE EVENT on_cancel.

      WHEN me->mc_function-transport.
        " Transporter
        RAISE EVENT on_transport
          EXPORTING
            iv_advanced_mode = abap_false.

      WHEN me->mc_function-update_shm.
        " Mettre à Jour la SHM
        RAISE EVENT on_update_shm.

      WHEN me->mc_function-primary_set.
        " Passe la version en Primaire
        RAISE EVENT on_version_primary_set.

      WHEN me->mc_function-version_create.
        " Création d'une nouvelle version
        RAISE EVENT on_version_create.

      WHEN me->mc_function-parameter_create.
        " Paramètre - Création
        RAISE EVENT on_parameter_create.

      WHEN me->mc_function-attribute_create.
        " Attribut - Création
        RAISE EVENT on_attribute_create.

      WHEN me->mc_function-delete.
        " Suppression
        RAISE EVENT on_delete.

      WHEN me->mc_function-display.
        " Affichage
        RAISE EVENT on_display.

      WHEN me->mc_function-modify.
        " Paramètre - Edition
        RAISE EVENT on_modify.

      WHEN me->mc_function-import_local.
        " Impression
        RAISE EVENT on_import_local.

      WHEN me->mc_function-export_local.
        " Export
        RAISE EVENT on_export_local.

      WHEN OTHERS.
        " Autres

    ENDCASE.

  ENDMETHOD.

  METHOD handler_dropdown_clicked.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    " -----------------------------------------------------------
    " Sélection des données
    " -----------------------------------------------------------

    DATA : lo_ctmenu TYPE REF TO cl_ctmenu.

    " -----------------------------------------------------------
    " Génération Menu Transport
    " -----------------------------------------------------------

    " Création instance Menu
    CREATE OBJECT lo_ctmenu.

    " Transport - OT / Direct
    lo_ctmenu->add_function(
      EXPORTING
        fcode             = CONV #( lcl_main_tree_toolbar_event=>mc_function-transport )
        text              = CONV #( text-ttr )
        icon              = CONV #( text-tra )
    ).

    " Transport - Fichier - Export
    lo_ctmenu->add_function(
      EXPORTING
        fcode             = CONV #( lcl_main_tree_toolbar_event=>mc_function-export_local )
        text              = CONV #( text-exp )
        icon              = CONV #( text-iie )
    ).

    " Transport - Fichier - Import
    lo_ctmenu->add_function(
      EXPORTING
        fcode             = CONV #( lcl_main_tree_toolbar_event=>mc_function-import_local )
        text              = CONV #( text-imp )
        icon              = CONV #( text-iim )
    ).

    " -----------------------------------------------------------
    " Affichage du Menu
    " -----------------------------------------------------------

    " Affichage
    CALL METHOD me->mo_toolbar->track_context_menu
      EXPORTING
        context_menu = lo_ctmenu
        posx         = posx
        posy         = posy.

  ENDMETHOD.

ENDCLASS.


*----------------------------------------------------------------------*
*       CLASS LCL_MAIN_TREE_EVENT IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main_tree_event IMPLEMENTATION.

  METHOD factory.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_events TYPE cntl_simple_events.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_event TYPE cntl_simple_event.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Création de l'instance
    " -----------------------------------------------------------

    " Initialisation instance
    CREATE OBJECT ro_instance
      EXPORTING
        io_main      = io_main
        io_alv_tree  = io_alv_tree
        io_main_tree = io_main_tree.

    " -----------------------------------------------------------
    " Souscription aux évènements Externe
    " -----------------------------------------------------------

    " Handler Clique Boutton
    SET HANDLER ro_instance->handler_button_click FOR ro_instance->mo_alv_tree.

    " Handler  Aide à la recherche
    SET HANDLER ro_instance->handler_item_double_click FOR ro_instance->mo_alv_tree.

    " -----------------------------------------------------------
    " Initialisation table des évènements
    " -----------------------------------------------------------

    " Récupération des événements
    ro_instance->mo_alv_tree->get_registered_events(
      IMPORTING
        events     = lt_events
      EXCEPTIONS
        OTHERS     = 0
    ).

    " Evènement Clique Boutton
    ls_event-eventid = cl_gui_column_tree=>eventid_button_click.
    APPEND ls_event TO lt_events.

    " Evènement double clique
    ls_event-eventid = cl_gui_column_tree=>eventid_item_double_click.
    APPEND ls_event TO lt_events.

    " -----------------------------------------------------------
    " Souscription aux évènements Interne
    " -----------------------------------------------------------

    CALL METHOD ro_instance->mo_alv_tree->set_registered_events
      EXPORTING
        events = lt_events
      EXCEPTIONS
        OTHERS = 0.

  ENDMETHOD.

  METHOD constructor.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation des attributs
    " -----------------------------------------------------------

    me->mo_main         = io_main.
    me->mo_alv_tree     = io_alv_tree.
    me->mo_main_tree    = io_main_tree.

  ENDMETHOD.

  METHOD handler_button_click.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " A Implémenter
    " -----------------------------------------------------------


  ENDMETHOD.


  METHOD handler_item_double_click.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lor_range       TYPE REF TO zcl_hardcode_maintain=>tt_attribute_range_value_det,
      lot_source_code TYPE REF TO stringtab.

***------------------------------------------------------------------***
**                             RANGES                                 **
***------------------------------------------------------------------***
    DATA :
        lr_range TYPE tt_r_ranges.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
          ls_outtab_line TYPE lcl_main_tree=>ts_hc_data.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Gestion évènement double clique
    " -----------------------------------------------------------

    " Récupération de l'entrée correspondante
    me->mo_alv_tree->get_outtab_line(
      EXPORTING
        i_node_key     = node_key
      IMPORTING
        e_outtab_line  = ls_outtab_line
      EXCEPTIONS
        node_not_found = 1
        OTHERS         = 2
    ).
    IF sy-subrc NE 0.
      " Erreur récupération Noeud sélectionné
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Suivant la colonne sélectionnée
    CASE fieldname.

      WHEN cl_alv_tree_base=>c_hierarchy_column_name
        OR 'ATTRIBUTE_KEY1' OR 'ATTRIBUTE_KEY2' OR 'ATRIBUTE_KEY3' OR 'ATRIBUTE_KEY4'.
        " Hiérarchie ou Clef
        ""  --> Affiche édition du Noeud
        RAISE EVENT on_hierarchy_edit
          EXPORTING
            iv_node_key = node_key.

      WHEN 'ATTRIBUTE_AS_RANGE_ICON' ##NO_TEXT.
        " Range
        ""  --> Récupération Range
        me->mo_main_tree->attribute_detail_get_ref(
          EXPORTING
            iv_attribute_guid_regroup = ls_outtab_line-attribute_guid_regroup
          IMPORTING
            eot_range                 = lor_range
         ).

        IF lor_range IS BOUND.
          ""  --> Ouverture édition range
          LOOP AT lor_range->* ASSIGNING FIELD-SYMBOL(<lfs_s_range>).
            APPEND VALUE #( sign   = <lfs_s_range>-attribute_sign
                            option = <lfs_s_range>-attribute_opti
                            low    = <lfs_s_range>-attribute_low
                            high   = <lfs_s_range>-attribute_high
                           ) TO lr_range.
          ENDLOOP.
          lcl_main=>range_editor_open(
           EXPORTING
             iv_read_only = abap_true
           CHANGING
             cr_range     = lr_range
          ).

        ENDIF.

      WHEN 'ATTRIBUTE_AS_SOURCE_CODE_ICON' ##NO_TEXT.
        " Code Source
        ""  --> Récupération Code Source
        me->mo_main_tree->attribute_detail_get_ref(
          EXPORTING
            iv_attribute_guid_regroup = ls_outtab_line-attribute_guid_regroup
          IMPORTING
            eot_source_code           = lot_source_code
         ).

        ""  --> Ouverture Editeur
        lcl_main=>source_code_editor_open(
          EXPORTING
            iv_read_only   = abap_true
          CHANGING
            ct_source_code = lot_source_code->*
        ).

      WHEN OTHERS.
        " Autre colone
        ""  --> Ne rien faire
        RETURN.

    ENDCASE.

  ENDMETHOD.

ENDCLASS.


*----------------------------------------------------------------------*
*       CLASS LCL_MAIN IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main IMPLEMENTATION.

  METHOD initialization.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Création de l'instance
    " -----------------------------------------------------------

    CREATE OBJECT ro_instance
      EXPORTING
        iov_repid                    = REF #( p_repid )
        iov_load_work                = REF #( p_work )
        iov_value_or                 = REF #( p_orval )
        iov_parameter_or             = REF #( p_orparn )
        iov_attribute_or             = REF #( p_orattn )
        iov_value_high_or            = REF #( p_orhigh )
        ior_search_repid             = REF #( s_repid[] )
        ior_search_parameter_name    = REF #( s_pname[] )
        ior_search_attribute_name    = REF #( s_aname[] )
        ior_search_attribute_value_l = REF #( s_alow[] )
        ior_search_attribute_value_h = REF #( s_ahigh[] ).

    " -----------------------------------------------------------
    " Initialisation boutons
    " -----------------------------------------------------------
    SET PF-STATUS 'PF_STATUS_SEL'.                          ##NO_TEXT

  ENDMETHOD.

  METHOD is_changed.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Vérification si des données ont été modifiées
    " -----------------------------------------------------------

    rv_changed = me->mo_hardcode_maintain->is_changed( ).

  ENDMETHOD.

  METHOD constructor.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation des attributs
    " -----------------------------------------------------------

    " Ecran Principale - Initialisation critères de sélection
    me->ms_selection_criteria-main-ov_repid = iov_repid.
    me->ms_selection_criteria-ov_load_work  = iov_load_work.

    " Recherche - Initialisation critères de sélection
    me->ms_selection_criteria-search-or_repid                = ior_search_repid.
    me->ms_selection_criteria-search-or_parameter_name       = ior_search_parameter_name.
    me->ms_selection_criteria-search-or_attribute_name       = ior_search_attribute_name.
    me->ms_selection_criteria-search-or_attribute_value_low  = ior_search_attribute_value_l.
    me->ms_selection_criteria-search-or_attribute_value_high = ior_search_attribute_value_h.

    " Recherche - Initialisation options de recherche
    me->ms_selection_criteria-search-search_option-value_or      = iov_value_or.
    me->ms_selection_criteria-search-search_option-parameter_or  = iov_parameter_or.
    me->ms_selection_criteria-search-search_option-attribute_or  = iov_attribute_or.
    me->ms_selection_criteria-search-search_option-value_high_or = iov_value_high_or.

    " -----------------------------------------------------------
    " Soucris aux évènements
    " -----------------------------------------------------------

    SET HANDLER me->handler_on_display_aft_can FOR me.

  ENDMETHOD.

  METHOD process.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_hardcode TYPE zvtec_t_hc_tt.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF me->ms_selection_criteria-main-ov_repid->* IS INITIAL.
      " Identifiant obligatoire
      ""  --> Arrêt du traitement
      MESSAGE s012(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Création instance de Mise à Jour des Hardcodes
    " -----------------------------------------------------------

    CREATE OBJECT me->mo_hardcode_maintain
      EXPORTING
        iv_repid = me->ms_selection_criteria-main-ov_repid->*.

    " -----------------------------------------------------------
    " Récupération des données
    " -----------------------------------------------------------

    me->mo_hardcode_maintain->hardcode_data_get( IMPORTING et_join = lt_hardcode ).
    IF lt_hardcode[] IS INITIAL.
      " Aucune données
      TRY.
          ""  --> Création Version par défault
          me->mo_hardcode_maintain->version_add(
              iv_version_id = zcl_hardcode=>mc_version_default
              iv_is_primary = abap_true
          ).

          ""  --> Rechargement des données
          me->mo_hardcode_maintain->hardcode_data_get( IMPORTING et_join = lt_hardcode ).

        CATCH zcx_hardcode_maintain.
          " Erreur lors de l'ajout de la Version
          RETURN.

      ENDTRY.

    ENDIF.

    IF me->ms_process_instance-main_tree IS BOUND.
      " Libère les élèments à changer
      me->ms_process_instance-main_tree->free( ).

    ENDIF.

    " Initialisation instance
    CREATE OBJECT me->ms_process_instance-main_tree
      EXPORTING
        io_main           = me
        iv_repid          = me->ms_selection_criteria-main-ov_repid->*
        iv_container_name = 'CC_MAIN_TREE'. ##NO_TEXT

    " -----------------------------------------------------------
    " Traitement
    " -----------------------------------------------------------

    " Traitement
    me->ms_process_instance-main_tree->process(
      it_hardcode = lt_hardcode
      iv_event    = iv_event
      io_argument = io_argument
    ).

  ENDMETHOD.

  METHOD save.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_cx_hardcode_maintain TYPE REF TO zcx_hardcode_maintain.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    TRY.
        " -----------------------------------------------------------
        " Sauvegarde les données
        " -----------------------------------------------------------

        " Sauvegarde les données
        me->mo_hardcode_maintain->save_to_db( abap_true ).

        " Evènement données sauvegardées
        me->event_raise( lcl_main=>mc_event-save ).

        TRY.
            IF zcl_hardcode_shm=>hardcode_is_load( me->ms_selection_criteria-main-ov_repid->* ) EQ abap_true.
              " Hardcode présent dans la SHM
              ""  --> Pousse les modifications dans la SHM
              zcl_hardcode_shm=>get_instance( me->ms_selection_criteria-main-ov_repid->* )->hardcode_reload( ).

            ENDIF.

          CATCH zcx_hardcode_shm. ##NO_HANDLER
            " Une erreur est survenue // Tant pis ...

        ENDTRY.

        " Affiche message de succès
        MESSAGE s462(ab).

      CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
        " Une erreur est survenue
        ""  --> Affichage de l'erreur
        WHILE lo_cx_hardcode_maintain->previous IS BOUND.
          lo_cx_hardcode_maintain ?= lo_cx_hardcode_maintain->previous.
        ENDWHILE.
        MESSAGE ID lo_cx_hardcode_maintain->if_t100_message~t100key-msgid
              TYPE if_msg_output=>msgtype_success
            NUMBER lo_cx_hardcode_maintain->if_t100_message~t100key-msgno
              WITH lo_cx_hardcode_maintain->if_t100_message~t100key-attr1
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr2
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr3
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr4
           DISPLAY LIKE if_msg_output=>msgtype_error.

    ENDTRY.

  ENDMETHOD.

  METHOD call_popup_confirm_data_loss.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_answer TYPE c LENGTH 1.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " PopUp Confirmation perte de données
    " -----------------------------------------------------------

    " Affichage PopUp confirmation
    CALL FUNCTION 'POPUP_TO_CONFIRM_DATA_LOSS' ##NO_TEXT
      EXPORTING
        defaultoption = 'J' ##NO_TEXT
        titel         = text-dlo
        start_column  = 5
        start_row     = 6
      IMPORTING
        answer        = lv_answer.

    " Retourne booléen confirmation
    rv_confirmed = xsdbool( lv_answer EQ 'J' ).             ##NO_TEXT

  ENDMETHOD.

  METHOD call_popup_input_simple.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    CLEAR : ev_subrc, ev_cancel.

    IF iv_read_only EQ abap_true.
      " -----------------------------------------------------------
      " Affichage PopUp
      " -----------------------------------------------------------

      " Affichage
      CALL FUNCTION 'ISHMED_POPUP_TO_DISPLAY_TEXT'
        EXPORTING
          i_titel        = CONV string( iv_title )
          i_textline1    = CONV string( iv_text )
          i_start_column = 25 ##NO_TEXT
          i_start_row    = 6. ##NO_TEXT

    ELSE.
      " -----------------------------------------------------------
      " Affichage PopUp saisi
      " -----------------------------------------------------------

      " Edition
      CALL FUNCTION 'UR_CF_POPUP_TEXT_INPUT'
        EXPORTING
          i_title   = CONV string( iv_title )
          i_text    = CONV string( iv_text )
        IMPORTING
          e_text    = rv_input
        EXCEPTIONS
          cancelled = 1
          OTHERS    = 2.
      IF sy-subrc EQ 1.
        " Annulation
        rv_input  = iv_text.
        ev_cancel = abap_true.

      ELSEIF sy-subrc GT 1.
        " Une erreur est survenue
        ""  --> Retourne code erreur
        MESSAGE s397(0d) DISPLAY LIKE if_msg_output=>msgtype_warning.
        ev_subrc = 4.
        RETURN.

      ENDIF.

    ENDIF.

  ENDMETHOD.

  METHOD range_editor_open.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Edition Range
    " -----------------------------------------------------------

    " Ouverture Edition Range
    CALL FUNCTION 'COMPLEX_SELECTIONS_DIALOG'
      EXPORTING
        title             = text-csd
        lower_case        = abap_false
        no_interval_check = abap_true
        just_display      = iv_read_only
      TABLES
        range             = cr_range
      EXCEPTIONS
        cancelled         = 1
        OTHERS            = 2.
    IF sy-subrc NE 0.
      " Action interrompue
      ""  --> Arrêt du traitement
      rv_subrc = 4.
      RETURN.

    ENDIF.

  ENDMETHOD.

  METHOD source_code_editor_open.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    TRY.
        " -----------------------------------------------------------
        " Editeur de texte
        " -----------------------------------------------------------

        " Ouverture Editeur Code Source
        CALL FUNCTION 'ENH_SCPCONT_SOURCE_EDITOR'
          EXPORTING
            im_changemode = CONV abap_bool( boolc( iv_read_only EQ abap_false ) )
          CHANGING
            ch_text       = ct_source_code.

      CATCH cx_enh_canceled.  ##NO_HANDLER
        " Une erreur est survenue
        ""  --> Arrêt du traitement
        rv_subrc = 4.
        RETURN.

    ENDTRY.

  ENDMETHOD.

  METHOD value_help_system.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_fields     TYPE dfies_tab,
      lt_valuetab   TYPE char10_t,
      lt_return_tab TYPE hrreturn_tab.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Aide à la Recherche Système
    " -----------------------------------------------------------

    " Initialisation Valeur Disponible
    lt_valuetab = VALUE #(
      ( 'DE1' ##NO_TEXT  ) ( 'IE1' ##NO_TEXT  )                                     ##NO_TEXT
      ( 'RE1' ##NO_TEXT  ) ( 'PE1' ##NO_TEXT  )                                     ##NO_TEXT
    ).

    " Initialisation Champs
    lt_fields = VALUE #(
      (
        tabname    = 'ZTBDESTRFC' ##NO_TEXT                             ##NO_TEXT
        fieldname  = 'ZEDTARGSYS' ##NO_TEXT                              ##NO_TEXT
      )
    ).

    " Appel PopUp Sélection
    CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
      EXPORTING
        retfield        = 'ZEDTARGSYS' ##NO_TEXT
        window_title    = text-ssy
      TABLES
        value_tab       = lt_valuetab
        field_tab       = lt_fields
        return_tab      = lt_return_tab
      EXCEPTIONS
        parameter_error = 1
        no_values_found = 2
        OTHERS          = 3.
    IF sy-subrc NE 0 OR lt_return_tab[] IS INITIAL.
      " Erreur appel Aide à la Recherche
      ""  --> Arrêt du traitement
      CLEAR : rv_system.
      RETURN.

    ENDIF.

  ENDMETHOD.

  METHOD event_raise.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Lève évènement
    " -----------------------------------------------------------

    " Suivant l'évènement
    CASE iv_event.

      WHEN lcl_main=>mc_event-save.
        " Sauvegarde
        RAISE EVENT on_save.

      WHEN lcl_main=>mc_event-display_leave.
        " Sort de l'écran de visualisation
        RAISE EVENT on_display_leave.

      WHEN lcl_main=>mc_event-display_after_cancel.
        " Affichage après Annulation
        RAISE EVENT on_display_after_cancel.

      WHEN OTHERS.
        " Autre
        ""  --> Arrêt du traitement
        RETURN.

    ENDCASE.

  ENDMETHOD.

  METHOD event_register.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Enregistre l'évènement
    " -----------------------------------------------------------

    " Enregistre l'évènement
    me->ms_process_instance-v_registered_event = iv_event.

  ENDMETHOD.

  METHOD at_selection_screen.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_ucomm TYPE sy-ucomm.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Pré-Traitement
    " -----------------------------------------------------------

    IF NOT p_ucomm IS INITIAL.
      " Utilisation Action transmise
      lv_ucomm = p_ucomm.

    ELSE.
      " Utilisation Action utilisateur active
      lv_ucomm = sy-ucomm.

    ENDIF.

    " -----------------------------------------------------------
    " Suivant l'action utilisateur
    " -----------------------------------------------------------

    CASE lv_ucomm.

      WHEN lcl_main=>mc_event-back.
        " Retour
        LEAVE PROGRAM.

      WHEN lcl_main=>mc_event-leave.
        " Sort du Programme
        LEAVE PROGRAM.

      WHEN lcl_main=>mc_event-search.
        " Recherche
        IF ok_code NE lcl_main=>mc_event-dummy.
          me->programm_search( ).

        ENDIF.

      WHEN lcl_main=>mc_event-display.
        " Affichage
        me->programm_display( ).

      WHEN lcl_main=>mc_event-delete.
        " Suppression
        me->programm_deletion( ).

      WHEN lcl_main=>mc_event-copy.
        " Copier
        me->programm_copy( ).

      WHEN lcl_main=>mc_event-transport.
        " Transporter
        me->programm_transport( ).

      WHEN lcl_main=>mc_event-ushm.
        " Mettre à Jour la SHM
        me->programm_update_shm( ).

      WHEN lcl_main=>mc_event-impex.
        " Importer / Export Hardcode
        me->programm_impex_local( ).

      WHEN lcl_main=>mc_event-compare.
        " Comparer
        me->ms_process_instance-v_first_dispay = abap_false.
        me->program_compare( ).

      WHEN OTHERS.
        " Autres

    ENDCASE.

  ENDMETHOD.

  METHOD at_selection_screen_output.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    WHILE NOT me->ms_process_instance-v_registered_event IS INITIAL.
      " -----------------------------------------------------------
      " Gestion des évènements enregistré
      " -----------------------------------------------------------
      " Astuce de développement :
      "   Dans le cas de l'annulation des modifications
      " on relance l'affichage via la méthode principale.
      " Sauf que, cela engendre le traitement à partir d'ici
      " donc; quand on exécute une deuxième fois l'annulation,
      " on se retrouve à poursuivre après l'instruction
      " "RAISE EVENT". De fait, on initialise une boucle
      " sur "V_REGISTER_EVENT" afin de relancer l'affichage
      " si l'utilisateur annule de nouveaux les modifications
      " -----------------------------------------------------------

      " Suivant l'évènement enregistrée
      CASE me->ms_process_instance-v_registered_event.

        WHEN lcl_main=>mc_event-display.
          " Affichage
          me->event_raise( lcl_main=>mc_event-display_after_cancel ).

        WHEN OTHERS.
          " Autre
          ""  --> Réinitialisation
          CLEAR : me->ms_process_instance-v_registered_event.

      ENDCASE.

    ENDWHILE.

    IF sy-dynnr EQ 2100.
      " -----------------------------------------------------------
      " Recherche - Modification Ecran de sélection
      " -----------------------------------------------------------

      LOOP AT SCREEN INTO DATA(ls_screen).

        CASE ls_screen-group1.

          WHEN 'ORP'. ##NO_TEXT
            " Coche "OR" Paramètre
            ""  --> Modifie la possibilité de cocher
            ls_screen-input = SWITCH #( xsdbool(
                 NOT me->ms_selection_criteria-search-or_repid->*[]          IS INITIAL
                 AND (
                         NOT me->ms_selection_criteria-search-or_parameter_name->*[] IS INITIAL
                      OR NOT me->ms_selection_criteria-search-or_attribute_name->*[] IS INITIAL
                      )
                 )
                 WHEN abap_true THEN 1 ELSE 0
            ).

          WHEN 'ORA'. ##NO_TEXT
            " Coche "OR" Attribut
            ""  --> Modifie la possibilité de cocher
            ls_screen-input = SWITCH #( xsdbool(
                    NOT me->ms_selection_criteria-search-or_attribute_name->*[] IS INITIAL
                AND NOT me->ms_selection_criteria-search-or_parameter_name->*[] IS INITIAL )
                 WHEN abap_true THEN 1 ELSE 0
            ).

          WHEN 'ORV'. ##NO_TEXT
            " Coche "OR" Valeur
            ""  --> Modifie la possibilité de cocher
            ls_screen-input = SWITCH #( xsdbool(
              (
                   NOT me->ms_selection_criteria-search-or_repid->*[]          IS INITIAL
                OR NOT me->ms_selection_criteria-search-or_parameter_name->*[] IS INITIAL
                OR NOT me->ms_selection_criteria-search-or_attribute_name->*[] IS INITIAL
               )   AND (
                   NOT me->ms_selection_criteria-search-or_attribute_value_low->*[]  IS INITIAL
                OR NOT me->ms_selection_criteria-search-or_attribute_value_high->*[] IS INITIAL
               ) )
                WHEN abap_true THEN 1 ELSE 0
            ).

          WHEN 'ORH'. ##NO_TEXT
            " Coche "OR" Valeur Haute
            ""  --> Modifie la possibilité de cocher
            ls_screen-input = SWITCH #( xsdbool(
                  NOT me->ms_selection_criteria-search-or_attribute_value_low->*[]  IS INITIAL
              AND NOT me->ms_selection_criteria-search-or_attribute_value_high->*[] IS INITIAL )
                WHEN abap_true THEN 1 ELSE 0
            ).

          WHEN OTHERS.
            " Autre
            ""  --> Passe à l'itération suivante
            CONTINUE.

        ENDCASE.

        " Modification des propriétés d'affichage
        MODIFY screen FROM ls_screen.

      ENDLOOP.

    ENDIF.

  ENDMETHOD.

  METHOD pbo.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_method TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation Nom de la méthode PBO
    " -----------------------------------------------------------

    lv_method = |PBO_{ sy-dynnr }|.                         ##NO_TEXT

    TRY.
        " -----------------------------------------------------------
        " Appel PBO
        " -----------------------------------------------------------

        CALL METHOD me->(lv_method).

      CATCH cx_root.
        " Méthode n'existe pas
        ""  --> Arrêt du traitement
        RETURN.

    ENDTRY.

  ENDMETHOD.

  METHOD pai.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_method TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation Nom de la méthode PAI
    " -----------------------------------------------------------

    lv_method = |PAI_{ sy-dynnr }|.                         ##NO_TEXT

    TRY.
        " -----------------------------------------------------------
        " Appel PAI
        " -----------------------------------------------------------

        CALL METHOD me->(lv_method)
          EXPORTING
            iv_ucomm = ok_code.

      CATCH cx_root.
        " Erreur appel dynamique
        RETURN.

    ENDTRY.

  ENDMETHOD.

  METHOD pbo_0101.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation barre d'état
    " -----------------------------------------------------------

    SET PF-STATUS 'PF_STATUS_0101'.                         ##NO_TEXT
    SET TITLEBAR 'TITLEBAR_0101' WITH me->mo_hardcode_maintain->mv_repid. ##NO_TEXT

  ENDMETHOD.

  METHOD pai_0101.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Gestion Action Utilisateur
    " -----------------------------------------------------------

    " Suivant l'action utilisateur
    CASE iv_ucomm.

      WHEN lcl_main=>mc_event-back
        OR lcl_main=>mc_event-exit
        OR lcl_main=>mc_event-leave.
        " Retour / Arrêt
        IF me->is_changed( ) EQ abap_true.
          " Données modifiées non persistée
          ""  --> Affiche popup confirmation
          IF lcl_main=>call_popup_confirm_data_loss( ) EQ abap_true.
            " Oui
            ""  --> Sauvegarde
            me->save( ).

          ENDIF.

        ENDIF.

        " Suivant l'action utilisateur
        CASE iv_ucomm.

          WHEN lcl_main=>mc_event-leave.
            "  Arrêt
            ""  --> Interruption du traitement
            LEAVE PROGRAM.

          WHEN lcl_main=>mc_event-cancel.
            " Interrompre
            ""  --> Ne rien faire

          WHEN OTHERS.
            " Retour
            ""  --> Retourne à l'écran précédent
            me->event_raise( lcl_main=>mc_event-display_leave ).
            LEAVE TO SCREEN 0.                              ##NO_TEXT

        ENDCASE.

      WHEN lcl_main=>mc_event-save.
        " Sauvegarde
        ""  --> Sauvegarde
        me->save( ).

      WHEN OTHERS.
        " Autres

    ENDCASE.

  ENDMETHOD.

  METHOD pbo_0201.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation barre d'état
    " -----------------------------------------------------------

    SET TITLEBAR 'TITLEBAR_0201' WITH gs_attribute_detail-attribute_name. ##NO_TEXT

    " -----------------------------------------------------------
    " Initialisation focus
    " -----------------------------------------------------------

    SET CURSOR FIELD 'BTN_VALID'.                           ##NO_TEXT

    " -----------------------------------------------------------
    " Modification des données affichées
    " -----------------------------------------------------------

    " Modification de l'affichage
    LOOP AT SCREEN.

      IF  screen-group2 EQ 'RON'                            ##NO_TEXT
      AND gs_attribute_detail-read_only EQ abap_true.
        " Lecture-seule
        ""  --> Désactive la saisie
        screen-input = 0.

        ""  --> Modifie les propriétés de l'écran
        MODIFY SCREEN.

      ENDIF.

      " Suivant le groupe
      CASE screen-group1.

        WHEN 'RAN'.                                         ##NO_TEXT
          " Range
          ""  --> Affiche / Masque les valeurs de sélection multiple
          IF gs_attribute_detail-attribute_as_range EQ abap_true.
            " Valeur multiple
            ""  --> Affiche zone de saisie
            screen-active    = 1.
            screen-invisible = 0.

          ELSE.
            " Pas de valeurs multiple
            ""  --> Masque zone de saisie
            screen-active    = 0.
            screen-invisible = 1.

          ENDIF.

        WHEN 'COS'.                                         ##NO_TEXT
          " Code Source
          ""  --> Affiche / Masque le bouton d'Edition
          IF gs_attribute_detail-attribute_as_source_code EQ abap_true.
            " Code Source
            ""  --> Affiche zone de saisie
            screen-active    = 1.
            screen-invisible = 0.

          ELSE.
            " Pas de Code Source
            ""  --> Masque zone de saisie
            screen-active    = 0.
            screen-invisible = 1.

          ENDIF.

        WHEN OTHERS.
          " Autres
          CONTINUE.

      ENDCASE.

      " Modification de l'écran
      MODIFY SCREEN.

    ENDLOOP.

  ENDMETHOD.

  METHOD pai_0201.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
          lo_attribute_detail TYPE REF TO lcl_attribute_detail.

***------------------------------------------------------------------***
**                             RANGES                                 **
***------------------------------------------------------------------***
    DATA :
      lor_range TYPE REF TO tt_r_ranges.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
          lot_source_code TYPE REF TO stringtab.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    CLEAR : gs_attribute_detail-cancel.

    " -----------------------------------------------------------
    " Pré-Traitement
    " -----------------------------------------------------------

    " Récupération instance Gestion Détail
    lo_attribute_detail = lcl_attribute_detail=>instance_get( ).

    " -----------------------------------------------------------
    " Traitement action utilisateur
    " -----------------------------------------------------------

    " Suivant l'action utilisateur
    CASE iv_ucomm.

      WHEN lcl_main=>mc_event-back
        OR lcl_main=>mc_event-exit
        OR lcl_main=>mc_event-valid.
        " Retour
        ""  --> Modification avant sortie
        IF gs_attribute_detail-attribute_as_range EQ abap_false.
          " Pas de Valeurs multiple
          ""  --> Supprime les valeurs saisie
          lor_range = lo_attribute_detail->range_value_get( ).
          FREE : lor_range->*.

        ENDIF.

        IF gs_attribute_detail-attribute_as_source_code EQ abap_false.
          " Pas de Code Source
          ""  --> Supprime Code Saisie
          lot_source_code = lo_attribute_detail->source_code_get( ).
          FREE : lot_source_code->*.

        ENDIF.

        ""  --> Retourne à l'écran précédent
        LEAVE TO SCREEN 0.

      WHEN lcl_main=>mc_event-leave
        OR lcl_main=>mc_event-cancel.
        " Annulation
        ""  --> Appose témoin d'annulation
        gs_attribute_detail-cancel = abap_true.

        ""  --> Retourne à l'écran précédent
        LEAVE TO SCREEN 0.

      WHEN lcl_main=>mc_event-range_display.
        " Range - Modification affichage

      WHEN lcl_main=>mc_event-source_dispay.
        " Code Source - Modification affichage

      WHEN lcl_main=>mc_event-save.
        " Sauvegarde les modifications
        me->save( ).

      WHEN lcl_main=>mc_event-range_set.
        " Range - Edition
        ""  --> Récupération Range
        lor_range = lo_attribute_detail->range_value_get( ).

        IF lor_range IS BOUND.
          ""  --> Ouverture édition range
          IF NOT lcl_main=>range_editor_open(
           EXPORTING
             iv_read_only = lo_attribute_detail->mv_read_only
           CHANGING
             cr_range     = lor_range->*
          ) IS INITIAL.
            " Erreur édition Range
            MESSAGE s397(0d) DISPLAY LIKE if_msg_output=>msgtype_warning.

          ENDIF.

        ENDIF.

      WHEN lcl_main=>mc_event-source_set.
        " Code Source - Edition
        ""  --> Récupération Code Source
        lot_source_code = lo_attribute_detail->source_code_get( ).

        ""  --> Ouverture Editeur
        lcl_main=>source_code_editor_open(
          EXPORTING
            iv_read_only   = lo_attribute_detail->mv_read_only
          CHANGING
            ct_source_code = lot_source_code->*
        ).

      WHEN OTHERS.
        " Autre

    ENDCASE.

  ENDMETHOD.

  METHOD pbo_0301.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation barre d'état
    " -----------------------------------------------------------

    SET PF-STATUS 'PF_STATUS_0301'.                         ##NO_TEXT
    SET TITLEBAR 'TITLEBAR_0301' WITH me->mo_hardcode_maintain->mv_repid. ##NO_TEXT

    " -----------------------------------------------------------
    " Initialisation barre d'état
    " -----------------------------------------------------------

    " Affichage HC Local / Distant
    me->hardcode_compare_display(
      is_system_target = VALUE #(
        system  = gs_transport_target-system
        mandant = gs_transport_target-mandant
      )
    ).

  ENDMETHOD.

  METHOD pai_0301.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
          lo_transport_target TYPE REF TO ts_transport_target.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Suivant l'action utilisateur
    " -----------------------------------------------------------

    " Suivant l'action utilisateur
    CASE iv_ucomm.

      WHEN lcl_main=>mc_event-back
        OR lcl_main=>mc_event-exit.
        " Retour
        ""  --> Retourne à l'écran précédent
        me->event_raise( lcl_main=>mc_event-display_leave ). "Lève évènements quitte l'affichage
        LEAVE TO SCREEN 0.

      WHEN lcl_main=>mc_event-transport.
        " Transporter
        ""  --> Transport les Hardcodes vers la Cible définie
        CREATE DATA lo_transport_target TYPE ts_transport_target.
        lo_transport_target->* = gs_transport_target.
        me->process(
          iv_event    = lcl_main_tree_toolbar_event=>mc_function-transport
          io_argument = lo_transport_target
        ).

        ""  --> Recharge Arbre Distant
        me->hardcode_compare_display(
          is_system_target = VALUE #(
            system  = gs_transport_target-system
            mandant = gs_transport_target-mandant
          )
          iv_refresh_target = abap_true
        ).

      WHEN lcl_main=>mc_event-refresh.
        " Rafrachir
        ""  --> Recharge l'Arbre Local / Distant
        me->hardcode_compare_display(
          is_system_target = VALUE #(
            system  = gs_transport_target-system
            mandant = gs_transport_target-mandant
          )
          iv_refresh_local  = abap_true
          iv_refresh_target = abap_true
        ).

      WHEN lcl_main=>mc_event-cancel.
        " Annuler
        ""  --> Retour à l'écran précédent
        me->event_raise( lcl_main=>mc_event-display_leave ). "Lève évènements quitte l'affichage
        LEAVE TO SCREEN 0.

      WHEN OTHERS.
        " Autres

    ENDCASE.

  ENDMETHOD.

  METHOD pbo_0302.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation barre d'état
    " -----------------------------------------------------------

    SET PF-STATUS 'PF_STATUS_0302'.

  ENDMETHOD.

  METHOD pai_0302.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Suivant l'action utilisateur
    " -----------------------------------------------------------

    " Suivant l'action utilisateur
    CASE iv_ucomm.

      WHEN lcl_main=>mc_event-transport.
        " Transporter
        ""  --> Contrôle
        IF gs_transport_target-system  IS INITIAL
        OR gs_transport_target-mandant IS INITIAL.
          " Mandant / Système obligatoire
          IF gs_transport_target-mandant IS INITIAL.
            " Mandant obligatoire
            MESSAGE s010(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_error.

          ELSE.
            " Système obligatoire
            MESSAGE s009(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_error.

          ENDIF.

        ELSEIF sy-mandt EQ gs_transport_target-mandant
           AND sy-sysid EQ gs_transport_target-system.
          " Environnement courant = Environnement cible
          MESSAGE s011(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_warning.

        ELSE.
          ""  --> Transport de tous les Hardcodes
          gs_transport_target-cancel        = abap_false.
          gs_transport_target-transport_all = abap_true.

          ""  --> Retour à l'écran précédent
          LEAVE TO SCREEN 0.

        ENDIF.

      WHEN lcl_main=>mc_event-back OR lcl_main=>mc_event-exit
        OR lcl_main=>mc_event-ecan OR lcl_main=>mc_event-leave OR lcl_main=>mc_event-cancel.
        " Annuler
        ""  --> Appose témoin annulation
        CLEAR : gs_transport_target.
        gs_transport_target-cancel = abap_true.

        ""  --> Retour à l'écran précédent
        LEAVE TO SCREEN 0.

      WHEN OTHERS.
        " Autres

    ENDCASE.

  ENDMETHOD.

  METHOD pbo_2000.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation barre d'état
    " -----------------------------------------------------------

    SET TITLEBAR 'TITLEBAR_2000'. ##NO_TEXT
    SET PF-STATUS 'PF_STATUS_2000'. ##NO_TEXT

  ENDMETHOD.

  METHOD pai_2000.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Suivant l'action utilisateur
    " -----------------------------------------------------------

    " Suivant l'action utilisateur
    CASE iv_ucomm.

      WHEN lcl_main=>mc_event-execute.
        " Exécuter
        ""  --> Recherche des Hardcodes correspondant
        me->_programm_search( ).

      WHEN lcl_main=>mc_event-back
        OR lcl_main=>mc_event-exit
        OR lcl_main=>mc_event-leave.
        " Retour
        ""  --> Retour à l'écran précédent
        CLEAR : ok_code.
        LEAVE TO SCREEN 0.

      WHEN OTHERS.
        " Autres

    ENDCASE.

    IF iv_ucomm(1) NE '%' ##NO_TEXT.
      ""  --> On initialise ici une action inutile
      "" pour le retour vers la méthode "AT_SELECTION_SCREEN"
      ok_code = lcl_main=>mc_event-dummy.

    ENDIF.

  ENDMETHOD.

  METHOD hardcode_compare_display.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_hardcode_local  TYPE zvtec_t_hc_tt,
      lt_hardcode_target TYPE zvtec_t_hc_tt.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_hardcode_tree_local  TYPE REF TO lcl_main_tree,
      lo_hardcode_tree_target TYPE REF TO lcl_main_tree.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_destination TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    IF iv_refresh_local                       EQ abap_true
    OR me->ms_process_instance-v_first_dispay EQ abap_false.
      " -----------------------------------------------------------
      " Création Instance ALV Local
      " -----------------------------------------------------------

      " Récupération HC Local
      CALL FUNCTION 'Z_HC_READ'
        EXPORTING
          iv_repid    = me->ms_selection_criteria-main-ov_repid->*
        IMPORTING
          et_hardcode = lt_hardcode_local.

      " Création Instance ALV Local
      CREATE OBJECT lo_hardcode_tree_local
        EXPORTING
          io_main           = me
          iv_repid          = me->ms_selection_criteria-main-ov_repid->*
          iv_read_only      = abap_true
          iv_container_name = 'CC_HARDCODE_TREE_LOCAL'. ##NO_TEXT

      " Préparation affichage
      lo_hardcode_tree_local->process(
        iv_event     = lcl_main_tree_toolbar_event=>mc_function-none
        it_hardcode  = lt_hardcode_local
      ).

    ENDIF.

    IF iv_refresh_target                      EQ abap_true
    OR me->ms_process_instance-v_first_dispay EQ abap_false.

      IF NOT is_system_target IS INITIAL.
        " -----------------------------------------------------------
        " Création Instance ALV Cible
        " -----------------------------------------------------------

        " Détermination Déstination
        lv_destination = |{ is_system_target-system }CLNT{ is_system_target-mandant }|. ##NO_TEXT

        " Leture HC Cible
        CALL FUNCTION 'Z_HC_READ'
          DESTINATION lv_destination
          EXPORTING
            iv_repid              = me->ms_selection_criteria-main-ov_repid->*
          IMPORTING
            et_hardcode           = lt_hardcode_target
          EXCEPTIONS ##FM_SUBRC_OK
            error_message         = 1
            system_failure        = 2
            communication_failure = 3
            OTHERS                = 4.

        " Création Instance ALV Cible
        CREATE OBJECT lo_hardcode_tree_target
          EXPORTING
            io_main           = me
            iv_repid          = me->ms_selection_criteria-main-ov_repid->*
            is_system         = is_system_target
            iv_read_only      = abap_true
            iv_container_name = 'CC_HARDCODE_TREE_TARGET'. ##NO_TEXT

        " Préparation Instance ALV Cible
        lo_hardcode_tree_target->process(
          iv_event     = lcl_main_tree_toolbar_event=>mc_function-none
          it_hardcode  = lt_hardcode_target
        ).

      ENDIF.

    ENDIF.

    IF me->ms_process_instance-v_first_dispay EQ abap_false.
      " Premier affichage
      ""  --> Initialisation Indicateur première affichage
      me->ms_process_instance-v_first_dispay = abap_true.

    ENDIF.

  ENDMETHOD.

  METHOD transport_request_create.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    TRY.
        " -----------------------------------------------------------
        " Sélection / Création OT
        " -----------------------------------------------------------

        " Sélection / Création de l'OT
        rv_trkorr = zcl_hardcode_maintain=>transport_request_create( iv_repid ).

      CATCH zcx_hardcode_maintain INTO DATA(lo_cx_hardcode_maintain).
        " Une erreur est survenue // Action interrompu
        ""  --> Affiche le message
        WHILE lo_cx_hardcode_maintain->previous IS BOUND.
          lo_cx_hardcode_maintain ?= lo_cx_hardcode_maintain->previous.
        ENDWHILE.
        MESSAGE ID lo_cx_hardcode_maintain->if_t100_message~t100key-msgid
              TYPE if_msg_output=>msgtype_success
            NUMBER lo_cx_hardcode_maintain->if_t100_message~t100key-msgno
              WITH lo_cx_hardcode_maintain->if_t100_message~t100key-attr1
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr2
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr3
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr4
           DISPLAY LIKE if_msg_output=>msgtype_error.

        ""  --> Arrêt du traitement
        RETURN.

    ENDTRY.

  ENDMETHOD.

  METHOD handler_on_display_aft_can.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Traitement pour affichage après annulation des modif.
    " -----------------------------------------------------------

    " Réinitialise Evénement enregistré
    CLEAR : me->ms_process_instance-v_registered_event.

    " Relance l'affichage des HC
    me->process( lcl_main=>mc_event-display ).

  ENDMETHOD.

  METHOD programm_search.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Recherche - Appel écran de sélection
    " -----------------------------------------------------------

    CALL SCREEN 2000.

  ENDMETHOD.

  METHOD programm_display.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Affichage HC
    " -----------------------------------------------------------

    " Affichage
    me->process( lcl_main_tree_toolbar_event=>mc_function-display ).

  ENDMETHOD.

  METHOD programm_deletion.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_cx_hardcode_maintain TYPE REF TO zcx_hardcode_maintain.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_answer             TYPE c LENGTH 1,
      lv_transport_deletion TYPE xsdboolean.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF me->ms_selection_criteria-main-ov_repid->* IS INITIAL.
      " Identifiant obligatoire
      ""  --> Arrêt du traitement
      MESSAGE s012(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " Recherche existence de la Version
    SELECT SINGLE mandt FROM ztec_t_hc_vers
                        INTO lv_answer
                       WHERE repid EQ me->ms_selection_criteria-main-ov_repid->*.
    IF sy-subrc NE 0.
      " La Version n'existe pas
      ""  --> Affiche message succès
      MESSAGE w001(zhardcode) WITH me->ms_selection_criteria-main-ov_repid->*.

      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Suppression Hardcode du Programme
    " -----------------------------------------------------------

    TRY.
        ""  --> Recherche au moins un Attribut présent sur le Programme
        SELECT mandt FROM zvtec_t_hc UP TO 1 ROWS
                     INTO lv_answer
                     WHERE repid EQ me->ms_selection_criteria-main-ov_repid->*.
        ENDSELECT.
        IF sy-subrc EQ 0.
          " Au moins un Attribut sur ce Programme
          ""  --> Appel PopUp Confirmation suppression
          CALL FUNCTION 'POPUP_TO_CONFIRM'
            EXPORTING
              titlebar              = text-tde
              text_question         = text-tq2
              text_button_1         = text-oui
              icon_button_1         = text-tra
              text_button_2         = text-oui
              icon_button_2         = text-oka
              default_button        = '1' ##NO_TEXT
              display_cancel_button = abap_true
            IMPORTING
              answer                = lv_answer
            EXCEPTIONS
              text_not_found        = 1
              OTHERS                = 2.
          IF sy-subrc  NE 0.
            " L'utilisateur refuse la suppression
            ""  --> Arrêt du traitement
            RETURN.

          ENDIF.

          " Suivant la réponse de l'utilisateur
          CASE lv_answer.

            WHEN '1'.
              " Suppression avec Transport
              ""  --> Initialisation Indicateur Transport des Suppressions
              lv_transport_deletion = abap_true.

            WHEN '2'.
              " Suppression sans Transport

            WHEN OTHERS.
              " Autres // Interrompre
              ""  --> Arrêt du traitement
              RETURN.

          ENDCASE.

        ENDIF.

        ""  --> Création instance Hardcode
        CREATE OBJECT me->mo_hardcode_maintain
          EXPORTING
            iv_repid = me->ms_selection_criteria-main-ov_repid->*.

        ""  --> Suppression de toutes les données
        me->mo_hardcode_maintain->version_del( ).

        ""  --> Sauvegarde les modifications en DB
        me->mo_hardcode_maintain->save_to_db( abap_false ).

        TRY.
            IF zcl_hardcode_shm=>hardcode_is_load( me->ms_selection_criteria-main-ov_repid->* ) EQ abap_true.
              ""  --> Suppression en SHM
              zcl_hardcode_shm=>hardcode_unload( me->ms_selection_criteria-main-ov_repid->* ).

            ENDIF.

          CATCH zcx_hardcode_shm. ##NO_HANDLER
            " Une erreur est survenue // Tant pis ...

        ENDTRY.

        IF lv_transport_deletion EQ abap_true.
          " L'utilisateur souhaite transporter la suppression
          ""  --> Traitement Transport
*          ""  --> Initialisation tables des Clefs
*          LOOP AT lt_join ASSIGNING FIELD-SYMBOL(<lfs_s_join>).
*
*            AT NEW version_guid.
*              " A chaque changement de Version
*              ""  --> Ajout du GUID de Version
*              APPEND <lfs_s_join>-version_guid TO lt_vers_guid_to_del.
*
*            ENDAT.
*
*            AT NEW parameter_guid.
*              " A chaque changement de Paramètre
*              ""  --> Ajout du GUID de Paramètre
*              APPEND <lfs_s_join>-parameter_guid TO lt_param_guid_to_del.
*
*            ENDAT.
*
*            AT NEW attribute_guid_regroup.
*              " A chaque changement d'Attribut
*              ""  --> Ajout du GUID Attribut
*              APPEND <lfs_s_join>-attribute_guid_regroup TO lt_attr_guid_to_del.
*
*            ENDAT.
*
*          ENDLOOP.
*
*          " Tri et Suppression des doublons
*          SORT lt_vers_guid_to_del.  DELETE ADJACENT DUPLICATES FROM lt_vers_guid_to_del.
*          SORT lt_attr_guid_to_del.  DELETE ADJACENT DUPLICATES FROM lt_attr_guid_to_del.
*          SORT lt_param_guid_to_del. DELETE ADJACENT DUPLICATES FROM lt_param_guid_to_del.
*
*          IF NOT lt_vers_guid_to_del[]  IS INITIAL OR
*             NOT lt_attr_guid_to_del[]  IS INITIAL OR
*             NOT lt_param_guid_to_del[] IS INITIAL.
*            ""  --> Création de l'Ordre de Transport
*            lcl_main=>transport_request_create(
*                it_vers_guid_to_del  = lt_vers_guid_to_del
*                it_attr_guid_to_del  = lt_attr_guid_to_del
*                it_param_guid_to_del = lt_param_guid_to_del
*            ).
*
*          ENDIF.
*
        ENDIF.

        ""  --> Commit
        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
          EXPORTING
            wait = abap_true.

        ""  --> Affiche message succès
        MESSAGE s007(zhardcode) WITH me->ms_selection_criteria-main-ov_repid->*.

      CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
        " Une erreur est survenue
        ""  --> Affichage de l'erreur
        WHILE lo_cx_hardcode_maintain->previous IS BOUND.
          lo_cx_hardcode_maintain ?= lo_cx_hardcode_maintain->previous.
        ENDWHILE.
        MESSAGE ID lo_cx_hardcode_maintain->if_t100_message~t100key-msgid
              TYPE if_msg_output=>msgtype_success
            NUMBER lo_cx_hardcode_maintain->if_t100_message~t100key-msgno
              WITH lo_cx_hardcode_maintain->if_t100_message~t100key-attr1
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr2
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr3
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr4
           DISPLAY LIKE if_msg_output=>msgtype_error.

    ENDTRY.

  ENDMETHOD.

  METHOD programm_copy.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_cx_hardcode_maintain TYPE REF TO zcx_hardcode_maintain.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
          lv_repid_new TYPE ztec_t_hc_vers-repid.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF me->ms_selection_criteria-main-ov_repid->* IS INITIAL.
      " Identifiant obligatoire
      ""  --> Arrêt du traitement
      MESSAGE s012(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " Recherche existence de la Version
    SELECT SINGLE repid FROM ztec_t_hc_vers
                        INTO lv_repid_new
                       WHERE repid EQ me->ms_selection_criteria-main-ov_repid->*.
    IF sy-subrc NE 0.
      " La Version n'existe pas
      ""  --> Affiche message succès
      MESSAGE w001(zhardcode) WITH me->ms_selection_criteria-main-ov_repid->*.

      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Copie Hardcode du Programme
    " -----------------------------------------------------------

    TRY.
        ""  --> Création instance Hardcode
        CREATE OBJECT me->mo_hardcode_maintain
          EXPORTING
            iv_repid = me->ms_selection_criteria-main-ov_repid->*.

        ""  --> Détermination Nom de la Copie
        lv_repid_new = me->call_popup_input_simple(
          iv_text  = me->ms_selection_criteria-main-ov_repid->*
          iv_title = text-nre
        ).

        ""  --> Copie de toutes les données
        me->mo_hardcode_maintain = me->mo_hardcode_maintain->hardcode_copy( lv_repid_new ).

        ""  --> Sauvegarde les modifications en DB
        me->mo_hardcode_maintain->save_to_db( abap_true ).

        ""  --> Copie effectuée
        MESSAGE s006(zhardcode) WITH me->ms_selection_criteria-main-ov_repid->* lv_repid_new.

        ""  --> Modification Programme saisie
        me->ms_selection_criteria-main-ov_repid->* = lv_repid_new.

      CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
        " Une erreur est survenue
        ""  --> Affichage de l'erreur
        WHILE lo_cx_hardcode_maintain->previous IS BOUND.
          lo_cx_hardcode_maintain ?= lo_cx_hardcode_maintain->previous.
        ENDWHILE.
        MESSAGE ID lo_cx_hardcode_maintain->if_t100_message~t100key-msgid
              TYPE if_msg_output=>msgtype_success
            NUMBER lo_cx_hardcode_maintain->if_t100_message~t100key-msgno
              WITH lo_cx_hardcode_maintain->if_t100_message~t100key-attr1
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr2
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr3
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr4
           DISPLAY LIKE if_msg_output=>msgtype_error.

    ENDTRY.

  ENDMETHOD.

  METHOD programm_transport.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF me->ms_selection_criteria-main-ov_repid->* IS INITIAL.
      " Identifiant obligatoire
      ""  --> Arrêt du traitement
      MESSAGE s012(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Traitement
    " -----------------------------------------------------------

    " Contrôle existence des Hardcodes du Programme
    SELECT SINGLE mandt FROM ztec_t_hc_vers
                       WHERE repid EQ @me->ms_selection_criteria-main-ov_repid->*
                        INTO @DATA(lv_mandt).
    IF sy-subrc NE 0.
      " Hardcode n'existe pas
      ""  --> Affiche message d'erreur
      IF 1 = 2. MESSAGE e001(zhardcode). ENDIF.
      MESSAGE ID zcl_hardcode=>mc_my_msgid TYPE if_msg_output=>msgtype_success
          NUMBER 001 WITH me->ms_selection_criteria-main-ov_repid->*
             DISPLAY LIKE if_msg_output=>msgtype_error.

      ""  --> Arrêt du traitement
      RETURN.

    ELSE.
      " -----------------------------------------------------------
      " Transport des Hardcodes
      " -----------------------------------------------------------

      me->process( lcl_main_tree_toolbar_event=>mc_function-transport ).

    ENDIF.

  ENDMETHOD.

  METHOD programm_update_shm.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF me->ms_selection_criteria-main-ov_repid->* IS INITIAL.
      " Identifiant obligatoire
      ""  --> Arrêt du traitement
      MESSAGE s012(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Traitement
    " -----------------------------------------------------------

    " Contrôle existence des Hardcodes du Programme
    SELECT SINGLE mandt FROM ztec_t_hc_vers
                       WHERE repid EQ @me->ms_selection_criteria-main-ov_repid->*
                        INTO @DATA(lv_mandt).
    IF sy-subrc NE 0.
      " Hardcode n'existe pas
      ""  --> Affiche message d'erreur
      IF 1 = 2. MESSAGE e001(zhardcode). ENDIF.
      MESSAGE ID zcl_hardcode=>mc_my_msgid TYPE if_msg_output=>msgtype_success
          NUMBER 001 WITH me->ms_selection_criteria-main-ov_repid->*
             DISPLAY LIKE if_msg_output=>msgtype_error.

      ""  --> Arrêt du traitement
      RETURN.

    ELSE.
      " -----------------------------------------------------------
      " Mise à Jour dans la SHM
      " -----------------------------------------------------------

      me->process( lcl_main_tree_toolbar_event=>mc_function-update_shm ).

    ENDIF.

  ENDMETHOD.

  METHOD programm_impex_local.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_answer TYPE c LENGTH 1.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF me->ms_selection_criteria-main-ov_repid->* IS INITIAL.
      " Identifiant obligatoire
      ""  --> Arrêt du traitement
      MESSAGE s012(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " PopUp Sélection Import / Export
    " -----------------------------------------------------------

    " Import ou Export ?
    CALL FUNCTION 'POPUP_TO_CONFIRM'
      EXPORTING
        titlebar              = text-iex
        text_question         = text-tq5
        text_button_1         = text-imp
        icon_button_1         = text-iim
        text_button_2         = text-exp
        icon_button_2         = text-iie
        default_button        = '1' ##NO_TEXT
        display_cancel_button = abap_true
      IMPORTING
        answer                = lv_answer
      EXCEPTIONS
        text_not_found        = 1
        OTHERS                = 2.
    IF sy-subrc NE 0
    OR ( lv_answer NE '1' AND lv_answer NE '2' ).           ##NO_TEXT
      " Interruption
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Traitement
    " -----------------------------------------------------------

    " Suivant l'Action choisie
    CASE lv_answer.

      WHEN '1'.                                             ##NO_TEXT
        " Import
        ""  --> Lance le traitement d'Import
        me->_programm_import_local( ).

      WHEN '2'.                                             ##NO_TEXT
        " Export
        ""  --> Lance le traitement d'Export
        me->_programm_export_local( ).

      WHEN OTHERS.
        " Autres
        ""  --> Arrêt du traitement
        RETURN.

    ENDCASE.

  ENDMETHOD.

  METHOD program_compare.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF me->ms_selection_criteria-main-ov_repid->* IS INITIAL.
      " Identifiant obligatoire
      ""  --> Arrêt du traitement
      MESSAGE s012(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Traitement
    " -----------------------------------------------------------

    " Contrôle existence des Hardcodes du Programme
    SELECT SINGLE mandt FROM ztec_t_hc_vers
                       WHERE repid EQ @me->ms_selection_criteria-main-ov_repid->*
                        INTO @DATA(lv_mandt).
    IF sy-subrc NE 0.
      " Hardcode n'existe pas
      ""  --> Affiche message d'erreur
      IF 1 = 2. MESSAGE e001(zhardcode). ENDIF.
      MESSAGE ID zcl_hardcode=>mc_my_msgid TYPE if_msg_output=>msgtype_success
          NUMBER 001 WITH me->ms_selection_criteria-main-ov_repid->*
             DISPLAY LIKE if_msg_output=>msgtype_error.

      ""  --> Arrêt du traitement
      RETURN.

    ELSE.
      " -----------------------------------------------------------
      " Affichage des Hardcodes Locales / Cibles
      " -----------------------------------------------------------

      " Affichage des Hardcodes pour Comparaison
      me->process( lcl_main_tree_toolbar_event=>mc_function-compare ).

    ENDIF.

  ENDMETHOD.

  METHOD _programm_export_local.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF me->ms_selection_criteria-main-ov_repid->* IS INITIAL.
      " Programme Obligatoire
      ""  --> Affiche message d'erreur

      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Traitement
    " -----------------------------------------------------------

    " Contrôle existence des Hardcodes du Programme
    SELECT SINGLE mandt FROM ztec_t_hc_vers
                       WHERE repid EQ @me->ms_selection_criteria-main-ov_repid->*
                        INTO @DATA(lv_mandt).
    IF sy-subrc NE 0.
      " Hardcode n'existe pas
      ""  --> Affiche message d'erreur
      IF 1 = 2. MESSAGE e001(zhardcode). ENDIF.
      MESSAGE ID zcl_hardcode=>mc_my_msgid TYPE if_msg_output=>msgtype_success
          NUMBER 001 WITH me->ms_selection_criteria-main-ov_repid->*
             DISPLAY LIKE if_msg_output=>msgtype_error.

      ""  --> Arrêt du traitement
      RETURN.

    ELSE.
      " -----------------------------------------------------------
      " Export des Hardcodes
      " -----------------------------------------------------------

      " Traitement Export
      me->process( lcl_main_tree_toolbar_event=>mc_function-export_local ).

    ENDIF.

  ENDMETHOD.

  METHOD _programm_import_local.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
        lt_file_table TYPE filetable.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_rc            TYPE i,
      lv_answer        TYPE char1,
      lv_text_question TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Sélection du fichier
    " -----------------------------------------------------------

    " Sélection du fichier
    cl_gui_frontend_services=>file_open_dialog(
      EXPORTING
        window_title      = CONV #( text-tsf )
        file_filter       = zcl_hardcode_maintain=>mc_file_type_hardcode
        default_extension = zcl_hardcode_maintain=>mc_file_type_hardcode
      CHANGING
        file_table        = lt_file_table
        rc                = lv_rc
      EXCEPTIONS
        OTHERS            = 1
    ).
    IF sy-subrc NE 0
    OR lt_file_table[] IS INITIAL.
      " Fichier non déterminé
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Récupération Nom du Fichier
    me->ms_work_area_public-filename_import = lt_file_table[ 1 ]-filename.

    " Récupération de l'identifiant du Programme dans le fichier
    me->ms_selection_criteria-main-ov_repid->* = zcl_hardcode_file=>hardcode_get_repid(
      me->ms_work_area_public-filename_import
    ).

    IF me->ms_selection_criteria-main-ov_repid->* IS INITIAL.
      " Programme Obligatoire
      ""  --> Affiche message d'erreur

      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    " Contrôle existence des Hardcodes du Programme
    SELECT SINGLE mandt FROM ztec_t_hc_vers
                       WHERE repid EQ @me->ms_selection_criteria-main-ov_repid->*
                        INTO @DATA(lv_mandt).
    IF sy-subrc EQ 0.
      " Hardcode existe pas
      ""  --> Confirme écrasement
      lv_text_question = text-tq4.
      REPLACE '&' WITH me->ms_selection_criteria-main-ov_repid->* INTO lv_text_question. ##NO_TEXT
      CONDENSE lv_text_question.
      CALL FUNCTION 'POPUP_TO_CONFIRM'
        EXPORTING
          titlebar              = text-cim
          text_question         = lv_text_question
          text_button_1         = text-oui
          text_button_2         = text-non
          default_button        = '1' ##NO_TEXT
          display_cancel_button = abap_true
        IMPORTING
          answer                = lv_answer
        EXCEPTIONS
          text_not_found        = 1
          OTHERS                = 2.
      IF sy-subrc  NE 0 OR lv_answer NE '1'.                ##NO_TEXT
        " L'utilisateur refuse l'écrasement
        ""  --> Arrêt du traitement
        MESSAGE s200(ctsprj) DISPLAY LIKE if_msg_output=>msgtype_warning.
        RETURN.

      ENDIF.

    ENDIF.

    " -----------------------------------------------------------
    " Import des Hardcodes
    " -----------------------------------------------------------

    me->process( lcl_main_tree_toolbar_event=>mc_function-import_local ).

  ENDMETHOD.

  METHOD _programm_search.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Exécution de la Recherche
    " -----------------------------------------------------------

    IF me->_programm_search_execute( ) IS INITIAL.
      " Affichage du résultat
      me->_programm_search_display( ).

    ENDIF.

  ENDMETHOD.

  METHOD _programm_search_execute.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_sql_cond TYPE string.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
          <lfs_use_or> TYPE xsdboolean.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Construction condition requête "Nom"
    " -----------------------------------------------------------

    " Initialisation parenthèse ouvrante combinaisons "Nom" et "Valeur"
    lv_sql_cond = SWITCH string(
      xsdbool( (
                    NOT me->ms_selection_criteria-search-or_repid->*                IS INITIAL
                 OR NOT me->ms_selection_criteria-search-or_parameter_name->*       IS INITIAL
                 OR NOT me->ms_selection_criteria-search-or_attribute_name->*       IS INITIAL
               ) AND (
                    NOT me->ms_selection_criteria-search-or_attribute_value_low->*  IS INITIAL
                 OR NOT me->ms_selection_criteria-search-or_attribute_value_high->* IS INITIAL
               )
             )
      WHEN abap_true THEN |(|   ##NO_TEXT
                     ELSE space
    ).

    IF NOT me->ms_selection_criteria-search-or_repid->* IS INITIAL.
      " Recherche par Nom HC
      lv_sql_cond = |{ lv_sql_cond }| &&
        | repid IN @me->ms_selection_criteria-search-or_repid->*|. ##NO_TEXT

    ENDIF.

    IF NOT me->ms_selection_criteria-search-or_parameter_name->* IS INITIAL.
      " Recherche par Nom Paramètre
      ""  --> Ajout pour filtre
      lv_sql_cond = |{ lv_sql_cond } | &&
         |{ SWITCH string( xsdbool(
               NOT lv_sql_cond IS INITIAL
                OR ( zcl_text_utilities=>text_exist( iv_string = lv_sql_cond
                                                     iv_search = '('  ##NO_TEXT
                                                     iv_length = 1
                                                    ) EQ abap_true
                            AND strlen( lv_sql_cond ) GT 1
                   )
              )
              WHEN abap_false THEN space
              ELSE SWITCH string( me->ms_selection_criteria-search-search_option-parameter_or->*
                     WHEN abap_true THEN cl_rsmds_sql_renderer=>c_or
                                    ELSE cl_rsmds_sql_renderer=>c_and
                   )
            )
         }| &&
        | parameter_name IN @me->ms_selection_criteria-search-or_parameter_name->*|.  ##NO_TEXT

      ""  --> Initialise FS sur coche "OR Attribut"
      ASSIGN me->ms_selection_criteria-search-search_option-attribute_or->* TO <lfs_use_or>.

    ELSE.
      ""  --> Initialise FS sur coche "OR Paramètre"
      ASSIGN me->ms_selection_criteria-search-search_option-parameter_or->* TO <lfs_use_or>.

    ENDIF.

    IF NOT me->ms_selection_criteria-search-or_attribute_name->* IS INITIAL.
      " Recherche par Nom Attribut
      ""  --> Ajout pour filtre
      lv_sql_cond = |{ lv_sql_cond } | &&
         |{ SWITCH string( xsdbool(
               NOT lv_sql_cond IS INITIAL
                OR ( zcl_text_utilities=>text_exist( iv_string = lv_sql_cond
                                                     iv_search = '('  ##NO_TEXT
                                                     iv_length = 1
                                                    ) EQ abap_true
                            AND strlen( lv_sql_cond ) GT 1
                   )
              )
              WHEN abap_false THEN space
              ELSE SWITCH string( <lfs_use_or>
                     WHEN abap_true THEN cl_rsmds_sql_renderer=>c_or
                                    ELSE cl_rsmds_sql_renderer=>c_and
                   )
            )
         }| &&
        | attribute_name IN @me->ms_selection_criteria-search-or_attribute_name->*|.  ##NO_TEXT

    ENDIF.

    " Initialisation parenthèse fermante combinaisons "Nom" et "Valeur"
    lv_sql_cond = |{ lv_sql_cond } | && SWITCH string(
      xsdbool( zcl_text_utilities=>text_exist( iv_string = lv_sql_cond
                                               iv_search = '('
                                               iv_length = 1
                                             ) EQ abap_true ) ##NO_TEXT
      WHEN abap_true THEN |)|   ##NO_TEXT
                     ELSE space
    ).

    " -----------------------------------------------------------
    " Construction condition requête "Valeur"
    " -----------------------------------------------------------

    " Gestion opérateur relationnel entre les autres élèments et les valeurs
    lv_sql_cond = |{ lv_sql_cond } | &&
      |{ SWITCH string( xsdbool( NOT lv_sql_cond IS INITIAL AND (
                                    NOT me->ms_selection_criteria-search-or_attribute_value_low->*  IS INITIAL
                                 OR NOT me->ms_selection_criteria-search-or_attribute_value_high->* IS INITIAL )
                                    AND zcl_text_utilities=>text_exist( iv_string = lv_sql_cond
                                                                        iv_search = '('  ##NO_TEXT
                                                                        iv_length = 1
                                                                      ) EQ abap_true
                               )
           WHEN abap_true THEN SWITCH string( me->ms_selection_criteria-search-search_option-value_or->*
                                 WHEN abap_true THEN |{ cl_rsmds_sql_renderer=>c_or } (|
                                                ELSE |{ cl_rsmds_sql_renderer=>c_and } (|
                               )
           ELSE space
         )
      }|.

    IF NOT me->ms_selection_criteria-search-or_attribute_value_low->* IS INITIAL.
      " Recherche par Valeur Basse
      ""  --> Ajout pour filtre
      lv_sql_cond = |{ lv_sql_cond } | &&
        | attribute_low IN @me->ms_selection_criteria-search-or_attribute_value_low->*|.  ##NO_TEXT

    ENDIF.

    IF NOT me->ms_selection_criteria-search-or_attribute_value_high->* IS INITIAL.
      " Recherche par Valeur Haute
      ""  --> Ajout pour filtre
      lv_sql_cond = |{ lv_sql_cond } | &&
         |{ SWITCH string( xsdbool(
               NOT lv_sql_cond IS INITIAL )
              WHEN abap_false THEN space
              ELSE SWITCH string( xsdbool( NOT me->ms_selection_criteria-search-or_attribute_value_low->* IS INITIAL )
                     WHEN abap_false THEN space
                     ELSE SWITCH string( me->ms_selection_criteria-search-search_option-value_high_or->*
                            WHEN abap_true THEN | { cl_rsmds_sql_renderer=>c_or }|
                                           ELSE | { cl_rsmds_sql_renderer=>c_and }|
                          )
                   )
            )
         }| &&
        | attribute_high IN @me->ms_selection_criteria-search-or_attribute_value_high->*|.  ##NO_TEXT

    ENDIF.

    " Gestion parenthèse fermetante des Valeurs
    lv_sql_cond = |{ lv_sql_cond }| && |{ SWITCH string( xsdbool(
               (
                    NOT me->ms_selection_criteria-search-or_repid->*                IS INITIAL
                 OR NOT me->ms_selection_criteria-search-or_parameter_name->*       IS INITIAL
                 OR NOT me->ms_selection_criteria-search-or_attribute_name->*       IS INITIAL
               ) AND (
                    NOT me->ms_selection_criteria-search-or_attribute_value_low->*  IS INITIAL
                 OR NOT me->ms_selection_criteria-search-or_attribute_value_high->* IS INITIAL
               )
             )
      WHEN abap_true THEN | )|   ##NO_TEXT
                     ELSE space
     ) }|.

    " -----------------------------------------------------------
    " Recherche
    " -----------------------------------------------------------

    " Recherche des Hardcodes correspondant
    SELECT repid,
           parameter_name,
           attribute_name,
           attribute_key1, attribute_key2,
           attribute_key3, attribute_key4,
           attribute_low, attribute_high
      FROM zvtec_t_hc
     WHERE (lv_sql_cond)
      INTO CORRESPONDING FIELDS OF TABLE @me->ms_work_area_private-t_hardcode_search.
    IF sy-subrc NE 0.
      " Aucune Valeur trouvée
      ""  --> Retourne code en erreur
      MESSAGE s003(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_warning.
      rv_subrc = 4.

      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

  ENDMETHOD.

  METHOD _programm_search_display.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

    TYPES :
      BEGIN OF lts_properties_display,
        fieldname     TYPE string,
        visible       TYPE xsdboolean,
        output_length TYPE lvc_outlen,
      END OF   lts_properties_display.

    TYPES : ltt_properties_display TYPE SORTED TABLE OF lts_properties_display
                    WITH NON-UNIQUE KEY primary_key COMPONENTS fieldname.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
        lt_properties_display TYPE ltt_properties_display.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_salv    TYPE REF TO cl_salv_table,
      lo_column  TYPE REF TO cl_salv_column_table,
      lo_columns TYPE REF TO cl_salv_columns_table.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
          <lfs_value> TYPE any.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF me->ms_work_area_private-t_hardcode_search IS INITIAL.
      " Aucune données
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Préparation propriétés d'affichage
    " -----------------------------------------------------------

    lt_properties_display = VALUE #(
      ( fieldname = 'REPID' ##NO_TEXT )
      ( fieldname = 'PARAMETER_NAME' ##NO_TEXT )
      ( fieldname = 'ATTRIBUTE_NAME' ##NO_TEXT )
      ( fieldname = 'ATTRIBUTE_KEY1' ##NO_TEXT )
      ( fieldname = 'ATTRIBUTE_KEY2' ##NO_TEXT )
      ( fieldname = 'ATTRIBUTE_KEY3' ##NO_TEXT )
      ( fieldname = 'ATTRIBUTE_KEY4' ##NO_TEXT )
      ( fieldname = 'ATTRIBUTE_LOW' ##NO_TEXT )
      ( fieldname = 'ATTRIBUTE_HIGH' ##NO_TEXT )
    ).

    LOOP AT me->ms_work_area_private-t_hardcode_search
      ASSIGNING FIELD-SYMBOL(<lfs_s_hc_search>).

      LOOP AT lt_properties_display ASSIGNING FIELD-SYMBOL(<lfs_s_properties_display>).

        " Récupération de la valeur du champ correspondant
        ASSIGN COMPONENT <lfs_s_properties_display>-fieldname
            OF STRUCTURE <lfs_s_hc_search>
                      TO <lfs_value>.
        IF sy-subrc NE 0.
          " Aucun champ correspondant
          ""  --> Passe à l'itération suivante
          CONTINUE.

        ENDIF.

*        " Suivant la Colonne
*        CASE <lfs_s_properties_display>-fieldname.
*
*          WHEN 'REPID'. ##NO_TEXT
*            " Programme
*            <lfs_s_hc_search>-t_hyperlink =
*
*          WHEN OTHERS.
*            " Autre
*
*        ENDCASE.

        IF  <lfs_value> IS INITIAL
        AND <lfs_s_properties_display>-visible EQ abap_false.
          " Valeur vide
          ""  --> Masque la colonne
          <lfs_s_properties_display>-visible = abap_false.

        ELSE.
          " Valeur
          ""  --> Affiche la Colonne
          <lfs_s_properties_display>-visible = abap_true.

          ""  --> Détermine la longueur
          IF <lfs_s_properties_display>-output_length LT strlen( <lfs_value> ).
            " Longueur plus grande que celle précédemment
            <lfs_s_properties_display>-output_length = strlen( <lfs_value> ).

          ENDIF.

        ENDIF.

      ENDLOOP.

    ENDLOOP.

    TRY.
        " -----------------------------------------------------------
        " Affiche les données
        " -----------------------------------------------------------

        " Génération SALV
        cl_salv_table=>factory(
          IMPORTING
            r_salv_table = lo_salv
          CHANGING
            t_table      = me->ms_work_area_private-t_hardcode_search
        ).

        " Gestion évènement
        lo_salv->get_functions( )->set_all( abap_true ).

        " Récupération des Colonnes
        lo_columns = lo_salv->get_columns( ).

        LOOP AT lt_properties_display ASSIGNING <lfs_s_properties_display>.

          TRY.
              " Récupération Colonne correspondante
              lo_column ?= lo_columns->get_column( CONV #( <lfs_s_properties_display>-fieldname ) ).
              lo_column->set_visible( <lfs_s_properties_display>-visible ).
              lo_column->set_output_length( <lfs_s_properties_display>-output_length ).

              CASE <lfs_s_properties_display>-fieldname.

                WHEN 'REPID'. ##NO_TEXT
                  " Programme
                  lo_column->set_cell_type( if_salv_c_cell_type=>link ).

                WHEN OTHERS.
                  " Autre

              ENDCASE.

            CATCH cx_salv_not_found.

          ENDTRY.

        ENDLOOP.

        " Affichage
        lo_salv->display( ).

      CATCH cx_salv_msg.

    ENDTRY.

  ENDMETHOD.

ENDCLASS.


*----------------------------------------------------------------------*
*       CLASS LCL_MAIN_TREE IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main_tree IMPLEMENTATION.

  METHOD constructor.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
          ls_system TYPE ts_system.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Pré-Traitement
    " -----------------------------------------------------------

    IF is_system IS INITIAL.
      " Aucun système transmis
      ""  --> Utilisation système courant
      ls_system-system  = sy-sysid.
      ls_system-mandant = sy-mandt.

    ELSE.
      " Système transmis
      ""  --> Utilisation de ce système
      ls_system = is_system.

    ENDIF.

    " -----------------------------------------------------------
    " Initialisation attributs
    " -----------------------------------------------------------

    " Instance Principal
    me->mo_main = io_main.

    " Initialisation Attribut
    me->mv_repid     = iv_repid.
    me->ms_system    = ls_system.
    me->mv_read_only = iv_read_only.

    " Nom du Custom Container
    me->ms_display_element-display_element-v_container_name = iv_container_name.

    " -----------------------------------------------------------
    " Souscription aux évènements
    " -----------------------------------------------------------

    " Handler sur la sauvegarde
    SET HANDLER me->handler_on_save FOR me->mo_main.

    " Handler sur la fermeture de l'affichage
    SET HANDLER me->handler_on_display_leave FOR me->mo_main.

  ENDMETHOD.

  METHOD free.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Libére les objets inutiles
    " -----------------------------------------------------------

    " Table données affichées
    FREE : me->ms_display_element-data-t_display_data.

    IF me->ms_display_element-display_element-o_container IS BOUND.
      " Arbre ALV
      me->ms_display_element-display_element-o_alv_tree->free(
        EXCEPTIONS
          cntl_error        = 0
          cntl_system_error = 0
          OTHERS            = 0
      ).

    ENDIF.

    IF me->ms_display_element-display_element-o_container IS BOUND.
      " Container
      me->ms_display_element-display_element-o_container->free(
        EXCEPTIONS
          cntl_error        = 0
          cntl_system_error = 0
          OTHERS            = 0
      ).

      FREE : me->ms_display_element-display_element-o_container.

    ENDIF.

    IF me->ms_display_element-display_element-o_ccontainer IS BOUND.
      " Custom Container
      me->ms_display_element-display_element-o_ccontainer->free(
        EXCEPTIONS
          cntl_error        = 0
          cntl_system_error = 0
          OTHERS            = 0
      ).

      FREE : me->ms_display_element-display_element-o_ccontainer.

    ENDIF.

    " -----------------------------------------------------------
    " Traitement supplémentaire
    " -----------------------------------------------------------

    " Simule une action pour déclencher le PBO
    cl_gui_cfw=>set_new_ok_code( lcl_main_tree_toolbar_event=>mc_function-none ).

    " Synchronisation Back & Front
    cl_gui_cfw=>flush(
      EXCEPTIONS
        cntl_error        = 0
        cntl_system_error = 0
    ).

  ENDMETHOD.

  METHOD process.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
          ls_transport_target TYPE ts_transport_target.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
          <lfs_argument> TYPE any.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Libère les objets inutiles
    " -----------------------------------------------------------

    " Libération objets
    me->free( ).

    " -----------------------------------------------------------
    " Chargement des données
    " -----------------------------------------------------------

    rv_subrc = me->load_data( it_hardcode ).

    IF rv_subrc IS INITIAL.
      " -----------------------------------------------------------
      " Initialisation des élèments à afficher
      " -----------------------------------------------------------

      me->build_display_element( ).

      " -----------------------------------------------------------
      " Initialisation des données à afficher
      " -----------------------------------------------------------

      me->build_hierarchy_node( ).

    ENDIF.

    " -----------------------------------------------------------
    " Gestion Evenement / Traitement
    " -----------------------------------------------------------

    " Simule l'Action utilisateur à la place de l'Affichage
    ""  --> Suivant l'Evèment
    CASE iv_event.

      WHEN lcl_main_tree_toolbar_event=>mc_function-none.
        " -----------------------------------------------------------
        " Etend jusqu'au Noeud indiqué
        " -----------------------------------------------------------

        me->ms_display_element-display_element-o_alv_tree->expand_node(
          EXPORTING
            i_node_key          = cl_sedi_abs_nav_tree=>c_root_key
            i_level_count       = 10
            i_expand_subtree    = abap_true
          EXCEPTIONS                                      ##SUBRC_OK
            failed              = 1
            illegal_level_count = 2
            cntl_system_error   = 3
            node_not_found      = 4
            cannot_expand_leaf  = 5
            OTHERS              = 6
        ).

      WHEN lcl_main_tree_toolbar_event=>mc_function-display.
        " Affichage des Hardcodes
        me->display( ).

      WHEN lcl_main_tree_toolbar_event=>mc_function-compare.
        ""  --> Comparaison
        me->ms_display_element-display_element-o_toolbar_handler->handler_on_compare( ).

      WHEN lcl_main_tree_toolbar_event=>mc_function-transport.
        ""  --> Transporter
        IF io_argument IS BOUND.
          " Argument d'Evenement transmis
          ""  --> Utilisation Système cible
          ASSIGN io_argument->* TO <lfs_argument>.
          IF sy-subrc EQ 0.
            MOVE-CORRESPONDING <lfs_argument> TO ls_transport_target.

          ENDIF.

        ENDIF.

        ""  --> Transport
        me->ms_display_element-display_element-o_toolbar_handler->handler_on_transport(
          iv_advanced_mode    = abap_false
          is_transport_target = ls_transport_target
        ).

      WHEN lcl_main_tree_toolbar_event=>mc_function-update_shm.
        ""  --> MàJ SHM
        me->ms_display_element-display_element-o_toolbar_handler->handler_on_update_shm( ).

      WHEN lcl_main_tree_toolbar_event=>mc_function-export_local.
        ""  --> Export Local
        me->ms_display_element-display_element-o_toolbar_handler->handler_on_export_local( ).

      WHEN lcl_main_tree_toolbar_event=>mc_function-import_local.
        ""  --> Import Local
        me->ms_display_element-display_element-o_toolbar_handler->handler_on_import_local(
          me->mo_main->ms_work_area_public-filename_import
        ).

      WHEN OTHERS.
        " Autres

    ENDCASE.

  ENDMETHOD.

  METHOD handler_on_save.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Après la sauvegarde
    " -----------------------------------------------------------

    " Masque le bouton "Annuler"
    me->_toolbar_button_visibility_set( iv_cancel_visible = abap_false ).

  ENDMETHOD.

  METHOD handler_on_display_leave.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Libération élèments d'affichage
    " -----------------------------------------------------------

    " Libére les élèments d'affichage
    me->free( ).

  ENDMETHOD.

  METHOD load_data.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_hardcode TYPE zvtec_t_hc_tt.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_hc_data               TYPE ts_hc_data_internal,
      ls_attribute_range       TYPE ts_attribute_range,
      ls_attribute_range_value TYPE zcl_hardcode_maintain=>ts_attribute_range_value_det.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    CLEAR : rv_subrc.

    " -----------------------------------------------------------
    " Pré-traitement
    " -----------------------------------------------------------

    " Initialisation table locale
    lt_hardcode[] = it_hardcode[].
    SORT lt_hardcode BY attribute_guid_regroup.

*    " -----------------------------------------------------------
*    " Récupération données Code Source
*    " -----------------------------------------------------------
*
*    " Récupération des Identifiants des Codes Sources
*    SELECT srtfd FROM ztec_t_hc_attr_c
*      FOR ALL ENTRIES IN @lt_hardcode
*                   WHERE srtfd EQ @lt_hardcode-attribute_guid_regroup
*              INTO TABLE @DATA(lt_srtfd_SOURCE_CODE).
*    SORT lt_srtfd_SOURCE_CODE BY srtfd.

    " -----------------------------------------------------------
    " Extraction des lignes non chargées
    " -----------------------------------------------------------

    READ TABLE me->ms_persistent_data-t_hc_data
          WITH TABLE KEY repid      = me->mv_repid
                         system_key = me->ms_system
               ASSIGNING FIELD-SYMBOL(<lfs_s_hc_data>).
    IF sy-subrc NE 0.
      " Aucune données correspondante
      ""  --> Création nouvelle entrée
      ls_hc_data-repid   = me->mv_repid.
      ls_hc_data-system  = me->ms_system-system.
      ls_hc_data-mandant = me->ms_system-mandant.

      ""  --> Sépare les lignes d'Attribut de référence des valeurs multiple
      LOOP AT lt_hardcode ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode>).

        CLEAR : ls_attribute_range.

        " Détermination longueur max
        IF strlen( <lfs_s_hardcode>-attribute_name ) GT ls_hc_data-hierarchy_header_length.
          ls_hc_data-hierarchy_header_length = strlen( <lfs_s_hardcode>-attribute_name ).
        ENDIF.
        IF strlen( <lfs_s_hardcode>-parameter_name ) GT ls_hc_data-hierarchy_header_length.
          ls_hc_data-hierarchy_header_length = strlen( <lfs_s_hardcode>-parameter_name ).
        ENDIF.

        IF <lfs_s_hardcode>-attribute_guid_regroup EQ <lfs_s_hardcode>-attribute_guid.
          " Il s'agit de la ligne de référence
          ""  --> Ajout de l'entrée
          APPEND <lfs_s_hardcode> TO ls_hc_data-t_hardcode.

          ""  --> Récupération Code Source
          INSERT VALUE #(
            attribute_guid_regroup = <lfs_s_hardcode>-attribute_guid_regroup
            t_source_code          = zcl_hardcode_cluster=>source_code_get( <lfs_s_hardcode>-attribute_guid_regroup )
          ) INTO TABLE ls_hc_data-t_source_code.

        ELSE.
          " Il s'agit d'une ligne valeurs multiple
          READ TABLE ls_hc_data-t_attribute_range WITH TABLE KEY attribute_guid_regroup = <lfs_s_hardcode>-attribute_guid_regroup
                                                       ASSIGNING FIELD-SYMBOL(<lfs_s_attribute_range>).
          IF sy-subrc EQ 0.
            " Entrée déjà traitée
            ""  --> Passe à l'itération suivante
            CONTINUE.

          ENDIF.

          " Création nouvelle ligne
          ls_attribute_range-attribute_guid_regroup = <lfs_s_hardcode>-attribute_guid_regroup.
          INSERT ls_attribute_range INTO TABLE ls_hc_data-t_attribute_range ASSIGNING <lfs_s_attribute_range>.

          " Récupération des valeurs multiples
          READ TABLE lt_hardcode WITH KEY attribute_guid_regroup = <lfs_s_hardcode>-attribute_guid_regroup
                            TRANSPORTING NO FIELDS BINARY SEARCH.
          IF sy-subrc EQ 0.
            " Parcours l'ensemble des valeurs multiples
            LOOP AT lt_hardcode ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode_range_value>)
                                     FROM sy-tabix.

              CLEAR : ls_attribute_range_value.

              IF <lfs_s_hardcode_range_value>-attribute_guid_regroup NE <lfs_s_hardcode>-attribute_guid_regroup.
                " On ne traite plus le même regroupement de valeur
                ""  --> Arrêt de la boucle
                EXIT.

              ENDIF.

              IF <lfs_s_hardcode_range_value>-attribute_guid_regroup EQ <lfs_s_hardcode_range_value>-attribute_guid.
                " Ligne de référence
                ""  --> Passe à l'itération suivante
                CONTINUE.

              ENDIF.

              " Initialisation valeurs de range
              MOVE-CORRESPONDING <lfs_s_hardcode_range_value> TO ls_attribute_range_value.

              " Ajout de l'entrée dans les valeurs de range
              INSERT ls_attribute_range_value INTO TABLE <lfs_s_attribute_range>-t_attribute_range_value.

            ENDLOOP.        "Fin parcours des valeurs mutliples de l'Attribut

          ENDIF.            "Fin de test présence valeurs multiples sur l'Attribut

        ENDIF.              "Fin de test Attribut de référence

      ENDLOOP.              "Fin parcours des Hardcodes

      ""  --> Ajout des longueurs
      ADD 25 TO ls_hc_data-hierarchy_header_length. ##NO_TEXT

      ""  --> Ajout de l'entrée
      INSERT ls_hc_data INTO TABLE me->ms_persistent_data-t_hc_data
                         ASSIGNING <lfs_s_hc_data>.

    ENDIF.

    " -----------------------------------------------------------
    " Utilisation données
    " -----------------------------------------------------------

    me->ms_display_element-display_element-v_header_length = <lfs_s_hc_data>-hierarchy_header_length.

  ENDMETHOD.

  METHOD build_hierarchy_node.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_display_data TYPE tt_t_hc_data.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_display_data TYPE ts_hc_data.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
        lo_alv_tree_util TYPE REF TO zcl_gui_alv_tree_util.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_version_count TYPE i.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    REFRESH : me->ms_display_element-data-t_display_data.

    " -----------------------------------------------------------
    " Extraction des données à afficher
    " -----------------------------------------------------------

    " Création Instance Utilitaire Gestion ALV Tree
    CREATE OBJECT lo_alv_tree_util
      EXPORTING
        io_alv_tree = me->ms_display_element-display_element-o_alv_tree.

    " Récupération position première itération du Programme
    READ TABLE me->ms_persistent_data-t_hc_data
    WITH TABLE KEY repid      = me->mv_repid
                   system_key = me->ms_system
      ASSIGNING FIELD-SYMBOL(<lfs_s_hc_data>).
    IF sy-subrc NE 0.
      " Aucune données
      rv_subrc = 4.
      RETURN.

    ENDIF.

    " Parcours l'ensemble des Noeuds du Programme
    LOOP AT <lfs_s_hc_data>-t_hardcode ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode>).

      AT NEW version_guid.
        " A chaque changement de Version
        ""  --> Incrémentation compteur de Version
        ADD 1 TO lv_version_count.

      ENDAT.

      " Initialisation des données
      MOVE-CORRESPONDING <lfs_s_hardcode> TO ls_display_data.

      " Initialisation Icône Primaire
      ls_display_data-version_primary_icon = me->icon_version_primary_set( ls_display_data-version_primary ).

      " Initialisation Icône Range
      ls_display_data-attribute_as_range_icon = me->icon_attribute_range_set( ls_display_data-attribute_as_range ).

      " Initialisation Icône Code Source
      ls_display_data-attribute_as_source_code_icon = me->icon_attribute_source_code_set( ls_display_data-attribute_as_source_code ).

      " Ajout de l'entrée
      APPEND ls_display_data TO lt_display_data.

      CLEAR : ls_display_data.

    ENDLOOP.

    " -----------------------------------------------------------
    " Contrôle présence de données
    " -----------------------------------------------------------

    IF lt_display_data[] IS INITIAL.
      " Aucune données à afficher
      ""  --> Retourne code retour en erreur
      rv_subrc = 8.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Adapte les boutons visibles
    " -----------------------------------------------------------

    " Affiche (ou non) le bouton "Modifier Primarité" si Version > 1
    me->_toolbar_button_visibility_set( iv_primarity_visible = xsdbool( lv_version_count GT 1 ) ).

    " -----------------------------------------------------------
    " Alimentation automatique des données dans l'ALV Tree
    " -----------------------------------------------------------

    " Alimentation des Noeuds de l'ALV
    zcl_gui_alv_tree_util=>alv_tree_populate_auto(
      EXPORTING
        it_alv_tree_data  = lt_display_data
        it_hierarchy      = me->ms_display_element-display_element-t_hierarchy
      IMPORTING
        et_level_node_key = me->mt_level_node_key
      CHANGING
        co_alv_tree       = me->ms_display_element-display_element-o_alv_tree
    ).

  ENDMETHOD.

  METHOD build_display_element.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    IF NOT me->ms_display_element-display_element-o_ccontainer IS BOUND.
      " -----------------------------------------------------------
      " Création du Custom Container
      " -----------------------------------------------------------
      me->build_container( ).

    ENDIF.

    IF me->ms_display_element-display_element-t_fieldcatalog[] IS INITIAL.
      " -----------------------------------------------------------
      " Constitution du FieldCatalog
      " -----------------------------------------------------------
      me->build_fieldcatalog( ).

    ENDIF.

    IF me->ms_display_element-display_element-t_hierarchy[] IS INITIAL.
      " -----------------------------------------------------------
      " Constitution de la Hiérarchie d'affichage
      " -----------------------------------------------------------
      me->build_hierarchy( ).

    ENDIF.

    IF me->ms_display_element-display_element-s_hierarchy_header IS INITIAL.
      " -----------------------------------------------------------
      " Initialisation de l'entête de la Hiérarchie
      " -----------------------------------------------------------

      me->ms_display_element-display_element-s_hierarchy_header-width   =
        me->ms_display_element-display_element-v_header_length.
      me->ms_display_element-display_element-s_hierarchy_header-heading = text-hea.

    ENDIF.

    IF me->ms_display_element-display_element-t_toolbar_excluding[] IS INITIAL.
      " -----------------------------------------------------------
      " Initialisation des fonctionnalitées à exclures
      " -----------------------------------------------------------

      " Modification affichage des colonnes
      APPEND cl_gui_alv_tree=>mc_fc_calculate       TO me->ms_display_element-display_element-t_toolbar_excluding.
      APPEND cl_gui_alv_tree=>mc_fc_print_back      TO me->ms_display_element-display_element-t_toolbar_excluding.
      APPEND cl_gui_alv_tree=>mc_fc_current_variant TO me->ms_display_element-display_element-t_toolbar_excluding.

    ENDIF.

    " -----------------------------------------------------------
    " Création de l'ALV Tree
    " -----------------------------------------------------------

    me->build_alv_tree( ).

  ENDMETHOD.

  METHOD display.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Etend jusqu'au Noeud indiqué
    " -----------------------------------------------------------

    me->ms_display_element-display_element-o_alv_tree->expand_node(
      EXPORTING
        i_node_key          = cl_sedi_abs_nav_tree=>c_root_key
        i_level_count       = 10
        i_expand_subtree    = abap_true
      EXCEPTIONS                                          ##SUBRC_OK
        failed              = 1
        illegal_level_count = 2
        cntl_system_error   = 3
        node_not_found      = 4
        cannot_expand_leaf  = 5
        OTHERS              = 6
    ).

    " -----------------------------------------------------------
    " Affichage des paramètres
    " -----------------------------------------------------------

    " Appel de l'écran d'affichage
    CALL SCREEN 0101.

  ENDMETHOD.

  METHOD build_container.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    CLEAR : me->ms_display_element-display_element-o_ccontainer.

    " -----------------------------------------------------------
    " Création du Custom Container
    " -----------------------------------------------------------

    " Initialisation Custom Container
    CREATE OBJECT me->ms_display_element-display_element-o_ccontainer
      EXPORTING
        container_name              = me->ms_display_element-display_element-v_container_name
      EXCEPTIONS
        cntl_error                  = 1
        cntl_system_error           = 2
        create_error                = 3
        lifetime_error              = 4
        lifetime_dynpro_dynpro_link = 5
        OTHERS                      = 6.
    IF sy-subrc NE 0.
      " Une erreur est survenue

    ENDIF.

  ENDMETHOD.

  METHOD build_hierarchy.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_mandatory_component TYPE cgpl_field_names.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_hierarchy TYPE zcl_gui_alv_tree_util=>ts_hierarchy.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_node_level TYPE i.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    REFRESH : me->ms_display_element-display_element-t_hierarchy.

    " -----------------------------------------------------------
    " Initialisation des Attributs "obligatoire" à alimenter
    " -----------------------------------------------------------

    APPEND 'VERSION_ID'   TO lt_mandatory_component.        ##NO_TEXT
    APPEND 'VERSION_GUID' TO lt_mandatory_component.        ##NO_TEXT

    " -----------------------------------------------------------
    " Initialisation de la Hiérarchie
    " -----------------------------------------------------------

    " Version
    ADD 1 TO lv_node_level.
    CLEAR : ls_hierarchy.
    ls_hierarchy-fieldname                = 'VERSION_ID'.   ##NO_TEXT
    ls_hierarchy-node_level               = lv_node_level.
    ls_hierarchy-node_text_alpha_in       = abap_true.
    ls_hierarchy-node_layout-n_image      = text-ver.
    ls_hierarchy-node_layout-exp_image    = text-ver.
    ls_hierarchy-node_layout-isfolder     = abap_true.
    ls_hierarchy-node_level_key_fieldname = 'VERSION_GUID'. ##NO_TEXT
    APPEND 'VERSION_PRIMARY'               TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND 'VERSION_PRIMARY_ICON'          TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND LINES OF lt_mandatory_component TO ls_hierarchy-t_component_display.
    INSERT ls_hierarchy INTO TABLE me->ms_display_element-display_element-t_hierarchy.

    " Paramètre
    ADD 1 TO lv_node_level.
    CLEAR : ls_hierarchy.
    ls_hierarchy-fieldname                = 'PARAMETER_NAME'. ##NO_TEXT
    ls_hierarchy-node_level               = lv_node_level.
    ls_hierarchy-hide_if_null             = abap_true.
    ls_hierarchy-hide_if_empty            = abap_false.
    ls_hierarchy-node_text_alpha_in       = abap_true.
    ls_hierarchy-node_layout-n_image      = text-par.
    ls_hierarchy-node_layout-exp_image    = text-par.
    ls_hierarchy-node_layout-isfolder     = abap_true.
    ls_hierarchy-node_level_key_fieldname = 'PARAMETER_GUID'. ##NO_TEXT
    APPEND 'PARAMETER_NAME'                TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND 'PARAMETER_GUID'                TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND LINES OF lt_mandatory_component TO ls_hierarchy-t_component_display.
    APPEND 'VERSION_PRIMARY_ICON'          TO ls_hierarchy-t_component_excluded. ##NO_TEXT
    INSERT ls_hierarchy INTO TABLE me->ms_display_element-display_element-t_hierarchy.

    " Dernier Niveau Attribut
    ADD 1 TO lv_node_level.
    CLEAR : ls_hierarchy.
    ls_hierarchy-fieldname                = 'ATTRIBUTE_NAME'. ##NO_TEXT
    ls_hierarchy-node_level               = lv_node_level.
    ls_hierarchy-hide_if_null             = abap_true.
    ls_hierarchy-hide_if_empty            = abap_false.
    ls_hierarchy-node_text_alpha_in       = abap_true.
    ls_hierarchy-node_layout-n_image      = text-att.
    ls_hierarchy-node_layout-exp_image    = text-att.
    ls_hierarchy-node_level_key_fieldname = 'ATTRIBUTE_GUID_REGROUP'. ##NO_TEXT
    APPEND 'PARAMETER_GUID'                TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND 'ATTRIBUTE_NAME'                TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND 'ATTRIBUTE_GUID'                TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND 'ATTRIBUTE_GUID_REGROUP'        TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND 'ATTRIBUTE_KEY1'                TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND 'ATTRIBUTE_KEY2'                TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND 'ATTRIBUTE_KEY3'                TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND 'ATTRIBUTE_KEY4'                TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND 'ATTRIBUTE_AS_RANGE'            TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND 'ATTRIBUTE_AS_RANGE_ICON'       TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND 'ATTRIBUTE_AS_SOURCE_CODE'      TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND 'ATTRIBUTE_AS_SOURCE_CODE_ICON' TO ls_hierarchy-t_component_display. ##NO_TEXT
    APPEND LINES OF lt_mandatory_component TO ls_hierarchy-t_component_display.
    APPEND 'VERSION_PRIMARY_ICON'          TO ls_hierarchy-t_component_excluded. ##NO_TEXT
    INSERT ls_hierarchy INTO TABLE me->ms_display_element-display_element-t_hierarchy.

  ENDMETHOD.

  METHOD build_fieldcatalog.

***------------------------------------------------------------------***
**                           CONSTANTES                               **
***------------------------------------------------------------------***
    CONSTANTS :
      " Définition longeur d'affichage
      BEGIN OF lc_output_length,
        " Clef
        BEGIN OF key,
          key_standard TYPE lvc_outlen VALUE 30,
          key_compare  TYPE lvc_outlen VALUE 10,
        END OF key,
        " Icône
        BEGIN OF icon,
          icon_standard TYPE lvc_outlen VALUE 13,
          icon_compare  TYPE lvc_outlen VALUE 13,
        END OF icon,
      END OF   lc_output_length.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_fieldcat TYPE lvc_s_fcat.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_tabledescr  TYPE REF TO cl_abap_tabledescr,
      lo_structdescr TYPE REF TO cl_abap_structdescr.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    REFRESH : me->ms_display_element-display_element-t_fieldcatalog.

    " -----------------------------------------------------------
    " Constitution du FieldCatalog
    " -----------------------------------------------------------

    " Récupération description de la table
    lo_tabledescr ?= cl_abap_structdescr=>describe_by_data( me->ms_display_element-data-t_display_data ).

    " Récupération description ligne de la table
    lo_structdescr ?= lo_tabledescr->get_table_line_type( ).

    " Parcours l'ensemble des champs de la table
    LOOP AT cl_salv_data_descr=>read_structdescr( lo_structdescr ) ASSIGNING FIELD-SYMBOL(<lfs_s_dfies>).

      CLEAR : ls_fieldcat.

      " Initialisation des données
      MOVE-CORRESPONDING <lfs_s_dfies> TO ls_fieldcat.

      " Personnalisation
      CASE ls_fieldcat-fieldname.

        WHEN 'VERSION_GUID'                                 ##NO_TEXT
          OR 'PARAMETER_GUID'                               ##NO_TEXT
          OR 'ATTRIBUTE_GUID'                               ##NO_TEXT
          OR 'ATTRIBUTE_GUID_REGROUP'.                      ##NO_TEXT
          " GUID Interne
          ls_fieldcat-no_out = abap_true.

        WHEN 'REPID'                                        ##NO_TEXT
          OR 'VERSION_ID'                                   ##NO_TEXT
          OR 'PARAMETER_NAME'                               ##NO_TEXT
          OR 'ATTRIBUTE_NAME'.                              ##NO_TEXT
          " Répertoire / Version / Paramètre / Attribut
          ls_fieldcat-no_out = abap_true.

        WHEN 'VERSION_PRIMARY'.                             ##NO_TEXT
          " Version primaire
          ls_fieldcat-no_out = abap_true.

        WHEN 'VERSION_PRIMARY_ICON'.                        ##NO_TEXT
          " Version primaire Icône
          ls_fieldcat-icon      = abap_true.
          ls_fieldcat-outputlen = lc_output_length-icon-icon_standard.
          ls_fieldcat-scrtext_s = ls_fieldcat-scrtext_m = ls_fieldcat-scrtext_l = text-pri.

        WHEN 'ATTRIBUTE_AS_RANGE_ICON'.                     ##NO_TEXT
          " Icône - Range
          ls_fieldcat-icon      = abap_true.
          ls_fieldcat-outputlen = lc_output_length-icon-icon_standard.
          ls_fieldcat-scrtext_s = ls_fieldcat-scrtext_m = ls_fieldcat-scrtext_l = text-ran.

        WHEN 'ATTRIBUTE_AS_SOURCE_CODE_ICON'.               ##NO_TEXT
          " Icône - Code Source
          ls_fieldcat-icon      = abap_true.
          ls_fieldcat-outputlen = lc_output_length-icon-icon_standard.
          ls_fieldcat-scrtext_s = ls_fieldcat-scrtext_m = ls_fieldcat-scrtext_l = text-cos.

        WHEN 'PARAMETER'.                                   ##NO_TEXT
          " Paramètre

        WHEN 'ATTRIBUTE_KEY1'.                              ##NO_TEXT
          " Clef 1
          ls_fieldcat-outputlen = lc_output_length-key-key_standard.
          ls_fieldcat-scrtext_m = |{ ls_fieldcat-scrtext_m } 1|. ##NO_TEXT
          ls_fieldcat-scrtext_s = |{ ls_fieldcat-scrtext_s } 1|. ##NO_TEXT
          ls_fieldcat-scrtext_l = |{ ls_fieldcat-scrtext_l } 1|. ##NO_TEXT

        WHEN 'ATTRIBUTE_KEY2'.                              ##NO_TEXT
          " Clef 2
          ls_fieldcat-outputlen = lc_output_length-key-key_standard.
          ls_fieldcat-scrtext_m = |{ ls_fieldcat-scrtext_m } 2|. ##NO_TEXT
          ls_fieldcat-scrtext_s = |{ ls_fieldcat-scrtext_s } 2|. ##NO_TEXT
          ls_fieldcat-scrtext_l = |{ ls_fieldcat-scrtext_l } 2|. ##NO_TEXT

        WHEN 'ATTRIBUTE_KEY3'.                              ##NO_TEXT
          " Clef 3
          ls_fieldcat-outputlen = lc_output_length-key-key_standard.
          ls_fieldcat-scrtext_m = |{ ls_fieldcat-scrtext_m } 3|. ##NO_TEXT
          ls_fieldcat-scrtext_s = |{ ls_fieldcat-scrtext_s } 3|. ##NO_TEXT
          ls_fieldcat-scrtext_l = |{ ls_fieldcat-scrtext_l } 3|. ##NO_TEXT

        WHEN 'ATTRIBUTE_KEY4'.                              ##NO_TEXT
          " Clef 4
          ls_fieldcat-outputlen = lc_output_length-key-key_standard.
          ls_fieldcat-scrtext_m = |{ ls_fieldcat-scrtext_m } 4|. ##NO_TEXT
          ls_fieldcat-scrtext_s = |{ ls_fieldcat-scrtext_s } 4|. ##NO_TEXT
          ls_fieldcat-scrtext_l = |{ ls_fieldcat-scrtext_l } 4|. ##NO_TEXT

        WHEN 'ATTRIBUTE_SIGN'.                              ##NO_TEXT
          " Paramètre - Signe
          ls_fieldcat-no_out = abap_true.

        WHEN 'ATTRIBUTE_OPTI'.                              ##NO_TEXT
          " Paramètre - Opérateur
          ls_fieldcat-no_out = abap_true.

        WHEN 'ATTRIBUTE_LOW'.                               ##NO_TEXT
          " Paramètre - Valeur basse
          ls_fieldcat-no_out = abap_true.

        WHEN 'ATTRIBUTE_HIGH'.                              ##NO_TEXT
          " Paramètre - Valeur Haute
          ls_fieldcat-no_out = abap_true.

        WHEN 'ATTRIBUTE_AS_RANGE'.                          ##NO_TEXT
          " Paramètre Range
          ls_fieldcat-no_out = abap_true.

        WHEN 'ATTRIBUTE_AS_SOURCE_CODE'.                    ##NO_TEXT
          " Paramètre Code Source
          ls_fieldcat-no_out = abap_true.

        WHEN OTHERS.
          " Autres

      ENDCASE.

      " Ajout du champ
      APPEND ls_fieldcat TO me->ms_display_element-display_element-t_fieldcatalog.

    ENDLOOP.

  ENDMETHOD.

  METHOD build_toolbar.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
          lt_data_table TYPE ttb_button.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération instance Barre de Tâche
    " -----------------------------------------------------------

    " Récupération barre de tâche
    FREE : me->ms_display_element-display_element-o_toolbar.
    me->ms_display_element-display_element-o_alv_tree->get_toolbar_object(
      IMPORTING
        er_toolbar = me->ms_display_element-display_element-o_toolbar
    ).

    IF NOT me->ms_display_element-display_element-o_toolbar IS BOUND.
      " Pas de Toolbar
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    IF me->mv_read_only EQ abap_false.
      " -----------------------------------------------------------
      " Ajout des fonctionnalitées spécifiques d'édition
      " -----------------------------------------------------------

      " -----------------------------------------------------------
      " Bouton - Création
      " -----------------------------------------------------------

      APPEND LINES OF VALUE ttb_button(
        ( " Version - Créer
          TEXT      = text-cre
          ICON      = text-vcr
          FUNCTION  = lcl_main_tree_toolbar_event=>mc_function-version_create
          butn_type = cntb_btype_button
        )
        ( " Paramètre - Créer
          TEXT      = text-cre
          ICON      = text-par
          FUNCTION  = lcl_main_tree_toolbar_event=>mc_function-parameter_create
          butn_type = cntb_btype_button
        )
        ( " Attribut - Créer
          TEXT      = text-cre
          ICON      = text-att
          FUNCTION  = lcl_main_tree_toolbar_event=>mc_function-attribute_create
          butn_type = cntb_btype_button
        )
      ) TO lt_data_table.

      APPEND VALUE #( " Séparateur
        function  = 'SEP6'                         ##NO_TEXT
        butn_type = cntb_btype_sep
      ) TO lt_data_table.

      " -----------------------------------------------------------
      " Bouton - Modification
      " -----------------------------------------------------------

      APPEND LINES OF VALUE ttb_button(
        ( " Annuler
          TEXT      = text-tca
          ICON      = text-can
          FUNCTION  = lcl_main_tree_toolbar_event=>mc_function-cancel
          butn_type = cntb_btype_button
        )
        ( " Supprimer
          TEXT      = text-tde
          ICON      = text-del
          FUNCTION  = lcl_main_tree_toolbar_event=>mc_function-delete
          butn_type = cntb_btype_button
        )
        ( " Modifier
          TEXT      = text-tmo
          ICON      = TEXT-MOD
          FUNCTION  = lcl_main_tree_toolbar_event=>mc_function-modify
          butn_type = cntb_btype_button
        )
        ( " Copier
          TEXT      = text-tcy
          ICON      = text-cop
          FUNCTION  = lcl_main_tree_toolbar_event=>mc_function-copy
          butn_type = cntb_btype_button
        )
        ( " Rendre Primaire
          TEXT      = text-tsw
          ICON      = text-swi
          FUNCTION  = lcl_main_tree_toolbar_event=>mc_function-primary_set
          butn_type = cntb_btype_button
        )
      ) TO lt_data_table.

      APPEND VALUE #( "Séparateur
        function  = 'SEP5'                         ##NO_TEXT
        butn_type = cntb_btype_sep
      ) TO lt_data_table.

      " -----------------------------------------------------------
      " Bouton - Transports
      " -----------------------------------------------------------

      APPEND LINES OF VALUE ttb_button(
        ( " MàJ SHM
          TEXT      = text-tsh
          ICON      = text-shm
          FUNCTION  = lcl_main_tree_toolbar_event=>mc_function-update_shm
          butn_type = cntb_btype_button
        )
        ( " Séparateur
          FUNCTION  = 'SEP7'                         ##NO_TEXT
          butn_type = cntb_btype_sep
        )

*          ( "Transport
*            TEXT      = text-ttm
*            ICON      = text-trr
*            FUNCTION  = lcl_main_tree_toolbar_event=>mc_function-transport_menu
*            butn_type = cntb_btype_menu
*          )
        ( "Transport OT / Direct
          TEXT      = text-ttr
          ICON      = text-tra
          FUNCTION  = lcl_main_tree_toolbar_event=>mc_function-transport
          butn_type = cntb_btype_button
        )
        ( "Séparateur
          FUNCTION  = 'SEP8'                         ##NO_TEXT
          butn_type = cntb_btype_sep
        )
        ( "Import
          TEXT      = text-imp
          ICON      = text-iim
          FUNCTION  = lcl_main_tree_toolbar_event=>mc_function-import_local
          butn_type = cntb_btype_button
        )
        ( "Export
          TEXT      = text-exp
          ICON      = text-iie
          FUNCTION  = lcl_main_tree_toolbar_event=>mc_function-export_local
          butn_type = cntb_btype_button
        )
      ) TO lt_data_table.

    ELSE.
      " -----------------------------------------------------------
      " Affichage uniquement
      " -----------------------------------------------------------

      " Afficher
      lt_data_table = VALUE #(
       (
          function  = lcl_main_tree_toolbar_event=>mc_function-display
          icon      = text-idi
          butn_type = cntb_btype_button
          text      = text-dis
       )
      ).

    ENDIF.

    " -----------------------------------------------------------
    " Ajout des boutons
    " -----------------------------------------------------------

    " Ajout des boutons
    me->ms_display_element-display_element-o_toolbar->add_button_group(
      EXPORTING
        data_table       = lt_data_table
      EXCEPTIONS
        dp_error         = 1
        cntb_error_fcode = 2
        OTHERS           = 3
    ).
    IF sy-subrc EQ 0.
      " Masque le bouton d'annulation
      me->_toolbar_button_visibility_set( iv_cancel_visible = abap_false ).

    ENDIF.

    " -----------------------------------------------------------
    " Génération Toolbar - Evènement
    " -----------------------------------------------------------

    " Création instance Toolbar - Handler
    me->ms_display_element-display_element-o_toolbar_event =
      lcl_main_tree_toolbar_event=>factory( me->ms_display_element-display_element-o_toolbar ).

    " -----------------------------------------------------------
    " Génération Toolbar - Handler
    " -----------------------------------------------------------

    " Création instance Toolbar - Handler
    me->ms_display_element-display_element-o_toolbar_handler =
      lcl_main_tree_toolbar_handler=>factory(
        io_main_tree     = me
        io_toolbar_event = me->ms_display_element-display_element-o_toolbar_event
    ).

  ENDMETHOD.

  METHOD build_alv_tree.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    REFRESH : me->ms_display_element-data-t_display_data.

    IF me->ms_display_element-display_element-o_alv_tree IS BOUND.
      " Libération de l'ancienne instance
      me->ms_display_element-display_element-o_alv_tree->free( ).
      FREE : me->ms_display_element-display_element-o_alv_tree, me->ms_display_element-display_element-o_event.

    ENDIF.

    " -----------------------------------------------------------
    " Création de l'ALV
    " -----------------------------------------------------------

    CREATE OBJECT me->ms_display_element-display_element-o_alv_tree
      EXPORTING
        parent              = me->ms_display_element-display_element-o_ccontainer
        node_selection_mode = cl_gui_column_tree=>node_sel_mode_single
        item_selection      = abap_true
        no_html_header      = abap_true
        no_toolbar          = abap_false
      EXCEPTIONS ##SUBRC_OK
        OTHERS              = 1.
    IF sy-subrc NE 0.
      " Une erreur est survenue
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Génération instance Handler externe
    " -----------------------------------------------------------

    me->ms_display_element-display_element-o_event ?=
      lcl_main_tree_event=>factory(
        io_main         = me->mo_main
        io_alv_tree     = me->ms_display_element-display_element-o_alv_tree
        io_main_tree    = me
    ).

    " -----------------------------------------------------------
    " Préparation de l'Affichage
    " -----------------------------------------------------------

    me->ms_display_element-display_element-o_alv_tree->set_table_for_first_display(
      EXPORTING
        is_hierarchy_header  = me->ms_display_element-display_element-s_hierarchy_header
        it_toolbar_excluding = me->ms_display_element-display_element-t_toolbar_excluding
      CHANGING
        it_outtab            = me->ms_display_element-data-t_display_data
        it_fieldcatalog      = me->ms_display_element-display_element-t_fieldcatalog
    ).

    " -----------------------------------------------------------
    " Génération de la barre de Tâche
    " -----------------------------------------------------------

    me->build_toolbar( ).

  ENDMETHOD.

  METHOD icon_version_primary_set.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation de l'Icône de Primarité
    " -----------------------------------------------------------

    IF iv_version_primary EQ abap_true.
      " Version Primaire
      rv_icon_primary = text-vsp.

    ELSE.
      " Autre
      rv_icon_primary = text-vso.

    ENDIF.

  ENDMETHOD.

  METHOD icon_attribute_range_set.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation de l'Icône de Valeurs Multiple
    " -----------------------------------------------------------

    IF iv_attribute_as_range EQ abap_true.
      " Initialisation de l'icône
      rv_icon_range = text-ira.

    ENDIF.

  ENDMETHOD.

  METHOD icon_attribute_source_code_set.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation de l'Icône de Code Source
    " -----------------------------------------------------------

    IF iv_attribute_as_source_code EQ abap_true.
      " Initialisation de l'icône
      rv_icon_range = text-ics.

    ENDIF.

  ENDMETHOD.

  METHOD line_selected_get.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_selected_nodes TYPE lvc_t_nkey.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    CLEAR   : es_node_layout, ev_parent_node_key, ev_selected_node, ev_node_text, ev_subrc.
    REFRESH : et_item_layout.

    " -----------------------------------------------------------
    " Récupération de la ligne sélectionné
    " -----------------------------------------------------------

    me->ms_display_element-display_element-o_alv_tree->get_selected_nodes(
      CHANGING
        ct_selected_nodes = lt_selected_nodes
      EXCEPTIONS
        cntl_system_error = 1
        dp_error          = 2
        failed            = 3
        OTHERS            = 4
    ).
    IF sy-subrc NE 0
    OR lt_selected_nodes[] IS INITIAL.
      " Aucune ligne sélectionnée
      ""  --> Récupération ligne sélectionnée
      me->ms_display_element-display_element-o_alv_tree->get_selected_item(
        IMPORTING
          e_selected_node   = ev_selected_node
        EXCEPTIONS
          no_item_selection = 1
          cntl_system_error = 2
          failed            = 3
          OTHERS            = 4
      ).

    ELSE.
      " Ligne sélectionnée
      TRY.
          ""  --> Initialisation numéro de Noeud sélectionné
          ev_selected_node = lt_selected_nodes[ 1 ].

        CATCH cx_sy_itab_line_not_found. ##NO_HANDLER
          " Aucune entrée

      ENDTRY.

    ENDIF.

    IF sy-subrc         NE 0
    OR ev_selected_node IS INITIAL.
      ""  --> Affiche message avertissement
      ev_subrc = 4.
      MESSAGE w315(3g) DISPLAY LIKE 'W'.                    ##NO_TEXT
      RETURN.

    ENDIF.


    " Récupération des données de la ligne sélectionnée
    me->ms_display_element-display_element-o_alv_tree->get_outtab_line(
      EXPORTING
        i_node_key     = ev_selected_node
      IMPORTING
        e_node_text    = ev_node_text
        e_outtab_line  = rs_outtab_line
        es_node_layout = es_node_layout
        et_item_layout = et_item_layout
      EXCEPTIONS                                          ##SUBRC_OK
        node_not_found = 1
        OTHERS         = 2
    ).

    IF ev_parent_node_key IS SUPPLIED.
      " -----------------------------------------------------------
      " Détermination Noeud Parent
      " -----------------------------------------------------------
      IF NOT iv_parent_node_ref IS INITIAL.
        " Référence Noeud parent indiquée
        ""  --> Récupération champ de référence
        ASSIGN COMPONENT iv_parent_node_ref OF STRUCTURE rs_outtab_line
                                                      TO FIELD-SYMBOL(<lfs_node_level_key>).

        TRY.
            " Récupération du Noeud Parent correspondant à la ligne sélectionné
            ev_parent_node_key = me->mt_level_node_key[ node_level_key = <lfs_node_level_key>
                                                      ]-node_key.

          CATCH cx_sy_itab_line_not_found. ##NO_HANDLER
            " Impossible de déterminer le Noeud Parent

        ENDTRY.

      ELSE.
        " Récupération Noeud Parent direct
        me->ms_display_element-display_element-o_alv_tree->get_parent(
          EXPORTING
            i_node_key        = ev_selected_node
          IMPORTING
            e_parent_node_key = ev_parent_node_key
        ).

      ENDIF.

    ENDIF.

  ENDMETHOD.

  METHOD attribute_detail_get_ref.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    CLEAR : eot_source_code, eot_range.

    " -----------------------------------------------------------
    " Récupération des données de l'Attribut
    " -----------------------------------------------------------

    IF eot_range IS SUPPLIED.

      TRY.
          " Récupération valeurs de Range
          eot_range = REF #( me->ms_persistent_data-t_hc_data[ repid   = me->mv_repid
                                                               system  = me->ms_system-system
                                                               mandant = me->ms_system-mandant
                                          ]-t_attribute_range[ attribute_guid_regroup = iv_attribute_guid_regroup
                                                             ]-t_attribute_range_value ).

        CATCH cx_sy_itab_line_not_found.
          " Pas de range pour cette entrée
          CLEAR : eot_range.

      ENDTRY.

    ENDIF.


    IF eot_source_code IS SUPPLIED.
      TRY.
          " Récupération Code Source
          eot_source_code = REF #( me->ms_persistent_data-t_hc_data[ repid   = me->mv_repid
                                                                     system  = me->ms_system-system
                                                                     mandant = me->ms_system-mandant
                                                    ]-t_source_code[ attribute_guid_regroup = iv_attribute_guid_regroup
                                                                   ]-t_source_code ).

        CATCH cx_sy_itab_line_not_found.
          " Pas de Code Source pour cette entrée
          CLEAR : eot_source_code.

      ENDTRY.

    ENDIF.

  ENDMETHOD.

  METHOD node_add.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_outtab_line    TYPE ts_hc_data,
      ls_level_node_key TYPE zcl_gui_alv_tree_util=>ts_level_node_key.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Ajout d'un nouveau Noeud
    " -----------------------------------------------------------

    " Evènement modification
    RAISE EVENT submit_change.

    " Récupération paramètrage Hiérarchique
    READ TABLE me->ms_display_element-display_element-t_hierarchy
      WITH TABLE KEY node_level = iv_node_level
           ASSIGNING FIELD-SYMBOL(<lfs_s_hierarchy>).

    " Exploitation de la Hiérarchie appliquée
    zcl_gui_alv_tree_util=>hierarchy_usage(
      EXPORTING
        is_data           = is_data
        is_hierarchy      = <lfs_s_hierarchy>
      IMPORTING
        es_node_data      = ls_outtab_line
        ev_node_text      = ls_level_node_key-node_text
        ev_node_level_key = ls_level_node_key-node_level_key
    ).

    " Ajout du nouveau paramètre
    me->ms_display_element-display_element-o_alv_tree->add_node(
      EXPORTING
        i_relat_node_key     = iv_node_parent
        i_relationship       = cl_gui_column_tree=>relat_last_child
        is_outtab_line       = ls_outtab_line
        is_node_layout       = <lfs_s_hierarchy>-node_layout
        i_node_text          = CONV lvc_value( ls_level_node_key-node_text )
      IMPORTING
        e_new_node_key       = ls_level_node_key-node_key
      EXCEPTIONS                                          ##SUBRC_OK
        relat_node_not_found = 1
        node_not_found       = 2
        OTHERS               = 3
    ).

    " Ajout du nouveau Noeud dans la table des Niveaux de Nodes
    ls_level_node_key-parent_node_key = iv_node_parent.
    APPEND ls_level_node_key TO me->mt_level_node_key.

    " Retourne nouveau numéro de Noeud
    rv_node_key = ls_level_node_key-node_key.

    " -----------------------------------------------------------
    " Mise à jour de l'ALV Tree
    " -----------------------------------------------------------

    " Mise à jour de l'affichage
    me->ms_display_element-display_element-o_alv_tree->update_calculations( ).

    " -----------------------------------------------------------
    " Déploie les élèments du Noeud
    " -----------------------------------------------------------

    me->ms_display_element-display_element-o_alv_tree->expand_node(
      EXPORTING
        i_node_key       = iv_node_parent
        i_level_count    = 3
        i_expand_subtree = abap_true
      EXCEPTIONS
        OTHERS           = 0
    ).

  ENDMETHOD.

  METHOD attribute_detail_display.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lot_source_code           TYPE REF TO stringtab,
      lot_attribute_range_value TYPE REF TO zcl_hardcode_maintain=>tt_attribute_range_value_det.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_attribute_detail TYPE ts_attribute_detail_ref.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    CLEAR   : es_new_attribute_logical_key,  ev_cancel,
              es_new_attribute_logical_keyx, es_hardcode_data.
    REFRESH : et_attribute_range_value, er_ranges_value.

    " -----------------------------------------------------------
    " Initialisation des données
    " -----------------------------------------------------------

    " Initialisation données Détail
    ls_attribute_detail-attribute_name           = REF #( cs_hardcode_data-attribute_name ).
    ls_attribute_detail-attribute_key1           = REF #( cs_hardcode_data-attribute_key1 ).
    ls_attribute_detail-attribute_key2           = REF #( cs_hardcode_data-attribute_key2 ).
    ls_attribute_detail-attribute_key3           = REF #( cs_hardcode_data-attribute_key3 ).
    ls_attribute_detail-attribute_key4           = REF #( cs_hardcode_data-attribute_key4 ).
    ls_attribute_detail-attribute_as_range       = REF #( cs_hardcode_data-attribute_as_range ).
    ls_attribute_detail-attribute_as_source_code = REF #( cs_hardcode_data-attribute_as_source_code ).

    " Récupération Code Source et Range
    me->attribute_detail_get_ref(
      EXPORTING
        iv_attribute_guid_regroup = cs_hardcode_data-attribute_guid_regroup
      IMPORTING
        eot_range       = lot_attribute_range_value
        eot_source_code = lot_source_code
    ).
    IF NOT lot_attribute_range_value IS BOUND.
      " Aucun Range
      ""  --> Création nouvelle référence
      CREATE DATA lot_attribute_range_value.

    ENDIF.

    IF NOT lot_source_code IS BOUND.
      " Aucun Code Source
      ""  --> Création nouvelle référence
      CREATE DATA lot_source_code.

    ENDIF.

    " -----------------------------------------------------------
    " Affichage des données
    " -----------------------------------------------------------

    " Création instance Gestion Détail Attribut
    CREATE OBJECT me->mo_attribute_detail
      EXPORTING
        io_main      = me->mo_main
        io_main_tree = me
        iv_read_only = me->mv_read_only.

    " Affichage du Détail
    me->mo_attribute_detail->display(
      IMPORTING
        ev_cancel                     = ev_cancel
        es_new_attribute_logical_key  = es_new_attribute_logical_key
        es_new_attribute_logical_keyx = es_new_attribute_logical_keyx
      CHANGING
        cot_source_code               = lot_source_code
        cs_attribute_detail           = ls_attribute_detail
        cot_attribute_range_value     = lot_attribute_range_value
    ).

    " -----------------------------------------------------------
    " Initilisation données de retour
    " -----------------------------------------------------------

    IF er_ranges_value IS SUPPLIED.
      " Range de valeur
      er_ranges_value = CORRESPONDING #( lot_attribute_range_value->*
                                          MAPPING low    = attribute_low
                                                  sign   = attribute_sign
                                                  high   = attribute_high
                                                  option = attribute_opti
                                        ).

    ENDIF.

    IF et_source_code IS SUPPLIED.
      " Code Source
      et_source_code = lot_source_code->*.

    ENDIF.

    IF et_attribute_range_value IS SUPPLIED.
      " Attribut - Range de valeur
      et_attribute_range_value = lot_attribute_range_value->*.

    ENDIF.

  ENDMETHOD.

  METHOD _toolbar_button_visibility_set.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Modification propriété d'affichage des boutons
    " -----------------------------------------------------------

    IF  iv_cancel_visible IS SUPPLIED
    AND iv_cancel_visible NE abap_undefined.
      ""  --> Modification affichage bouton "Annuler"
      me->ms_display_element-display_element-o_toolbar->set_button_visible(
        EXPORTING
          visible          = iv_cancel_visible
          fcode            = lcl_main_tree_toolbar_event=>mc_function-cancel
        EXCEPTIONS
          OTHERS           = 0
      ).

    ENDIF.

    IF  iv_primarity_visible IS SUPPLIED
    AND iv_primarity_visible NE abap_undefined.
      ""  --> Modification affichage bouton "Primarité"
      me->ms_display_element-display_element-o_toolbar->set_button_visible(
        EXPORTING
          visible          = iv_primarity_visible
          fcode            = lcl_main_tree_toolbar_event=>mc_function-primary_set
        EXCEPTIONS
          OTHERS           = 0
      ).

    ENDIF.

  ENDMETHOD.

ENDCLASS.


*----------------------------------------------------------------------*
*       CLASS LCL_ATTRIBUTE_DETAIL IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_attribute_detail IMPLEMENTATION.

  METHOD constructor.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation des attributs
    " -----------------------------------------------------------

    " Attribut Classe
    me->mo_main      = io_main.
    me->mo_main_tree = io_main_tree.

    " Attribut lecture seule
    me->mv_read_only = iv_read_only.

    " Attribut Détail
    me->mo_attribute_detail = REF #( gs_attribute_detail ).

    " Instance Singleton
    DELETE lcl_attribute_detail=>mt_instance
     WHERE repid NE io_main_tree->mv_repid.
    READ TABLE lcl_attribute_detail=>mt_instance
    WITH TABLE KEY repid      = io_main_tree->mv_repid
                   system_key = io_main_tree->ms_system
                   ASSIGNING FIELD-SYMBOL(<lfs_s_instance>).
    IF sy-subrc NE 0.
      " Pas d'entrée
      INSERT VALUE #(
        repid      = io_main_tree->mv_repid
        system_key = io_main_tree->ms_system
      ) INTO TABLE lcl_attribute_detail=>mt_instance
         ASSIGNING <lfs_s_instance>.

    ENDIF.

    " Initialisation instance ST
    <lfs_s_instance>-instance = me.

  ENDMETHOD.

  METHOD display.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_attribute_detail TYPE ts_attribute_detail.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    CLEAR : me->mo_attribute_detail->cancel, ev_cancel.
    CLEAR : es_new_attribute_logical_keyx, es_new_attribute_logical_key.

    " -----------------------------------------------------------
    " Initialisation données générales
    " -----------------------------------------------------------

    " Initialisation propriété d'édition
    me->mo_attribute_detail->read_only = me->mv_read_only.

    " Initialisation propriété système
    lcl_attribute_detail=>mos_system = REF #( me->mo_main_tree->ms_system ).

    " Initialisation Attribut
    me->mo_attribute_detail->attribute_name           = cs_attribute_detail-attribute_name->*.
    me->mo_attribute_detail->attribute_key1           = cs_attribute_detail-attribute_key1->*.
    me->mo_attribute_detail->attribute_key2           = cs_attribute_detail-attribute_key2->*.
    me->mo_attribute_detail->attribute_key3           = cs_attribute_detail-attribute_key3->*.
    me->mo_attribute_detail->attribute_key4           = cs_attribute_detail-attribute_key4->*.
    me->mo_attribute_detail->attribute_as_range       = cs_attribute_detail-attribute_as_range->*.
    me->mo_attribute_detail->attribute_as_source_code = cs_attribute_detail-attribute_as_source_code->*.

    FREE : me->mor_ranges_value.
    CREATE DATA me->mor_ranges_value.
    IF cot_attribute_range_value IS BOUND.
      " Initialisation Range
      me->mor_ranges_value->* = CORRESPONDING #( cot_attribute_range_value->*
                                                  MAPPING low    = attribute_low
                                                          sign   = attribute_sign
                                                          high   = attribute_high
                                                          option = attribute_opti
                                               ).

    ELSE.
      " Création instance du Range
      CREATE DATA cot_attribute_range_value.

    ENDIF.

    FREE : me->mot_source_code.
    CREATE DATA me->mot_source_code.
    IF cot_source_code IS BOUND.
      " Initialisation Code Source
      me->mot_source_code->* = cot_source_code->*.

    ELSE.
      " Création instance du Code Source
      CREATE DATA cot_source_code.

    ENDIF.

    IF es_new_attribute_logical_key IS SUPPLIED.
      " Initialisation données avant modification
      ls_attribute_detail = me->mo_attribute_detail->*.

    ENDIF.

    " -----------------------------------------------------------
    " Affichage des données
    " -----------------------------------------------------------

    CALL SCREEN 0201 STARTING AT 20 10.

    " -----------------------------------------------------------
    " Une fois la saisie finie
    " -----------------------------------------------------------

    " Retourne le choix de l'utilisateur
    ev_cancel = me->mo_attribute_detail->cancel.

    IF me->mo_attribute_detail->cancel EQ abap_true.
      " L'utilisateur a annuler les modifications
      ""  --> Arrêt du traitement
      RETURN.

    ELSE.
      " L'utilisateur a confirmé les modifications
      ""  --> Pousse les modifications
      cs_attribute_detail-attribute_name->*           = me->mo_attribute_detail->attribute_name.
      cs_attribute_detail-attribute_key1->*           = me->mo_attribute_detail->attribute_key1.
      cs_attribute_detail-attribute_key2->*           = me->mo_attribute_detail->attribute_key2.
      cs_attribute_detail-attribute_key3->*           = me->mo_attribute_detail->attribute_key3.
      cs_attribute_detail-attribute_key4->*           = me->mo_attribute_detail->attribute_key4.
      cs_attribute_detail-attribute_as_range->*       = me->mo_attribute_detail->attribute_as_range.
      cs_attribute_detail-attribute_as_source_code->* = me->mo_attribute_detail->attribute_as_source_code.

      ""  --> Initialisation Range
      REFRESH : cot_attribute_range_value->*.
      cot_attribute_range_value->* = CORRESPONDING #( me->mor_ranges_value->*
                                           MAPPING attribute_low  = low
                                                   attribute_sign = sign
                                                   attribute_high = high
                                                   attribute_opti = option
                                     ).
      cs_attribute_detail-attribute_as_range->* = xsdbool( NOT cot_attribute_range_value->* IS INITIAL ).

      ""  --> Initialisation Code Source
      REFRESH : cot_source_code->*.
      cot_source_code->* = me->mot_source_code->*.

      IF es_new_attribute_logical_key IS SUPPLIED.
        ""  -->  Initialisation des données modifiées
        MOVE-CORRESPONDING me->mo_attribute_detail->* TO es_new_attribute_logical_key.
        es_new_attribute_logical_keyx-attribute_name = boolc( ls_attribute_detail-attribute_name NE me->mo_attribute_detail->attribute_name ).
        es_new_attribute_logical_keyx-attribute_key1 = boolc( ls_attribute_detail-attribute_key1 NE me->mo_attribute_detail->attribute_key1 ).
        es_new_attribute_logical_keyx-attribute_key2 = boolc( ls_attribute_detail-attribute_key2 NE me->mo_attribute_detail->attribute_key2 ).
        es_new_attribute_logical_keyx-attribute_key3 = boolc( ls_attribute_detail-attribute_key3 NE me->mo_attribute_detail->attribute_key3 ).
        es_new_attribute_logical_keyx-attribute_key4 = boolc( ls_attribute_detail-attribute_key4 NE me->mo_attribute_detail->attribute_key4 ).

      ENDIF.

    ENDIF.

  ENDMETHOD.

  METHOD instance_get.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    TRY.
        " -----------------------------------------------------------
        " Retourne instance
        " -----------------------------------------------------------

        " Retourne l'instance correspondante
        ro_instance = lcl_attribute_detail=>mt_instance[
          repid      = go_main->mo_hardcode_maintain->mv_repid
          system_key = lcl_attribute_detail=>mos_system->*
        ]-instance.

      CATCH cx_sy_itab_line_not_found. ##NO_HANDLER

    ENDTRY.

  ENDMETHOD.

  METHOD range_value_get.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    ror_range_value = me->mor_ranges_value.

  ENDMETHOD.

  METHOD source_code_get.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    rot_source_code = me->mot_source_code.

  ENDMETHOD.

ENDCLASS.


*----------------------------------------------------------------------*
*       CLASS LCL_MAIN_TREE_TOOLBAR_HANDLER IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main_tree_toolbar_handler IMPLEMENTATION.

  METHOD factory.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Génération instance
    " -----------------------------------------------------------

    " Retourne instance
    CREATE OBJECT ro_instance
      EXPORTING
        io_main_tree     = io_main_tree
        io_toolbar_event = io_toolbar_event.

  ENDMETHOD.

  METHOD constructor.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation Attributs
    " -----------------------------------------------------------

    me->mo_main_tree     = io_main_tree.
    me->mo_toolbar_event = io_toolbar_event.

    " -----------------------------------------------------------
    " Souscription évènements
    " -----------------------------------------------------------

    " Sur l'ALV
    SET HANDLER me->handler_submit_change              FOR me->mo_main_tree.

    " Sur le Gestionnaire d'Event de l'ALV
    SET HANDLER me->handler_on_hierarchy_edit      FOR me->mo_main_tree->ms_display_element-display_element-o_event.

    " Sur la barre d'outil
    SET HANDLER me->handler_on_copy                FOR me->mo_toolbar_event.
    SET HANDLER me->handler_on_cancel              FOR me->mo_toolbar_event.
    SET HANDLER me->handler_on_delete              FOR me->mo_toolbar_event.
    SET HANDLER me->handler_on_modify              FOR me->mo_toolbar_event.
    SET HANDLER me->handler_on_display             FOR me->mo_toolbar_event.
    SET HANDLER me->handler_on_transport           FOR me->mo_toolbar_event.
    SET HANDLER me->handler_on_update_shm          FOR me->mo_toolbar_event.
    SET HANDLER me->handler_on_export_local        FOR me->mo_toolbar_event.
    SET HANDLER me->handler_on_import_local        FOR me->mo_toolbar_event.
    SET HANDLER me->handler_on_version_create      FOR me->mo_toolbar_event.
    SET HANDLER me->handler_on_parameter_create    FOR me->mo_toolbar_event.
    SET HANDLER me->handler_on_attribute_create    FOR me->mo_toolbar_event.
    SET HANDLER me->handler_on_version_primary_set FOR me->mo_toolbar_event.

  ENDMETHOD.

  METHOD handler_on_delete.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_children TYPE lvc_t_nkey.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_selected_line       TYPE lcl_main_tree=>ts_hc_data,
      ls_new_version_primary TYPE lcl_main_tree=>ts_hc_data.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_cx_hardcode_maintain TYPE REF TO zcx_hardcode_maintain.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_subrc                TYPE sy-subrc,
      lv_answer               TYPE c LENGTH 1,
      lv_selected_node        TYPE lvc_nkey,
      lv_node_key_new_primary TYPE lvc_nkey.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération des données de la ligne sélectionnée
    " -----------------------------------------------------------

    ls_selected_line = me->mo_main_tree->line_selected_get(
      IMPORTING
        ev_subrc         = lv_subrc
        ev_selected_node = lv_selected_node
    ).
    IF NOT lv_subrc IS INITIAL.
      " Aucune lignée seléctionnée
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Contrôle avant suppression
    " -----------------------------------------------------------

    me->mo_main_tree->ms_display_element-display_element-o_alv_tree->get_children(
      EXPORTING
        i_node_key         = lv_selected_node
      IMPORTING
        et_children        = lt_children
      EXCEPTIONS                                          ##SUBRC_OK
        historic_error     = 1
        node_key_not_found = 2
        OTHERS             = 3
    ).
    IF lines( lt_children ) GT 1.
      " -----------------------------------------------------------
      " Avertissement de Suppression
      " -----------------------------------------------------------

      CALL FUNCTION 'POPUP_TO_CONFIRM'
        EXPORTING
          titlebar              = text-tde
          text_question         = text-tq1
          text_button_1         = text-oui
          icon_button_1         = text-oka
          text_button_2         = text-non
          icon_button_2         = text-can
          default_button        = '1' ##NO_TEXT
          display_cancel_button = abap_true
        IMPORTING
          answer                = lv_answer
        EXCEPTIONS
          text_not_found        = 1
          OTHERS                = 2.
      IF sy-subrc  NE 0
      OR lv_answer NE '1'.                                  ##NO_TEXT
        " L'utilisateur refuse la suppression
        ""  --> Arrêt du traitement
        RETURN.

      ENDIF.

    ENDIF.

    TRY.
        " -----------------------------------------------------------
        " Suppression des données internes
        " -----------------------------------------------------------

        IF NOT ls_selected_line-attribute_guid_regroup IS INITIAL.
          " Attribut
          ""  --> Suppression de l'Attribut
          me->mo_main_tree->mo_main->mo_hardcode_maintain->attribute_del( ls_selected_line-attribute_guid_regroup ).

        ELSEIF NOT ls_selected_line-parameter_guid IS INITIAL.
          " Paramètre
          ""  --> Suppression du Paramètre
          me->mo_main_tree->mo_main->mo_hardcode_maintain->parameter_del( ls_selected_line-parameter_guid ).

        ELSEIF NOT ls_selected_line-version_guid IS INITIAL.
          " Version
          ""  --> Suppression de la Version
          me->mo_main_tree->mo_main->mo_hardcode_maintain->version_del( ls_selected_line-version_guid ).

          ""  --> Récupération d'une autre Version
          LOOP AT me->mo_main_tree->ms_display_element-data-t_display_data ASSIGNING FIELD-SYMBOL(<lfs_s_display_data>)
                                                                               WHERE version_guid NE ls_selected_line-version_guid.
            " Entrée récupérée
            EXIT.

          ENDLOOP.
          IF <lfs_s_display_data> IS ASSIGNED.
            " Modification de la primarité
            TRY.
                " Récupération du Numéro de Noeud
                lv_node_key_new_primary = me->mo_main_tree->mt_level_node_key[ node_text = <lfs_s_display_data>-version_id ]-node_key.

                " Récupération des données du Noeud
                me->mo_main_tree->ms_display_element-display_element-o_alv_tree->get_outtab_line(
                  EXPORTING
                    i_node_key     = lv_node_key_new_primary
                  IMPORTING
                    e_outtab_line  = ls_new_version_primary
                  EXCEPTIONS                              ##SUBRC_OK
                    node_not_found = 1
                    OTHERS         = 2
                ).

                " Modification des données pour Activer la Primarité
                ls_new_version_primary-version_primary      = abap_true.
                ls_new_version_primary-version_primary_icon = me->mo_main_tree->icon_version_primary_set( ls_new_version_primary-version_primary ).

                " Modification du Noeud pour Activer la Primarité
                me->mo_main_tree->ms_display_element-display_element-o_alv_tree->change_node(
                  EXPORTING
                    i_node_key     = lv_node_key_new_primary
                    i_outtab_line  = ls_new_version_primary
                  EXCEPTIONS                              ##SUBRC_OK
                    node_not_found = 1
                    OTHERS         = 2
                ).

              CATCH cx_sy_itab_line_not_found. ##NO_HANDLER

            ENDTRY.

            " Recherche présence d'une autre Version
            LOOP AT me->mo_main_tree->ms_display_element-data-t_display_data
              TRANSPORTING NO FIELDS WHERE version_guid NE <lfs_s_display_data>-version_guid
                                       AND version_guid NE ls_selected_line-version_guid.
              " Autre Version atteinte
              EXIT.
            ENDLOOP.
            IF sy-subrc NE 0.
              " Aucune autre Version
              ""  --> Masque le bouton "Modifier Primarité"
              me->_button_visibility_set( iv_primarity_visible = abap_false ).

            ELSE.
              " Au moins une autre Version
              ""  --> Affiche le bouton "Modifier Primarité"
              me->_button_visibility_set( iv_primarity_visible = abap_true ).

            ENDIF.

          ENDIF.

        ENDIF.

      CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
        " Une erreur est survenue
        ""  --> Affiche le message d'erreur
        WHILE lo_cx_hardcode_maintain->previous IS BOUND.
          lo_cx_hardcode_maintain ?= lo_cx_hardcode_maintain->previous.
        ENDWHILE.
        MESSAGE ID lo_cx_hardcode_maintain->if_t100_message~t100key-msgid
              TYPE if_msg_output=>msgtype_success
            NUMBER lo_cx_hardcode_maintain->if_t100_message~t100key-msgno
              WITH lo_cx_hardcode_maintain->if_t100_message~t100key-attr1
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr2
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr3
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr4
           DISPLAY LIKE if_msg_output=>msgtype_error.

        ""  --> Arrêt du traitement
        RETURN.

    ENDTRY.

    " -----------------------------------------------------------
    " Suppression des lignes dans l'ALV
    " -----------------------------------------------------------

    " Evènement modification
    me->handler_submit_change( ).

    " Suppression arboresence
    me->mo_main_tree->ms_display_element-display_element-o_alv_tree->delete_subtree(
      EXPORTING
        i_node_key                = lv_selected_node
        i_update_parents_expander = abap_true
        i_update_parents_folder   = abap_true
      EXCEPTIONS                                          ##SUBRC_OK
        node_key_not_in_model     = 1
        OTHERS                    = 2
    ).

    " Modification de l'affichage
    me->mo_main_tree->ms_display_element-display_element-o_alv_tree->update_calculations( ).

  ENDMETHOD.

  METHOD handler_on_compare.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle données à sauvegarder
    " -----------------------------------------------------------

    IF me->mo_main_tree->mo_main->is_changed( ) EQ abap_true.
      " Données modifiées non persistée
      ""  --> Affiche popup confirmation
      IF lcl_main=>call_popup_confirm_data_loss( ) EQ abap_true.
        " Oui
        ""  --> Sauvegarde
        me->mo_main_tree->mo_main->save( ).

      ELSE.
        " Non
        ""  --> Affiche message action interompue
        MESSAGE w306(0t).
        RETURN.

      ENDIF.

    ENDIF.

    " -----------------------------------------------------------
    " Affichage écran de comparaison
    " -----------------------------------------------------------

    " Nettoie les élèments des précédents affichage
    CLEAR : gs_transport_target.

    " Navigue vers l'écran de Comparaison
    CALL SCREEN 0301.

  ENDMETHOD.

  METHOD handler_on_transport.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_answer TYPE c LENGTH 1.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle données à sauvegarder
    " -----------------------------------------------------------

    IF me->mo_main_tree->mo_main->is_changed( ) EQ abap_true.
      " Données modifiées non persistée
      ""  --> Affiche popup confirmation
      IF lcl_main=>call_popup_confirm_data_loss( ) EQ abap_true.
        " Oui
        ""  --> Sauvegarde
        me->mo_main_tree->mo_main->save( ).

      ELSE.
        " Non
        ""  --> Affiche message action interompue
        MESSAGE w306(0t).
        RETURN.

      ENDIF.

    ENDIF.

    " -----------------------------------------------------------
    " PopUp sélection Mode de Transport
    " -----------------------------------------------------------

    CALL FUNCTION 'POPUP_TO_CONFIRM'
      EXPORTING
        titlebar              = text-qct
        text_question         = text-tct
        text_button_1         = text-ctt
        icon_button_1         = text-tti
        text_button_2         = text-ctd
        icon_button_2         = text-tdi
        default_button        = '2'
        display_cancel_button = abap_true
      IMPORTING
        answer                = lv_answer
      EXCEPTIONS
        text_not_found        = 1
        OTHERS                = 2.
    IF sy-subrc NE 0 OR lv_answer EQ 'A'.##NO_TEXT
      " Erreur / Interruption par l'utilisateur
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Transport des Hardcodes
    " -----------------------------------------------------------

    " Transport Direct
    me->_hardcode_transport(
      iv_direct           = SWITCH #( lv_answer
                              WHEN '1' ##NO_TEXT THEN abap_false
                              ELSE abap_true
                            )
      iv_advanced_mode    = iv_advanced_mode
      is_transport_target = is_transport_target
    ).

  ENDMETHOD.

  METHOD _hardcode_transport.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Transport des Hardcodes
    " -----------------------------------------------------------

    IF iv_direct EQ abap_true.
      " Transport Direct
      rs_return = me->_hardcode_transport_direct(
        iv_advanced_mode    = iv_advanced_mode
        is_transport_target = is_transport_target
      ).

    ELSE.
      " Transport par OT
      rs_return = me->_hardcode_transport_tr( ).

    ENDIF.

  ENDMETHOD.

  METHOD _hardcode_transport_direct.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_hc_version     TYPE ztec_t_hc_vers_tt,
      lt_hc_attribute   TYPE ztec_t_hc_attr_tt,
      lt_hc_parameter   TYPE ztec_t_hc_param_tt,
      lt_hc_source_code TYPE ztec_t_hc_attribute_source.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
          ls_return TYPE bapiret2.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
          los_transport_target TYPE REF TO ts_transport_target.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
          lv_destination TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation Pointeur sur Zone de Travail
    " -----------------------------------------------------------

    " Initialisation Référence sur la zone de travail
    los_transport_target = REF #( gs_transport_target ).

    IF NOT is_transport_target IS INITIAL.
      " Système cible transmis
      ""  --> Utilisation de ces données
      los_transport_target->* = is_transport_target.

    ELSE.
      " Pas de cible définie
      ""  --> Initialisation valeur par défaut
      los_transport_target->mandant = sy-mandt.

      IF iv_advanced_mode EQ abap_true.
        " Navigue vers l'écran de Gestion Avancé
        CALL SCREEN 0301.

      ELSE.
        " Pop-Up sélection système cible / mandant cible
        ""  --> Affiche Ecran saisie
        CALL SCREEN 0302 STARTING AT 10 10.

      ENDIF.

    ENDIF.

    " -----------------------------------------------------------
    " Transport des Hardcodes - Sélection
    " -----------------------------------------------------------

    IF los_transport_target->cancel EQ abap_true
    OR (
             los_transport_target->transport_all  EQ abap_false
         AND los_transport_target->transport_node IS INITIAL
       ).
      " Annulation Transport // Pas de Noeud à transporter
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Transport des Hardcodes - Détermination Hardcode
    " -----------------------------------------------------------

    IF los_transport_target->transport_all EQ abap_true.
      " Transport de tous les Hardcodes
      me->mo_main_tree->mo_main->mo_hardcode_maintain->hardcode_data_get(
        IMPORTING
          et_version     = lt_hc_version
          et_parameter   = lt_hc_parameter
          et_attribute   = lt_hc_attribute
          et_source_code = lt_hc_source_code
      ).

    ELSE.
      " Récupération Hardcode à Transporter
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Modification données avant MàJ Système Cible
    " -----------------------------------------------------------

    " Version
    LOOP AT lt_hc_version ASSIGNING FIELD-SYMBOL(<lfs_s_hc_version>).

      <lfs_s_hc_version>-mandt = los_transport_target->mandant.

    ENDLOOP.

    " Paramètres
    LOOP AT lt_hc_parameter ASSIGNING FIELD-SYMBOL(<lfs_s_hc_parameter>).

      <lfs_s_hc_parameter>-mandt = los_transport_target->mandant.

    ENDLOOP.

    " Attributs
    LOOP AT lt_hc_attribute ASSIGNING FIELD-SYMBOL(<lfs_s_hc_attribute>).

      <lfs_s_hc_attribute>-mandt = los_transport_target->mandant.

    ENDLOOP.

    " -----------------------------------------------------------
    " Transport des Hardcodes
    " -----------------------------------------------------------

    IF los_transport_target->system IS INITIAL.
      " Détermination Déstination
      SELECT SINGLE logsys FROM t000 WHERE mandt EQ @sy-mandt INTO @lv_destination.
      IF sy-subrc NE 0 OR lv_destination IS INITIAL.
        " Pas de correspondance ou Vide
        ""  --> Construction Destination RFC
        lv_destination = |{ los_transport_target->system }CLNT{ los_transport_target->mandant }|. ##NO_TEXT

      ENDIF.

    ELSE.
      ""  --> Construction Destination RFC
      lv_destination = |{ los_transport_target->system }CLNT{ los_transport_target->mandant }|. ##NO_TEXT

    ENDIF.

    " Transport des Hardcodes
    CALL FUNCTION 'Z_HC_TRANSPORT'
      DESTINATION lv_destination
      EXPORTING
        iv_repid              = me->mo_main_tree->mv_repid
        it_hc_version         = lt_hc_version
        it_hc_parameter       = lt_hc_parameter
        it_hc_attribute       = lt_hc_attribute
        it_hc_source_code     = lt_hc_source_code
      IMPORTING
        es_return             = ls_return
      EXCEPTIONS
        message_error         = 1
        system_failure        = 2 MESSAGE ls_return-message
        communication_failure = 3 MESSAGE ls_return-message
        OTHERS                = 4.
    IF sy-subrc NE 0 OR ls_return-type CS 'AE'.             ##NO_TEXT
      " Une erreur est survenue
      ""  --> Affiche Message d'erreur
      MESSAGE ID sy-msgid TYPE if_msg_output=>msgtype_success
          NUMBER sy-msgno WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
                  DISPLAY LIKE if_msg_output=>msgtype_error.

    ELSE.
      " Hardcode transporté
      ""  --> Affichage message
      MESSAGE s709(zhardcode).

    ENDIF.

  ENDMETHOD.

  METHOD _hardcode_transport_tr.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Génération de l'Ordre de Transport
    " -----------------------------------------------------------

    " Génération de l'OT
    DATA(lv_order) = lcl_main=>transport_request_create( me->mo_main_tree->mv_repid ).

    IF lv_order IS INITIAL.
      " Une erreur est survenue
      ""  --> Affiche message action interompue
      MESSAGE w306(0t).
      RETURN.

    ELSE.
      " Affichage message de succès
      MESSAGE s708(zhardcode) WITH lv_order.

    ENDIF.

  ENDMETHOD.

  METHOD handler_on_update_shm.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle données à sauvegarder
    " -----------------------------------------------------------

    IF me->mo_main_tree->mo_main->is_changed( ) EQ abap_true.
      " Données modifiées non persistée
      ""  --> Affiche popup confirmation
      IF lcl_main=>call_popup_confirm_data_loss( ) EQ abap_true.
        " Oui
        ""  --> Sauvegarde
        me->mo_main_tree->mo_main->save( ).

      ELSE.
        " Non
        ""  --> Affiche message action interompue
        MESSAGE w306(0t).
        RETURN.

      ENDIF.

    ENDIF.

    TRY.
        " -----------------------------------------------------------
        " Mise à jour dans la SHM
        " -----------------------------------------------------------

        " Pousse les modifications (Sauvegardées) dans la SHM
        zcl_hardcode_shm=>get_instance(
          me->mo_main_tree->mo_main->mo_hardcode_maintain->mv_repid
        )->hardcode_reload( ).

        " Affiche message succès
        MESSAGE s601(zhardcode) WITH me->mo_main_tree->mo_main->mo_hardcode_maintain->mv_repid.

      CATCH zcx_hardcode_shm. ##NO_HANDLER
        " Erreur

    ENDTRY.

  ENDMETHOD.

  METHOD handler_on_export_local.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_path     TYPE string,
      lv_filename TYPE string,
      lv_fullpath TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF me->mo_main_tree->mo_main->is_changed( ) EQ abap_true.
      " Modification non persistée
      ""  --> PopUp confirmation
      IF lcl_main=>call_popup_confirm_data_loss( ) EQ abap_true.
        " Oui
        ""  --> Sauvegarde
        me->mo_main_tree->mo_main->save( ).

      ELSE.
        " Non
        ""  --> Affiche message action interompue
        MESSAGE w306(0t).
        RETURN.

      ENDIF.

    ENDIF.

    " -----------------------------------------------------------
    " PopUp Sélection du Fichier
    " -----------------------------------------------------------

    " Sélection du fichier
    cl_gui_frontend_services=>file_save_dialog(
      EXPORTING
        window_title        = CONV #( text-wte )
        default_extension   = zcl_hardcode_maintain=>mc_file_type_hardcode
        default_file_name   = |Hardcode_{ me->mo_main_tree->mv_repid }| ##NO_TEXT
*        file_filter         =     " File Type Filter Table
        prompt_on_overwrite = abap_true
      CHANGING
        filename            = lv_filename
        path                = lv_path
        fullpath            = lv_fullpath
      EXCEPTIONS
        OTHERS              = 1
    ).
    IF sy-subrc NE 0.
      " Fichier non déterminé
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    TRY.
        " -----------------------------------------------------------
        " Export des Hardcodes
        " -----------------------------------------------------------

        " Export des Hardcodes
        zcl_hardcode_file=>hardcode_download(
          iv_repid    = me->mo_main_tree->mv_repid
          iv_filename = lv_fullpath
        ).

      CATCH zcx_hardcode_maintain INTO DATA(lo_cx_hardcode).
        " Erreur Export Hardcodes
        ""  --> Affiche erreur
        WHILE lo_cx_hardcode->previous IS BOUND.
          lo_cx_hardcode ?= lo_cx_hardcode->previous.
        ENDWHILE.
        MESSAGE ID lo_cx_hardcode->if_t100_message~t100key-msgid
              TYPE if_msg_output=>msgtype_success
            NUMBER lo_cx_hardcode->if_t100_message~t100key-msgno
              WITH lo_cx_hardcode->if_t100_message~t100key-attr1
                   lo_cx_hardcode->if_t100_message~t100key-attr2
                   lo_cx_hardcode->if_t100_message~t100key-attr3
                   lo_cx_hardcode->if_t100_message~t100key-attr4
           DISPLAY LIKE if_msg_output=>msgtype_error.

        ""  --> Arrêt du traitement
        RETURN.

    ENDTRY.

  ENDMETHOD.

  METHOD handler_on_import_local.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_hardcode   TYPE zvtec_t_hc_tt,
      lt_file_table TYPE filetable.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_rc       TYPE i,
      lv_filename TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    IF NOT iv_filename IS INITIAL.
      " Nom du fichier transmis
      ""  --> Utilisation de ce nom
      lv_filename = iv_filename.

    ELSE.
      " -----------------------------------------------------------
      " PopUp Sélection du Fichier
      " -----------------------------------------------------------

      " Sélection du fichier
      cl_gui_frontend_services=>file_open_dialog(
        EXPORTING
          window_title            = CONV #( text-tsf )
          default_extension       = zcl_hardcode_maintain=>mc_file_type_hardcode
          default_filename        = |Hardcode_{ me->mo_main_tree->mv_repid }| ##NO_TEXT
          file_filter             = zcl_hardcode_maintain=>mc_file_type_hardcode
        CHANGING
          file_table              = lt_file_table
          rc                      = lv_rc
        EXCEPTIONS
          OTHERS                  = 1
      ).
      IF sy-subrc NE 0 OR lt_file_table[] IS INITIAL.
        " Fichier non déterminé
        ""  --> Arrêt du traitement
        RETURN.

      ENDIF.

      " Initialisation Nom du Fichier
      lv_filename = lt_file_table[ 1 ]-filename.

      TRY.
          " -----------------------------------------------------------
          " Contrôle
          " -----------------------------------------------------------

          IF zcl_hardcode_file=>hardcode_get_repid( lv_filename )
            NE me->mo_main_tree->mv_repid.
            " Hardcode en cours de traitement <> Hardcode fichier
            ""  --> Arrêt du traitement
            MESSAGE s503(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_error.
            RETURN.

          ENDIF.

        CATCH zcx_hardcode_maintain.
          " Erreur fichier
          ""  --> Arrêt du traitement
          MESSAGE s502(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_error.
          RETURN.

      ENDTRY.

    ENDIF.

    TRY.
        " -----------------------------------------------------------
        " Import des Hardcodes
        " -----------------------------------------------------------

        " Import des Hardcodes
        zcl_hardcode_file=>hardcode_upload(
          EXPORTING
            iv_commit            = xsdbool( NOT iv_filename IS INITIAL ) "Commit si depuis Ecran de sélection
            iv_filename          = lv_filename
          IMPORTING
            eo_hardcode_maintain = me->mo_main_tree->mo_main->mo_hardcode_maintain
        ).

        " Suppression données persistantes
        DELETE me->mo_main_tree->ms_persistent_data-t_hc_data
         WHERE repid      EQ me->mo_main_tree->mv_repid
           AND system_key EQ me->mo_main_tree->ms_system.

        " Evènement modification
        me->handler_submit_change( ).

        " Message succès
        MESSAGE s505(zhardcode) WITH me->mo_main_tree->mv_repid.

      CATCH zcx_hardcode_maintain INTO DATA(lo_cx_hardcode_maintain).
        " Erreur Export Hardcodes
        ""  --> Retourne l'erreur
        WHILE lo_cx_hardcode_maintain->previous IS BOUND.
          lo_cx_hardcode_maintain ?= lo_cx_hardcode_maintain->previous.
        ENDWHILE.
        MESSAGE ID lo_cx_hardcode_maintain->if_t100_message~t100key-msgid
              TYPE if_msg_output=>msgtype_success
            NUMBER lo_cx_hardcode_maintain->if_t100_message~t100key-msgno
              WITH lo_cx_hardcode_maintain->if_t100_message~t100key-attr1
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr2
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr3
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr4
           DISPLAY LIKE if_msg_output=>msgtype_error.

    ENDTRY.

    IF iv_filename IS INITIAL.
      " -----------------------------------------------------------
      " Rafrachissement des données affichées
      " -----------------------------------------------------------

      " Récupération Hardcode
      me->mo_main_tree->mo_main->mo_hardcode_maintain->hardcode_data_get(
        IMPORTING et_join = lt_hardcode
      ).

      " Modification dans l'ALV
      me->mo_main_tree->load_data( lt_hardcode ).

      " Reconstruction de l'ALV
      me->mo_main_tree->build_hierarchy_node( ).

      " -----------------------------------------------------------
      " Etend le premier noued
      " -----------------------------------------------------------

      " Déploie l'arborescence
      me->expand_first_node( ).

    ENDIF.

  ENDMETHOD.

  METHOD handler_on_attribute_create.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_source_code           TYPE stringtab,
      lr_ranges_value          TYPE tt_r_ranges,
      lt_attribute_range_value TYPE zcl_hardcode_maintain=>tt_attribute_range_value_det.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_source_code           TYPE lcl_main_tree=>ts_source_code,
      ls_selected_line         TYPE lcl_main_tree=>ts_hc_data,
      ls_attribute_range       TYPE lcl_main_tree=>ts_attribute_range,
      ls_hardcode_data_new     TYPE lcl_main_tree=>ts_hc_data,
      ls_attribute_logical_key TYPE zcl_hardcode_maintain=>ts_attribute_logical_key.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_cx_hardcode_maintain TYPE REF TO zcx_hardcode_maintain.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_cancel          TYPE flag,
      lv_subrc           TYPE sy-subrc,
      lv_parent_node_key TYPE lvc_nkey.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
      <lfs_t_source_code>     TYPE lcl_main_tree=>tt_source_code,
      <lfs_t_attribute_range> TYPE lcl_main_tree=>tt_attribute_range.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération des données de la ligne sélectionnée
    " -----------------------------------------------------------

    " Récupération données Noeud sélectionné
    ls_selected_line = me->mo_main_tree->line_selected_get(
      EXPORTING
        iv_parent_node_ref = me->mo_main_tree->ms_display_element-display_element-t_hierarchy[
                              node_level = 2 ]-node_level_key_fieldname
      IMPORTING
        ev_subrc           = lv_subrc
        ev_parent_node_key = lv_parent_node_key
    ).
    IF NOT lv_subrc IS INITIAL.
      " Aucune lignée seléctionnée
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Contrôle cohérence de la ligne sélectionnée
    " -----------------------------------------------------------

    IF ls_selected_line-parameter_guid IS INITIAL.
      " Pas de GUID de Paramètre // Il s'agit d'une ligne "Version"
      ""  --> Affiche message d'erreur
      MESSAGE s304(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Initialisation données de base
    " -----------------------------------------------------------

    " Réinitialisation données Attributs
    CLEAR : ls_selected_line-attribute_name,           ls_selected_line-attribute_key1,
            ls_selected_line-attribute_key2,           ls_selected_line-attribute_key3,
            ls_selected_line-attribute_as_range,       ls_selected_line-attribute_key4,
            ls_selected_line-attribute_as_range_icon,  ls_selected_line-attribute_guid_regroup,
            ls_selected_line-attribute_as_source_code, ls_selected_line-attribute_as_source_code_icon.

    " Initialisation des données
    MOVE-CORRESPONDING ls_selected_line TO ls_hardcode_data_new.

    " -----------------------------------------------------------
    " Pop-Up saisi du Nom
    " -----------------------------------------------------------

    ls_hardcode_data_new-attribute_name = me->mo_main_tree->mo_main->call_popup_input_simple(
      EXPORTING
        iv_title = text-nat
      IMPORTING
        ev_subrc = lv_subrc
    ).
    IF NOT lv_subrc IS INITIAL.
      " Une erreur est survenue
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Pop-Up saisie des données
    " -----------------------------------------------------------

    me->mo_main_tree->attribute_detail_display(
      IMPORTING
        ev_cancel                = lv_cancel
        et_source_code           = lt_source_code
        er_ranges_value          = lr_ranges_value
        et_attribute_range_value = lt_attribute_range_value
      CHANGING
        cs_hardcode_data         = ls_hardcode_data_new
    ).
    IF  lv_cancel EQ abap_true
    AND ls_hardcode_data_new-attribute_guid_regroup IS INITIAL.
      " La création de l'Attribut a été annulé
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    TRY.
        " -----------------------------------------------------------
        " Création de l'Attribut
        " -----------------------------------------------------------

        " Initialisation données
        MOVE-CORRESPONDING ls_hardcode_data_new TO ls_attribute_logical_key.

        " Création du Nouvelle Attribut
        ls_hardcode_data_new-attribute_guid_regroup = me->mo_main_tree->mo_main->mo_hardcode_maintain->attribute_add(
            iv_parameter_guid        = ls_selected_line-parameter_guid
            is_attribute_logical_key = ls_attribute_logical_key
            ir_ranges_value          = lr_ranges_value
            it_source_code           = lt_source_code
        ).

        " -----------------------------------------------------------
        " Ajout du Noeud
        " -----------------------------------------------------------

        IF ls_hardcode_data_new-attribute_as_range EQ abap_true.
          " Initialisation Icône
          ls_hardcode_data_new-attribute_as_range_icon = text-ira.

        ENDIF.

        IF ls_hardcode_data_new-attribute_as_source_code EQ abap_true.
          " Initialisation Icône
          ls_hardcode_data_new-attribute_as_source_code_icon = text-ics.

        ENDIF.

        " Ajout du Noeud
        me->mo_main_tree->node_add(
          is_data        = ls_hardcode_data_new
          iv_node_level  = lcl_main_tree=>mc_node_level-attribute
          iv_node_parent = lv_parent_node_key
        ).

        " -----------------------------------------------------------
        " Alimentation données de l'Attribut
        " -----------------------------------------------------------

        " Récupération table des Ranges du Programme
        ASSIGN me->mo_main_tree->ms_persistent_data-t_hc_data[
            repid      = me->mo_main_tree->mv_repid
            system_key = me->mo_main_tree->ms_system
          ]-t_attribute_range TO <lfs_t_attribute_range>.
        IF sy-subrc EQ 0.
          " Récupération entrée correspondant à l'Attribut
          READ TABLE <lfs_t_attribute_range>
          WITH TABLE KEY attribute_guid_regroup = ls_hardcode_data_new-attribute_guid_regroup
               ASSIGNING FIELD-SYMBOL(<lfs_s_attribute_range>).
          IF sy-subrc NE 0.
            " Aucune entrée existante pour cet Attribut
            ls_attribute_range-attribute_guid_regroup = ls_hardcode_data_new-attribute_guid_regroup.
            INSERT ls_attribute_range INTO TABLE <lfs_t_attribute_range> ASSIGNING <lfs_s_attribute_range>.

          ENDIF.

          " Modification valeurs des ranges
          <lfs_s_attribute_range>-t_attribute_range_value = lt_attribute_range_value.

        ENDIF.

        " Récupération table des Codes Sources du Programme
        ASSIGN me->mo_main_tree->ms_persistent_data-t_hc_data[ repid      = me->mo_main_tree->mv_repid
                                                               system_key = me->mo_main_tree->ms_system
                                                             ]-t_source_code TO <lfs_t_source_code>.
        IF sy-subrc EQ 0.
          " Récupération entrée correspondant à l'Attribut
          READ TABLE <lfs_t_source_code>
          WITH TABLE KEY attribute_guid_regroup = ls_hardcode_data_new-attribute_guid_regroup
               ASSIGNING FIELD-SYMBOL(<lfs_s_source_code>).
          IF sy-subrc NE 0.
            " Aucune entrée existante pour cet Attribut
            ls_source_code-attribute_guid_regroup = ls_hardcode_data_new-attribute_guid_regroup.
            INSERT ls_source_code INTO TABLE <lfs_t_source_code> ASSIGNING <lfs_s_source_code>.

          ENDIF.

          " Modification Code Source
          <lfs_s_source_code>-t_source_code = lt_source_code.

        ENDIF.

      CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
        " Une erreur est survenue
        ""  --> Affichage de l'erreur
        WHILE lo_cx_hardcode_maintain->previous IS BOUND.
          lo_cx_hardcode_maintain ?= lo_cx_hardcode_maintain->previous.
        ENDWHILE.
        MESSAGE ID lo_cx_hardcode_maintain->if_t100_message~t100key-msgid
              TYPE if_msg_output=>msgtype_success
            NUMBER lo_cx_hardcode_maintain->if_t100_message~t100key-msgno
              WITH lo_cx_hardcode_maintain->if_t100_message~t100key-attr1
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr2
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr3
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr4
           DISPLAY LIKE if_msg_output=>msgtype_error.

    ENDTRY.

  ENDMETHOD.

  METHOD handler_on_version_primary_set.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_selected_line       TYPE lcl_main_tree=>ts_hc_data,
      ls_old_version_primary TYPE lcl_main_tree=>ts_hc_data.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_cx_hardcode_maintain TYPE REF TO zcx_hardcode_maintain.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_subrc                TYPE sy-subrc,
      lv_selected_node        TYPE lvc_nkey,
      lv_node_key_old_primary TYPE lvc_nkey.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération des données de la ligne sélectionnée
    " -----------------------------------------------------------

    " Récupération des données de la ligne sélectionnée
    ls_selected_line = me->mo_main_tree->line_selected_get(
      IMPORTING
        ev_subrc         = lv_subrc
        ev_selected_node = lv_selected_node
    ).
    IF NOT lv_subrc IS INITIAL.
      " Aucune lignée seléctionnée
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Détermination Type de Noeud
    " -----------------------------------------------------------

    IF NOT ls_selected_line-attribute_guid_regroup IS INITIAL
    OR NOT ls_selected_line-parameter_guid IS INITIAL.
      " Il ne s'agit pas d'une ligne "Version"
      ""  --> Affichage message d'erreur
      MESSAGE s002(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Récupération de l'ancien Noeud Primaire
    " -----------------------------------------------------------

    TRY.
        " Récupération du Numéro de Noeud
        lv_node_key_old_primary = me->mo_main_tree->mt_level_node_key[
          node_text = me->mo_main_tree->ms_display_element-data-t_display_data[
            version_primary = abap_true ]-version_id
        ]-node_key.

        " Récupération des données du Noeud
        me->mo_main_tree->ms_display_element-display_element-o_alv_tree->get_outtab_line(
          EXPORTING
            i_node_key     = lv_node_key_old_primary
          IMPORTING
            e_outtab_line  = ls_old_version_primary
          EXCEPTIONS                                      ##SUBRC_OK
            node_not_found = 1
            OTHERS         = 2
        ).

      CATCH cx_sy_itab_line_not_found. ##NO_HANDLER

    ENDTRY.

    " -----------------------------------------------------------
    " Modification des données
    " -----------------------------------------------------------

    IF ls_selected_line EQ ls_old_version_primary.
      " Ligne sélectionnée = Ancienne Ligne primaire
      ""  --> Récupération de la première Version
      lv_selected_node = CONV lvc_nkey( cl_sedi_abs_nav_tree=>c_root_key ).
      me->mo_main_tree->ms_display_element-display_element-o_alv_tree->get_outtab_line(
        EXPORTING
          i_node_key     = lv_selected_node
        IMPORTING
          e_outtab_line  = ls_selected_line
        EXCEPTIONS                                        ##SUBRC_OK
          node_not_found = 1
          OTHERS         = 3
      ).

    ENDIF.

    " Modification des données pour Activer la Primarité
    ls_selected_line-version_primary      = abap_true.
    ls_selected_line-version_primary_icon = me->mo_main_tree->icon_version_primary_set(
      ls_selected_line-version_primary
    ).

    " Modification des données pour Désactiver la Primarité
    ls_old_version_primary-version_primary      = abap_false.
    ls_old_version_primary-version_primary_icon = me->mo_main_tree->icon_version_primary_set(
      ls_old_version_primary-version_primary
    ).

    " -----------------------------------------------------------
    " Modification du Noeud
    " -----------------------------------------------------------

    TRY.
        " Modification de la Primarité
        me->mo_main_tree->mo_main->mo_hardcode_maintain->version_primary_set(
          iv_version_guid = ls_selected_line-version_guid
        ).

        " Modification du Noeud pour Activer la Primarité
        me->mo_main_tree->ms_display_element-display_element-o_alv_tree->change_node(
          EXPORTING
            i_node_key     = lv_selected_node
            i_outtab_line  = ls_selected_line
          EXCEPTIONS                                      ##SUBRC_OK
            node_not_found = 1
            OTHERS         = 2
        ).

        " Modification du Noeud pour Désactiver la Primarité
        me->mo_main_tree->ms_display_element-display_element-o_alv_tree->change_node(
          EXPORTING
            i_node_key     = lv_node_key_old_primary
            i_outtab_line  = ls_old_version_primary
          EXCEPTIONS ##SUBRC_OK
            node_not_found = 1
            OTHERS         = 2
        ).

        " Evènement modification
        me->handler_submit_change( ).

        " Modification de l'affichage
        me->mo_main_tree->ms_display_element-display_element-o_alv_tree->update_calculations( ).

      CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
        " Une erreur est survenue
        ""  --> Affichage de l'erreur
        WHILE lo_cx_hardcode_maintain->previous IS BOUND.
          lo_cx_hardcode_maintain ?= lo_cx_hardcode_maintain->previous.
        ENDWHILE.
        MESSAGE ID lo_cx_hardcode_maintain->if_t100_message~t100key-msgid
              TYPE if_msg_output=>msgtype_success
            NUMBER lo_cx_hardcode_maintain->if_t100_message~t100key-msgno
              WITH lo_cx_hardcode_maintain->if_t100_message~t100key-attr1
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr2
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr3
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr4
           DISPLAY LIKE if_msg_output=>msgtype_error.

    ENDTRY.

  ENDMETHOD.

  METHOD handler_on_cancel.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_answer TYPE c.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle présence de modification
    " -----------------------------------------------------------

    IF me->mo_main_tree->mo_main->is_changed( ) EQ abap_false.
      " Rien à annuler
      ""  --> Masque le bouton "Annuler"
      me->_button_visibility_set( iv_cancel_visible = abap_false ).

      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Confirme auprès de l'utilisateur
    " -----------------------------------------------------------

    " Données modifiées non persistée
    ""  --> Affiche popup confirmation
    CALL FUNCTION 'POPUP_TO_CONFIRM'
      EXPORTING
        titlebar              = text-dlo
        text_question         = text-qca
        text_button_1         = text-oui
        icon_button_1         = text-oka
        text_button_2         = text-non
        icon_button_2         = text-can
        display_cancel_button = abap_false
      IMPORTING
        answer                = lv_answer
      EXCEPTIONS
        text_not_found        = 1
        OTHERS                = 2.
    IF sy-subrc NE 0 OR lv_answer NE '1'.                   ##NO_TEXT
      " Erreur affichage || Annulation
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Annulation des modifications
    " -----------------------------------------------------------

    " Libère les éléments d'affichage
    me->mo_main_tree->free( ).

    " Enregistre Evènement d'affichage
    me->mo_main_tree->mo_main->event_register( lcl_main_tree_toolbar_event=>mc_function-display ).

    " Retourne à l'écran de sélection
    LEAVE TO SCREEN 0.

  ENDMETHOD.

  METHOD handler_submit_change.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Changement affichage bouton
    " -----------------------------------------------------------

    " Affiche le bouton "Annuler"
    me->_button_visibility_set( iv_cancel_visible = abap_true ).

  ENDMETHOD.

  METHOD handler_on_copy.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_children                   TYPE lvc_t_nkey,
      lt_attribute_data             TYPE ztec_t_hc_attr_tt,
      lt_parameter_data             TYPE ztec_t_hc_param_tt,
      lt_attribute_range_data       TYPE zcl_hardcode_maintain=>tt_attribute_range_data,
      lt_attribute_source_code_data TYPE zcl_hardcode_maintain=>tt_attribute_source_code_data.

    DATA :
      lot_source_code           TYPE REF TO stringtab,
      lot_attribute_range_value TYPE REF TO zcl_hardcode_maintain=>tt_attribute_range_value_det.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_source_code       TYPE lcl_main_tree=>ts_source_code,
      ls_version_data      TYPE ztec_t_hc_vers,
      ls_selected_line     TYPE lcl_main_tree=>ts_hc_data,
      ls_attribute_data    TYPE ztec_t_hc_attr,
      ls_parameter_data    TYPE ztec_t_hc_param,
      ls_attribute_range   TYPE lcl_main_tree=>ts_attribute_range,
      ls_hardcode_data_new TYPE lcl_main_tree=>ts_hc_data.

    DATA :
      ls_attribute_detail           TYPE ts_attribute_detail_ref,
      ls_attribute_range_data       TYPE zcl_hardcode_maintain=>ts_attribute_range_data,
      ls_new_attribute_logical_key  TYPE zcl_hardcode_maintain=>ts_attribute_logical_key,
      ls_new_attribute_logical_keyx TYPE zcl_hardcode_maintain=>ts_attribute_logical_keyx,
      ls_attribute_source_code_data TYPE zcl_hardcode_maintain=>ts_attribute_source_code_data.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_cx_hardcode_maintain TYPE REF TO zcx_hardcode_maintain.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_subrc              TYPE sy-subrc,
      lv_cancel             TYPE c LENGTH 1,
      lv_name_new           TYPE string,
      lv_selected_node      TYPE lvc_nkey,
      lv_parent_node_key    TYPE lvc_nkey,
      lv_version_node_key   TYPE lvc_nkey,
      lv_parameter_node_key TYPE lvc_nkey.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
      <lfs_s_source_code>     TYPE lcl_main_tree=>ts_source_code,
      <lfs_t_source_code>     TYPE lcl_main_tree=>tt_source_code,
      <lfs_s_attribute_range> TYPE lcl_main_tree=>ts_attribute_range,
      <lfs_t_attribute_range> TYPE lcl_main_tree=>tt_attribute_range.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération des données de la ligne sélectionnée
    " -----------------------------------------------------------

    ls_selected_line = me->mo_main_tree->line_selected_get(
      IMPORTING
        ev_subrc           = lv_subrc
        ev_selected_node   = lv_selected_node
        ev_parent_node_key = lv_parent_node_key
    ).
    IF NOT lv_subrc IS INITIAL.
      " Aucune lignée seléctionnée
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Contrôle avant suppression
    " -----------------------------------------------------------

    me->mo_main_tree->ms_display_element-display_element-o_alv_tree->get_children(
      EXPORTING
        i_node_key         = lv_selected_node
      IMPORTING
        et_children        = lt_children
      EXCEPTIONS ##SUBRC_OK
        historic_error     = 1
        node_key_not_found = 2
        OTHERS             = 3
    ).

    " -----------------------------------------------------------
    " Saisie du nouveau Nom
    " -----------------------------------------------------------

    IF NOT ls_selected_line-attribute_guid_regroup IS INITIAL.
      " Attribut
      lv_name_new = CONV #(
        me->mo_main_tree->mo_main->call_popup_input_simple(
          iv_title = text-tcy
          iv_text  = ls_selected_line-attribute_name
      ) ).

      " Initialisation des données pour Affichage gestion Nouvel Attribut
      CREATE DATA ls_attribute_detail-attribute_name.
      ls_attribute_detail-attribute_name->* = lv_name_new.
      CREATE DATA ls_attribute_detail-attribute_key1.
      ls_attribute_detail-attribute_key1->* = ls_selected_line-attribute_key1.
      CREATE DATA ls_attribute_detail-attribute_key2.
      ls_attribute_detail-attribute_key2->* = ls_selected_line-attribute_key2.
      CREATE DATA ls_attribute_detail-attribute_key3.
      ls_attribute_detail-attribute_key3->* = ls_selected_line-attribute_key3.
      CREATE DATA ls_attribute_detail-attribute_key4.
      ls_attribute_detail-attribute_key4->* = ls_selected_line-attribute_key4.
      CREATE DATA ls_attribute_detail-attribute_as_range.
      ls_attribute_detail-attribute_as_range->* = ls_selected_line-attribute_as_range.
      CREATE DATA ls_attribute_detail-attribute_as_source_code.
      ls_attribute_detail-attribute_as_source_code->* = ls_selected_line-attribute_as_source_code.

      " Récupération Détail de l'Attribut
      me->mo_main_tree->attribute_detail_get_ref(
        EXPORTING
          iv_attribute_guid_regroup = ls_selected_line-attribute_guid_regroup
        IMPORTING
          eot_range                 = DATA(lot_range_origin)
          eot_source_code           = DATA(lot_source_code_origin)
       ).

      " Initialisation Range
      CREATE DATA lot_attribute_range_value.
      IF lot_range_origin IS BOUND.
        lot_attribute_range_value->* = lot_range_origin->*.

      ENDIF.

      " Initialisation Code Source
      CREATE DATA lot_source_code.
      IF lot_source_code_origin IS BOUND.
        lot_source_code->* = lot_source_code_origin->*.

      ENDIF.

      IF NOT me->mo_main_tree->mo_attribute_detail IS BOUND.
        " Création instance Gestion Détail
        CREATE OBJECT me->mo_main_tree->mo_attribute_detail
          EXPORTING
            io_main      = me->mo_main_tree->mo_main
            io_main_tree = me->mo_main_tree.

      ENDIF.

      " Affichage outil saisi des données
      me->mo_main_tree->mo_attribute_detail->display(
        IMPORTING
          ev_cancel                     = lv_cancel
          es_new_attribute_logical_key  = ls_new_attribute_logical_key
          es_new_attribute_logical_keyx = ls_new_attribute_logical_keyx
        CHANGING
          cot_source_code               = lot_source_code
          cs_attribute_detail           = ls_attribute_detail
          cot_attribute_range_value     = lot_attribute_range_value
      ).
      IF lv_cancel EQ abap_true.
        " L'utilisateur à annulé les modifications
        ""  --> Arrêt du traitement
        RETURN.

      ENDIF.

    ELSEIF NOT ls_selected_line-parameter_guid IS INITIAL.
      " Paramètre
      lv_name_new = me->mo_main_tree->mo_main->call_popup_input_simple(
        iv_title = text-tcy
        iv_text  = ls_selected_line-parameter_name
      ).

    ELSEIF NOT ls_selected_line-version_guid IS INITIAL.
      " Version
      lv_name_new = me->mo_main_tree->mo_main->call_popup_input_simple(
        iv_title = text-tcy
        iv_text  = ls_selected_line-version_id
      ).

    ENDIF.
    IF lv_name_new IS INITIAL.
      " Pas de Nom saisi
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    TRY.
        " -----------------------------------------------------------
        " Copie des Hardcodes
        " -----------------------------------------------------------

        IF NOT ls_selected_line-attribute_guid_regroup IS INITIAL.
          " Attribut
          ""  --> Copie de l'Attribut
          me->mo_main_tree->mo_main->mo_hardcode_maintain->attribute_add(
            EXPORTING
              iv_parameter_guid             = ls_selected_line-parameter_guid
              is_attribute_logical_key      = ls_new_attribute_logical_key
              it_source_code                = lot_source_code->*
              ir_ranges_value               = CORRESPONDING tt_r_ranges( lot_attribute_range_value->*
                                                            MAPPING low    = attribute_low
                                                                    sign   = attribute_sign
                                                                    high   = attribute_high
                                                                    option = attribute_opti )
            IMPORTING
              es_attribute_data             = ls_attribute_data
              es_attribute_range_data       = ls_attribute_range_data
              es_attribute_source_code_data = ls_attribute_source_code_data
          ).

          " Ajout de l'entrée pour mutualisation traitement
          INSERT ls_attribute_range_data       INTO TABLE lt_attribute_range_data.
          INSERT ls_attribute_source_code_data INTO TABLE lt_attribute_source_code_data.

        ELSEIF NOT ls_selected_line-parameter_guid IS INITIAL.
          " Paramètre
          ""  --> Copie du Paramètre
          me->mo_main_tree->mo_main->mo_hardcode_maintain->parameter_copy(
            EXPORTING
              iv_parameter_guid_copy        = ls_selected_line-parameter_guid
              iv_parameter_name_new         = CONV #( lv_name_new )
              iv_copy_children              = abap_true
            IMPORTING
              es_parameter_data             = ls_parameter_data
              et_attribute_data             = lt_attribute_data
              et_attribute_range_data       = lt_attribute_range_data
              et_attribute_source_code_data = lt_attribute_source_code_data
          ).

          ""  --> Ajout des données du Paramètre
          APPEND ls_parameter_data TO lt_parameter_data.

        ELSEIF NOT ls_selected_line-version_guid IS INITIAL.
          " Version
          ""  --> Copie de la Version
          me->mo_main_tree->mo_main->mo_hardcode_maintain->version_copy(
            EXPORTING
              iv_version_guid_copy          = ls_selected_line-version_guid
              iv_version_id_new             = CONV #( lv_name_new )
              iv_copy_children              = abap_true
            IMPORTING
              es_version_data               = ls_version_data
              et_parameter_data             = lt_parameter_data
              et_attribute_data             = lt_attribute_data
              et_attribute_range_data       = lt_attribute_range_data
              et_attribute_source_code_data = lt_attribute_source_code_data
          ).

        ENDIF.

      CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
        " Une erreur est survenue
        ""  --> Tant pis, ce n'est qu'une copie ...
        WHILE lo_cx_hardcode_maintain->previous IS BOUND.
          lo_cx_hardcode_maintain ?= lo_cx_hardcode_maintain->previous.
        ENDWHILE.
        MESSAGE ID lo_cx_hardcode_maintain->if_t100_message~t100key-msgid
              TYPE if_msg_output=>msgtype_success
            NUMBER lo_cx_hardcode_maintain->if_t100_message~t100key-msgno
              WITH lo_cx_hardcode_maintain->if_t100_message~t100key-attr1
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr2
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr3
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr4
           DISPLAY LIKE if_msg_output=>msgtype_error.

        ""  --> Arrêt du traitement
        RETURN.

    ENDTRY.

    " -----------------------------------------------------------
    " Ajout des Noeuds
    " -----------------------------------------------------------

    IF NOT ls_selected_line-attribute_guid_regroup IS INITIAL.
      " -----------------------------------------------------------
      " Ajout de l'Attribut dans l'Affichage
      " -----------------------------------------------------------

      ""  --> Initialisation données à afficher
      MOVE-CORRESPONDING ls_attribute_data TO ls_hardcode_data_new.

      IF ls_hardcode_data_new-attribute_as_range EQ abap_true.
        ""  --> Initialisation Icône
        ls_hardcode_data_new-attribute_as_range_icon = text-ira.

      ENDIF.

      IF ls_hardcode_data_new-attribute_as_source_code EQ abap_true.
        ""  --> Initialisation Icône
        ls_hardcode_data_new-attribute_as_source_code_icon = text-ics.

      ENDIF.

      ""  -->  Ajout du Noeud
      me->mo_main_tree->node_add(
        is_data        = ls_hardcode_data_new
        iv_node_level  = lcl_main_tree=>mc_node_level-attribute
        iv_node_parent = lv_parent_node_key
      ).

      " -----------------------------------------------------------
      " Alimentation données de l'Attribut
      " -----------------------------------------------------------

      IF ls_hardcode_data_new-attribute_as_range EQ abap_true.
        ""  --> Récupération table des Ranges du Programme
        ASSIGN me->mo_main_tree->ms_persistent_data-t_hc_data[ repid      = me->mo_main_tree->mv_repid
                                                               system_key = me->mo_main_tree->ms_system
                                                             ]-t_attribute_range TO <lfs_t_attribute_range>.  "Forcément réussi
        IF sy-subrc EQ 0.
          ""  --> Récupération entrée correspondant à l'Attribut
          READ TABLE <lfs_t_attribute_range>
          WITH TABLE KEY attribute_guid_regroup = ls_hardcode_data_new-attribute_guid_regroup
               ASSIGNING <lfs_s_attribute_range>.
          IF sy-subrc NE 0.
            " Aucune entrée existante pour cet Attribut
            ""  --> Ajout de l'Entrée
            ls_attribute_range-attribute_guid_regroup = ls_hardcode_data_new-attribute_guid_regroup.
            INSERT ls_attribute_range INTO TABLE <lfs_t_attribute_range> ASSIGNING <lfs_s_attribute_range>.

          ENDIF.

          TRY.
              " Modification valeurs des ranges
              <lfs_s_attribute_range>-t_attribute_range_value = lt_attribute_range_data[
                  attribute_guid_regroup = ls_hardcode_data_new-attribute_guid_regroup
                ]-t_attribute_range_value.

            CATCH cx_sy_itab_line_not_found.
              " Pas de correspondance
              REFRESH : <lfs_s_attribute_range>-t_attribute_range_value.

          ENDTRY.

        ENDIF.

      ENDIF.

      IF ls_hardcode_data_new-attribute_as_source_code EQ abap_true.
        ""  --> Récupération table des Codes Sources du Programme
        ASSIGN me->mo_main_tree->ms_persistent_data-t_hc_data[ repid      = me->mo_main_tree->mv_repid
                                                               system_key = me->mo_main_tree->ms_system
                                                             ]-t_source_code TO <lfs_t_source_code>.  "Forcément réussi
        IF sy-subrc EQ 0.
          ""  --> Récupération entrée correspondant à l'Attribut
          READ TABLE <lfs_t_source_code>
          WITH TABLE KEY attribute_guid_regroup = ls_hardcode_data_new-attribute_guid_regroup
               ASSIGNING <lfs_s_source_code>.
          IF sy-subrc NE 0.
            " Aucune entrée existante pour cet Attribut
            ""  --> Ajout de l'Entrée
            ls_source_code-attribute_guid_regroup = ls_hardcode_data_new-attribute_guid_regroup.
            INSERT ls_source_code INTO TABLE <lfs_t_source_code> ASSIGNING <lfs_s_source_code>.

          ENDIF.

          TRY.
              " Initialisation Code Source
              <lfs_s_source_code>-t_source_code = lt_attribute_source_code_data[
                attribute_guid_regroup = ls_attribute_data-attribute_guid_regroup
              ]-t_source_code.

            CATCH cx_sy_itab_line_not_found.
              " Pas de correspondance
              REFRESH : <lfs_s_source_code>-t_source_code.

          ENDTRY.

        ENDIF.

      ENDIF.

    ELSEIF NOT ls_selected_line-parameter_guid IS INITIAL
        OR NOT ls_selected_line-version_guid   IS INITIAL.

      IF NOT ls_selected_line-parameter_guid IS INITIAL.
        " Utilisation de la Version courante comme Noeud parent
        lv_version_node_key = lv_parent_node_key.

      ELSE.
        " -----------------------------------------------------------
        " Ajout de la Version (+Enfants) dans l'Affichage
        " -----------------------------------------------------------

        ""  --> Initialisation des données
        MOVE-CORRESPONDING ls_version_data TO ls_hardcode_data_new.
        ls_hardcode_data_new-version_primary_icon = me->mo_main_tree->icon_version_primary_set( ls_hardcode_data_new-version_primary ).

        ""  --> Ajout du Noeud
        lv_version_node_key = me->mo_main_tree->node_add(
          is_data       = ls_hardcode_data_new
          iv_node_level = lcl_main_tree=>mc_node_level-version
        ).

        ""  --> Affiche le bouton "Modifier primarité"
        me->_button_visibility_set( iv_primarity_visible = abap_true ).

      ENDIF.

      " -----------------------------------------------------------
      " Ajout de la Version (+Enfants) dans l'Affichage
      " -----------------------------------------------------------

      " Tri des données
      SORT :
        lt_parameter_data BY parameter_guid,
        lt_attribute_data BY parameter_guid attribute_guid_regroup attribute_guid.

      " Parcours l'ensemble des Paramètres
      LOOP AT lt_parameter_data ASSIGNING FIELD-SYMBOL(<lfs_s_parameter_data>).

        CLEAR : ls_hardcode_data_new, lv_parameter_node_key.

        " Ajout du Paramètre dans l'Affichage
        MOVE-CORRESPONDING <lfs_s_parameter_data> TO ls_hardcode_data_new.

        " Ajout du Noeud
        lv_parameter_node_key = me->mo_main_tree->node_add(
          is_data        = ls_hardcode_data_new
          iv_node_level  = lcl_main_tree=>mc_node_level-parameter
          iv_node_parent = lv_version_node_key
        ).

        " Récupération entrée persistante
        READ TABLE me->mo_main_tree->ms_persistent_data-t_hc_data
        WITH TABLE KEY repid      = me->mo_main_tree->mv_repid
                       system_key = me->mo_main_tree->ms_system
             ASSIGNING FIELD-SYMBOL(<lfs_s_t_hc_data>).
        IF sy-subrc EQ 0.
          ""  --> Récupération table des Ranges
          ASSIGN <lfs_s_t_hc_data>-t_attribute_range TO <lfs_t_attribute_range>.

          ""  --> Récupération table Code Source
          ASSIGN <lfs_s_t_hc_data>-t_source_code TO <lfs_t_source_code>.

        ENDIF.

        " Récupération première occurence des Attributs du Paramètre
        READ TABLE lt_attribute_data WITH KEY parameter_guid = <lfs_s_parameter_data>-parameter_guid
                          TRANSPORTING NO FIELDS BINARY SEARCH.
        IF sy-subrc EQ 0.
          " Au moins une correspondance
          ""  --> Parcours l'ensemble des Attributs du Paramètre
          LOOP AT lt_attribute_data ASSIGNING FIELD-SYMBOL(<lfs_s_attribute_data>)
                                         FROM sy-tabix.

            CLEAR : ls_hardcode_data_new, ls_attribute_data.

            IF <lfs_s_attribute_data>-parameter_guid NE <lfs_s_parameter_data>-parameter_guid.
              " On ne traite plus le même Paramètre
              ""  --> Arrêt de la boucle
              EXIT.

            ENDIF.

            " Initialisation données à afficher
            MOVE-CORRESPONDING <lfs_s_attribute_data> TO ls_hardcode_data_new.

            IF ls_hardcode_data_new-attribute_as_range EQ abap_true.
              " Attribut utilisation Range
              ""  --> Initialisation Icône
              ls_hardcode_data_new-attribute_as_range_icon = text-ira.

            ENDIF.

            IF ls_hardcode_data_new-attribute_as_source_code EQ abap_true.
              " Attribut utilisation Code Source
              ""  --> Initialisation Icône
              ls_hardcode_data_new-attribute_as_source_code_icon = text-ics.

            ENDIF.

            " Ajout du Noeud
            me->mo_main_tree->node_add(
              is_data        = ls_hardcode_data_new
              iv_node_level  = lcl_main_tree=>mc_node_level-attribute
              iv_node_parent = lv_parameter_node_key
            ).

            " -----------------------------------------------------------
            " Alimentation données de l'Attribut
            " -----------------------------------------------------------

            IF <lfs_s_attribute_data>-attribute_as_range EQ abap_true
            AND <lfs_t_attribute_range> IS ASSIGNED.
              " Récupération entrée correspondant à l'Attribut
              READ TABLE <lfs_t_attribute_range>
              WITH TABLE KEY attribute_guid_regroup = ls_hardcode_data_new-attribute_guid_regroup
                   ASSIGNING <lfs_s_attribute_range>.
              IF sy-subrc NE 0.
                " Aucune entrée existante pour cet Attribut
                ""  --> Ajout de l'Entrée
                ls_attribute_range-attribute_guid_regroup = ls_hardcode_data_new-attribute_guid_regroup.
                INSERT ls_attribute_range INTO TABLE <lfs_t_attribute_range> ASSIGNING <lfs_s_attribute_range>.

              ENDIF.

              TRY.
                  " Modification valeurs des ranges
                  <lfs_s_attribute_range>-t_attribute_range_value = lt_attribute_range_data[
                      attribute_guid_regroup = ls_hardcode_data_new-attribute_guid_regroup
                    ]-t_attribute_range_value.

                CATCH cx_sy_itab_line_not_found.
                  " Pas de correspondance
                  REFRESH : <lfs_s_attribute_range>-t_attribute_range_value.

              ENDTRY.

            ENDIF.

            IF  <lfs_s_attribute_data>-attribute_as_source_code EQ abap_true
            AND <lfs_t_source_code> IS ASSIGNED.
              " Vérifie l'existence du Code Source
              READ TABLE <lfs_t_source_code>
              WITH TABLE KEY attribute_guid_regroup = ls_hardcode_data_new-attribute_guid_regroup
                   ASSIGNING <lfs_s_source_code>.
              IF sy-subrc NE 0.
                " Aucune entrée existante pour cet Attribut
                ""  --> Ajout de l'Entrée
                ls_source_code-attribute_guid_regroup = ls_hardcode_data_new-attribute_guid_regroup.
                INSERT ls_source_code INTO TABLE <lfs_t_source_code> ASSIGNING <lfs_s_source_code>.

              ENDIF.

              TRY.
                  " Initialisation Code Source
                  <lfs_s_source_code>-t_source_code = lt_attribute_source_code_data[
                    attribute_guid_regroup = ls_hardcode_data_new-attribute_guid_regroup
                  ]-t_source_code.

                CATCH cx_sy_itab_line_not_found.
                  " Pas de correspondance
                  REFRESH : <lfs_s_source_code>-t_source_code.

              ENDTRY.

            ENDIF.

          ENDLOOP.

        ENDIF.

      ENDLOOP.

    ENDIF.

    " -----------------------------------------------------------
    " Modification de l'Affichage
    " -----------------------------------------------------------

    " Modification de l'affichage
    me->mo_main_tree->ms_display_element-display_element-o_alv_tree->update_calculations( ).

  ENDMETHOD.

  METHOD handler_on_modify.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    " -----------------------------------------------------------
    " Edition de la ligne sélectionnée
    " -----------------------------------------------------------

    " Affiche détail de la ligne en édition
    me->_node_edit( ).

  ENDMETHOD.

  METHOD handler_on_hierarchy_edit.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Edition Noeud Hiérarchie
    " -----------------------------------------------------------

    " Traitement de modification
    me->_node_edit( ).

  ENDMETHOD.

  METHOD _node_edit.

***------------------------------------------------------------------***
**                             RANGES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_source_code  TYPE stringtab,
      lr_ranges_value TYPE tt_r_ranges.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_attribute_range_value TYPE zcl_hardcode_maintain=>tt_attribute_range_value_det.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_source_code                TYPE lcl_main_tree=>ts_source_code,
      ls_selected_line              TYPE lcl_main_tree=>ts_hc_data,
      ls_attribute_range            TYPE lcl_main_tree=>ts_attribute_range,
      ls_new_attribute_logical_key  TYPE zcl_hardcode_maintain=>ts_attribute_logical_key,
      ls_new_attribute_logical_keyx TYPE zcl_hardcode_maintain=>ts_attribute_logical_keyx.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_cx_exception         TYPE REF TO cx_root,
      lo_cx_hardcode_maintain TYPE REF TO zcx_hardcode_maintain.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_cancel        TYPE flag,
      lv_subrc         TYPE sy-subrc,
      lv_node_text     TYPE lvc_value,
      lv_node_level    TYPE zcl_gui_alv_tree_util=>ts_hierarchy-node_level,
      lv_selected_node TYPE lvc_nkey.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération des données de la ligne sélectionnée
    " -----------------------------------------------------------

    ls_selected_line = me->mo_main_tree->line_selected_get(
      IMPORTING
        ev_subrc         = lv_subrc
        ev_selected_node = lv_selected_node
    ).
    IF NOT lv_subrc IS INITIAL.
      " Aucune lignée seléctionnée
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Déslectionne
    me->mo_main_tree->ms_display_element-display_element-o_alv_tree->unselect_all( ).

    TRY.
        " -----------------------------------------------------------
        " Modification des données internes
        " -----------------------------------------------------------

        IF NOT ls_selected_line-attribute_guid_regroup IS INITIAL.
          " Attribut
          ""  --> Modification Noeud
          me->_node_edit_attribute( CHANGING cs_selected_line = ls_selected_line ).

          ""  --> Initialisation niveau de Noeud
          lv_node_level = 3.                                ##NO_TEXT

        ELSEIF NOT ls_selected_line-parameter_guid IS INITIAL.
          " Paramètre
          ""  --> Modification Noeud
          me->_node_edit_parameter( CHANGING cs_selected_line = ls_selected_line ).

          ""  --> Initialisation niveau de Noeud
          lv_node_level = 2.                                ##NO_TEXT

        ELSEIF NOT ls_selected_line-version_guid IS INITIAL.
          " Version
          ""  --> Modification Noeud
          me->_node_edit_version( CHANGING cs_selected_line = ls_selected_line ).

          ""  --> Initialisation niveau de Noeud
          lv_node_level = 1.                                ##NO_TEXT

          ""  --> Arrêt du traitement
          RETURN.

        ENDIF.

      CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
        " Une erreur est survenue
        ""  --> Affiche le message d'erreur
        WHILE lo_cx_hardcode_maintain->previous IS BOUND.
          lo_cx_hardcode_maintain ?= lo_cx_hardcode_maintain->previous.
        ENDWHILE.
        MESSAGE ID lo_cx_hardcode_maintain->if_t100_message~t100key-msgid
              TYPE if_msg_output=>msgtype_success
            NUMBER lo_cx_hardcode_maintain->if_t100_message~t100key-msgno
              WITH lo_cx_hardcode_maintain->if_t100_message~t100key-attr1
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr2
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr3
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr4
           DISPLAY LIKE if_msg_output=>msgtype_error.

        ""  --> Arrêt du traitement
        RETURN.

    ENDTRY.

    " Evènement modification
    me->handler_submit_change( ).

    " Récupération configuration de l'affichage
    zcl_gui_alv_tree_util=>hierarchy_usage(
      EXPORTING
        is_data      = ls_selected_line
        is_hierarchy = me->mo_main_tree->ms_display_element-display_element-t_hierarchy[ lv_node_level ]
      IMPORTING
        es_node_data = ls_selected_line
        ev_node_text = lv_node_text
    ).

    " -----------------------------------------------------------
    " Modification des lignes dans l'ALV
    " -----------------------------------------------------------

    me->mo_main_tree->ms_display_element-display_element-o_alv_tree->change_node(
      EXPORTING
        i_node_key     = lv_selected_node
        i_outtab_line  = ls_selected_line
        i_node_text    = lv_node_text
        i_u_node_text  = abap_true
      EXCEPTIONS ##SUBRC_OK
        node_not_found = 1
        OTHERS         = 2
    ).

    " Modification de l'affichage
    me->mo_main_tree->ms_display_element-display_element-o_alv_tree->update_calculations( ).

  ENDMETHOD.

  METHOD _node_edit_version.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Traitement Edition Version
    " -----------------------------------------------------------

    " Pas d'édition
    RETURN.

  ENDMETHOD.

  METHOD _node_edit_parameter.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_subrc  TYPE sy-subrc,
      lv_cancel TYPE xsdboolean.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " PopIn Edition
    " -----------------------------------------------------------

    " PopUp saisi Nom
    cs_selected_line-parameter_name = me->mo_main_tree->mo_main->call_popup_input_simple(
      EXPORTING
        iv_text      = cs_selected_line-parameter_name
        iv_title     = text-npa
        iv_read_only = me->mo_main_tree->mv_read_only
      IMPORTING
        ev_subrc     = lv_subrc
        ev_cancel    = lv_cancel
    ).
    IF NOT lv_subrc IS INITIAL
    OR me->mo_main_tree->mv_read_only EQ abap_true.
      " Action interrompue || Affichage uniquement
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Modification dans le modèle
    " -----------------------------------------------------------

    " Modification des données du Paramètre
    me->mo_main_tree->mo_main->mo_hardcode_maintain->parameter_set(
        iv_parameter_guid     = cs_selected_line-parameter_guid
        iv_new_parameter_name = cs_selected_line-parameter_name
    ).

  ENDMETHOD.

  METHOD _node_edit_attribute.

***------------------------------------------------------------------***
**                             RANGES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_source_code  TYPE stringtab,
      lr_ranges_value TYPE tt_r_ranges.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_attribute_range_value TYPE zcl_hardcode_maintain=>tt_attribute_range_value_det.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_source_code                TYPE lcl_main_tree=>ts_source_code,
      ls_attribute_range            TYPE lcl_main_tree=>ts_attribute_range,
      ls_new_attribute_logical_key  TYPE zcl_hardcode_maintain=>ts_attribute_logical_key,
      ls_new_attribute_logical_keyx TYPE zcl_hardcode_maintain=>ts_attribute_logical_keyx.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_cancel TYPE flag.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " PopIn Détail de l'Attribut
    " -----------------------------------------------------------

    " Affichage outil saisi des données
    me->mo_main_tree->attribute_detail_display(
      IMPORTING
        ev_cancel                     = lv_cancel
        et_source_code                = lt_source_code
        er_ranges_value               = lr_ranges_value
        et_attribute_range_value      = lt_attribute_range_value
        es_new_attribute_logical_key  = ls_new_attribute_logical_key
        es_new_attribute_logical_keyx = ls_new_attribute_logical_keyx
      CHANGING
        cs_hardcode_data              = cs_selected_line
    ).
    IF lv_cancel EQ abap_true
    OR me->mo_main_tree->mv_read_only EQ abap_true.
      " L'utilisateur à annulé les modifications
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Modification dans le modèle de données
    " -----------------------------------------------------------

    " Modification des données l'Attribut
    me->mo_main_tree->mo_main->mo_hardcode_maintain->attribute_set(
        iv_parameter_guid              = cs_selected_line-parameter_guid
        iv_attribute_guid_regroup      = cs_selected_line-attribute_guid_regroup
        is_new_attribute_logical_key   = ls_new_attribute_logical_key
        is_new_attribute_logical_keyx  = ls_new_attribute_logical_keyx
        ir_new_ranges_value            = lr_ranges_value
        iv_replace_ranges_value        = abap_true
        it_new_source_code_value       = lt_source_code
        iv_replace_source_code         = abap_true
    ).

    " Initialisation données du Range & Code Source
    READ TABLE me->mo_main_tree->ms_persistent_data-t_hc_data
    WITH TABLE KEY repid      = me->mo_main_tree->mv_repid
                   system_key = me->mo_main_tree->ms_system
         ASSIGNING FIELD-SYMBOL(<lfs_s_hc_data>).
    IF sy-subrc EQ 0.
      TRY.
          ""  --> Modification valeurs du Range
          <lfs_s_hc_data>-t_attribute_range[ attribute_guid_regroup  = cs_selected_line-attribute_guid_regroup
                                           ]-t_attribute_range_value = lt_attribute_range_value.

        CATCH cx_sy_itab_line_not_found.
          " L'entrée n'existe pas
          ""  --> Création d'une nouvelle entrée
          ls_attribute_range-attribute_guid_regroup  = cs_selected_line-attribute_guid_regroup.
          ls_attribute_range-t_attribute_range_value = lt_attribute_range_value[].
          INSERT ls_attribute_range INTO TABLE <lfs_s_hc_data>-t_attribute_range.

      ENDTRY.

      TRY.
          ""  --> Modification Code Source
          <lfs_s_hc_data>-t_source_code[ attribute_guid_regroup  = cs_selected_line-attribute_guid_regroup
                                       ]-t_source_code = lt_source_code.

        CATCH cx_sy_itab_line_not_found.
          " L'entrée n'existe pas
          ""  --> Création d'une nouvelle entrée
          ls_source_code-attribute_guid_regroup  = cs_selected_line-attribute_guid_regroup.
          ls_source_code-t_source_code = lt_source_code[].
          INSERT ls_source_code INTO TABLE <lfs_s_hc_data>-t_source_code.

      ENDTRY.

    ENDIF.

    " -----------------------------------------------------------
    " Autres modifications
    " -----------------------------------------------------------

    " Modification des Icônes
    cs_selected_line-attribute_as_range_icon = me->mo_main_tree->icon_attribute_range_set(
      cs_selected_line-attribute_as_range
    ).
    cs_selected_line-attribute_as_source_code_icon = me->mo_main_tree->icon_attribute_source_code_set(
      cs_selected_line-attribute_as_source_code
    ).

  ENDMETHOD.

  METHOD _button_visibility_set.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Modification propriété d'affichage des boutons
    " -----------------------------------------------------------

    IF  iv_cancel_visible IS SUPPLIED
    AND iv_cancel_visible NE abap_undefined.
      ""  --> Modification affichage bouton "Annuler"
      me->mo_main_tree->ms_display_element-display_element-o_toolbar->set_button_visible(
        EXPORTING
          visible          = iv_cancel_visible
          fcode            = lcl_main_tree_toolbar_event=>mc_function-cancel
        EXCEPTIONS
          OTHERS           = 0
      ).

    ENDIF.

    IF  iv_primarity_visible IS SUPPLIED
    AND iv_primarity_visible NE abap_undefined.
      ""  --> Modification affichage bouton "Primarité"
      me->mo_main_tree->ms_display_element-display_element-o_toolbar->set_button_visible(
        EXPORTING
          visible          = iv_primarity_visible
          fcode            = lcl_main_tree_toolbar_event=>mc_function-primary_set
        EXCEPTIONS
          OTHERS           = 0
      ).

    ENDIF.

  ENDMETHOD.

  METHOD handler_on_display.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Affichage détail
    " -----------------------------------------------------------

    " Affichage détail (lecture seule)
    me->_node_edit( ).

  ENDMETHOD.

  METHOD handler_on_version_create.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_version_data      TYPE ztec_t_hc_vers,
      ls_hardcode_data_new TYPE lcl_main_tree=>ts_hc_data.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_cx_hardcode_maintain TYPE REF TO zcx_hardcode_maintain.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_subrc TYPE sy-subrc.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Détermination du Numéro de Version
    " -----------------------------------------------------------

    ls_hardcode_data_new-version_id = me->mo_main_tree->mo_main->mo_hardcode_maintain->version_get_next( ).

    " -----------------------------------------------------------
    " Contrôle validité de la saisie
    " -----------------------------------------------------------

    IF ls_hardcode_data_new-version_id IS INITIAL.
      " Aucune saisie
      ""  --> Arrêt du traitement
      MESSAGE s104(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Ajout du Noeud
    " -----------------------------------------------------------

    TRY.
        " Création de la nouvelle Version
        ls_hardcode_data_new-version_guid = me->mo_main_tree->mo_main->mo_hardcode_maintain->version_add(
          EXPORTING
           iv_version_id    = ls_hardcode_data_new-version_id
           iv_is_primary    = abap_false
          IMPORTING
            es_version_data = ls_version_data
         ).

        " Initialisation des données
        MOVE-CORRESPONDING ls_version_data TO ls_hardcode_data_new.
        ls_hardcode_data_new-version_primary_icon = me->mo_main_tree->icon_version_primary_set( ls_hardcode_data_new-version_primary ).

        " Ajout du Noeud
        me->mo_main_tree->node_add(
          is_data       = ls_hardcode_data_new
          iv_node_level = lcl_main_tree=>mc_node_level-version
        ).

        " Affiche bouton "Modifier Primarité"
        me->_button_visibility_set( iv_primarity_visible = abap_true ).

      CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
        " Une erreur est survenue
        ""  --> Affichage de l'erreur
        WHILE lo_cx_hardcode_maintain->previous IS BOUND.
          lo_cx_hardcode_maintain ?= lo_cx_hardcode_maintain->previous.
        ENDWHILE.
        MESSAGE ID lo_cx_hardcode_maintain->if_t100_message~t100key-msgid
              TYPE if_msg_output=>msgtype_success
            NUMBER lo_cx_hardcode_maintain->if_t100_message~t100key-msgno
              WITH lo_cx_hardcode_maintain->if_t100_message~t100key-attr1
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr2
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr3
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr4
           DISPLAY LIKE if_msg_output=>msgtype_error.

    ENDTRY.

  ENDMETHOD.

  METHOD handler_on_parameter_create.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_selected_line     TYPE lcl_main_tree=>ts_hc_data,
      ls_hardcode_data_new TYPE lcl_main_tree=>ts_hc_data.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_cx_hardcode_maintain TYPE REF TO zcx_hardcode_maintain.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_subrc           TYPE sy-subrc,
      lv_parent_node_key TYPE lvc_nkey.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération des données de la ligne sélectionnée
    " -----------------------------------------------------------

    " Récupération des données de la ligne sélectionné
    "" + Récupération Noeud 'Version' correspondant
    ls_selected_line = me->mo_main_tree->line_selected_get(
      EXPORTING
        iv_parent_node_ref = me->mo_main_tree->ms_display_element-display_element-t_hierarchy[ node_level = 1 ]-node_level_key_fieldname
      IMPORTING
        ev_subrc           = lv_subrc
        ev_parent_node_key = lv_parent_node_key
    ).
    IF NOT lv_subrc IS INITIAL.
      " Aucune lignée seléctionnée
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Initialisation des données
    MOVE-CORRESPONDING ls_selected_line TO ls_hardcode_data_new.

    " -----------------------------------------------------------
    " Pop-Up saisie du Nom
    " -----------------------------------------------------------

    ls_hardcode_data_new-parameter_name = me->mo_main_tree->mo_main->call_popup_input_simple(
      EXPORTING
        iv_title = text-npa
      IMPORTING
        ev_subrc = lv_subrc
    ).
    IF NOT lv_subrc IS INITIAL.
      " Une erreur est survenue
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    IF ls_hardcode_data_new-parameter_name IS INITIAL.
      " Aucune saisie
      ""  --> Arrêt du traitement
      MESSAGE s203(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Ajout du Noeud
    " -----------------------------------------------------------

    TRY.
        " Création du Nouveau Paramètre
        ls_hardcode_data_new-parameter_guid = me->mo_main_tree->mo_main->mo_hardcode_maintain->parameter_add(
            iv_version_guid   = ls_selected_line-version_guid
            iv_parameter_name = ls_hardcode_data_new-parameter_name
        ).

        " Ajout du Noeud
        me->mo_main_tree->node_add(
          is_data            = ls_hardcode_data_new
          iv_node_level      = lcl_main_tree=>mc_node_level-parameter
          iv_node_parent     = lv_parent_node_key
        ).

      CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
        " Une erreur est survenue
        ""  --> Affichage de l'erreur
        WHILE lo_cx_hardcode_maintain->previous IS BOUND.
          lo_cx_hardcode_maintain ?= lo_cx_hardcode_maintain->previous.
        ENDWHILE.
        MESSAGE ID lo_cx_hardcode_maintain->if_t100_message~t100key-msgid
              TYPE if_msg_output=>msgtype_success
            NUMBER lo_cx_hardcode_maintain->if_t100_message~t100key-msgno
              WITH lo_cx_hardcode_maintain->if_t100_message~t100key-attr1
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr2
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr3
                   lo_cx_hardcode_maintain->if_t100_message~t100key-attr4
           DISPLAY LIKE if_msg_output=>msgtype_error.

    ENDTRY.

  ENDMETHOD.

  METHOD expand_first_node.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
          lt_children TYPE lvc_t_nkey.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Déplie l'arborescence
    " -----------------------------------------------------------

    " Récupération Noeud Version
    me->mo_main_tree->ms_display_element-display_element-o_alv_tree->get_children(
      EXPORTING
        i_node_key         = CONV #( '&VIRTUALROOT' )       ##NO_TEXT
      IMPORTING
        et_children        = lt_children
      EXCEPTIONS
        historic_error     = 1
        node_key_not_found = 2
        OTHERS             = 3
    ).
    IF sy-subrc EQ 0 AND NOT lt_children[] IS INITIAL.
      " Expand
      me->mo_main_tree->ms_display_element-display_element-o_alv_tree->expand_node(
        EXPORTING
          i_node_key          = lt_children[ 1 ]
          i_level_count       = 10
          i_expand_subtree    = abap_true
        EXCEPTIONS ##SUBRC_OK
          failed              = 1
          illegal_level_count = 2
          cntl_system_error   = 3
          node_not_found      = 4
          cannot_expand_leaf  = 5
          OTHERS              = 6
      ).

    ENDIF.

  ENDMETHOD.

ENDCLASS.

*----------------------------------------------------------------------*
*       CLASS LCL_TREE_DRAG_AND_DROP IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_tree_drag_and_drop IMPLEMENTATION.

  METHOD flavor_select.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Sélection des données
    " -----------------------------------------------------------



  ENDMETHOD.

  METHOD left_drag.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Sélection des données
    " -----------------------------------------------------------



  ENDMETHOD.

  METHOD right_drop.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Sélection des données
    " -----------------------------------------------------------



  ENDMETHOD.

  METHOD drop_complete.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Sélection des données
    " -----------------------------------------------------------



  ENDMETHOD.

ENDCLASS.
