FUNCTION z_hc_read.
*"----------------------------------------------------------------------
*& Copyright © 13/01/2016, Olivier Véhier                              *
*&                                                                     *
*& Permission is hereby granted, free of charge, to any person         *
*& obtaining a copy of this software and associated documentation      *
*& files (the "Software"), to deal in the Software without restriction *
*& including without limitation the rights to use, copy, modify,       *
*& merge, publish, distribute, sublicense, and/or sell copies of the   *
*& Software, and to permit persons to whom the Software is furnished   *
*& to do so, subject to the following conditions:                      *
*&                                                                     *
*& The above copyright notice and this permission notice shall be      *
*& included in all copies or substantial portions of the Software.     *
*&                                                                     *
*& THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,     *
*& EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES     *
*& OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND            *
*& NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS *
*& BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN  *
*& ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN   *
*& CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE    *
*& SOFTWARE.                                                           *
*&                                                                     *
*& Except as contained in this notice, the name of Olivier Véhier      *
*& shall not be used in advertising or otherwise to promote the sale,  *
*& use or other dealings in this Software without prior written        *
*& authorization from Olivier Véhier.                                  *
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(IV_REPID) TYPE  REPID
*"  EXPORTING
*"     VALUE(ET_HARDCODE) TYPE  ZVTEC_T_HC_TT
*"     VALUE(ET_HARDCODE_SOURCE_CODE) TYPE  ZTEC_T_HC_ATTRIBUTE_SOURCE
*"----------------------------------------------------------------------

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_hardcode_source_code TYPE ztec_s_hc_attribute_source.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Hardcode - Lecture
  " -----------------------------------------------------------

  " Lecture des Hardcodes
  et_hardcode = CORRESPONDING #( zcl_hardcode=>get_instance( iv_repid )->mt_hardcode ).

  IF NOT et_hardcode[] IS INITIAL
  AND et_hardcode_source_code IS SUPPLIED.
    " -----------------------------------------------------------
    " Hardcode - Code Source - Lecture
    " -----------------------------------------------------------

    " Récupération des Identifiants des Codes Sources
    SELECT srtfd FROM ztec_t_hc_attr_c
      FOR ALL ENTRIES IN @et_hardcode
                   WHERE srtfd EQ @et_hardcode-attribute_guid_regroup
              INTO TABLE @DATA(lt_srtfd).

    " Mapping dans l'autre sens
    et_hardcode_source_code[] = CORRESPONDING #( lt_srtfd MAPPING attribute_guid_regroup = srtfd EXCEPT * ).
    FREE lt_srtfd.

    " Récupération Code Source
    LOOP AT et_hardcode_source_code ASSIGNING FIELD-SYMBOL(<lfs_s_hc_sc>).

      " Récupération Code Source
      <lfs_s_hc_sc>-source_code = zcl_hardcode_cluster=>source_code_get( <lfs_s_hc_sc>-attribute_guid_regroup ).

    ENDLOOP.

  ENDIF.

ENDFUNCTION.
