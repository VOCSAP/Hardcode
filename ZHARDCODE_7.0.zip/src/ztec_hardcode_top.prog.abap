*&---------------------------------------------------------------------*
*& Include         : ZTEC_HARDCODE_TOP                                 *
*& Programme Cadre : ZTEC_HARDCODE                                     *
*&---------------------------------------------------------------------*
*& Gestion Hardcode                                                    *
*& Include Déclaration données                                         *
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*& Créé le      : 13/01/2016                                           *
*&                                                                     *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*

REPORT ztec_customizing.

***------------------------------------------------------------------***
**                             INCLUDE                                **
***------------------------------------------------------------------***


***------------------------------------------------------------------***
**                              MACCRO                                **
***------------------------------------------------------------------***


***------------------------------------------------------------------***
**                             CLASSES                                **
***------------------------------------------------------------------***

" Classes principales
CLASS lcl_main DEFINITION DEFERRED.

" Classes évènements
CLASS lcl_tree_drag_and_drop DEFINITION DEFERRED.
CLASS lcl_main_tree_event DEFINITION DEFERRED.
CLASS lcl_main_tree_toolbar_event DEFINITION DEFERRED.
CLASS lcl_main_tree_toolbar_handler DEFINITION DEFERRED.

" Classes affichage
CLASS lcl_main_tree DEFINITION DEFERRED.
CLASS lcl_attribute_detail DEFINITION DEFERRED.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

TYPES :
  BEGIN OF ts_system,
    system  TYPE syst_sysid,
    mandant TYPE sy-mandt,
  END OF   ts_system.

TYPES :
  BEGIN OF ts_attribute_detail,
    read_only                TYPE xsdboolean,
    attribute_name           TYPE ztec_t_hc_attr-attribute_name,
    attribute_key1           TYPE ztec_t_hc_attr-attribute_key1,
    attribute_key2           TYPE ztec_t_hc_attr-attribute_key2,
    attribute_key3           TYPE ztec_t_hc_attr-attribute_key3,
    attribute_key4           TYPE ztec_t_hc_attr-attribute_key4,
    attribute_as_range       TYPE ztec_t_hc_attr-attribute_as_range,
    attribute_as_source_code TYPE ztec_t_hc_attr-attribute_as_source_code,
    cancel                   TYPE flag,
  END OF   ts_attribute_detail.

TYPES : tt_r_ranges TYPE RANGE OF ztec_t_hc_attr-attribute_low.

TYPES :
  BEGIN OF ts_attribute_detail_ref,
    attribute_name           TYPE REF TO ztec_t_hc_attr-attribute_name,
    attribute_key1           TYPE REF TO ztec_t_hc_attr-attribute_key1,
    attribute_key2           TYPE REF TO ztec_t_hc_attr-attribute_key2,
    attribute_key3           TYPE REF TO ztec_t_hc_attr-attribute_key3,
    attribute_key4           TYPE REF TO ztec_t_hc_attr-attribute_key4,
    attribute_as_range       TYPE REF TO ztec_t_hc_attr-attribute_as_range,
    attribute_as_source_code TYPE REF TO ztec_t_hc_attr-attribute_as_source_code,
  END OF   ts_attribute_detail_ref.

TYPES :
  BEGIN OF ts_transport_target.
        INCLUDE TYPE : ts_system.
TYPES :
  cancel         TYPE xsdboolean,
  transport_all  TYPE xsdboolean,
  transport_node TYPE lvc_nkey,
  END OF   ts_transport_target.

***------------------------------------------------------------------***
**                           CONSTANTES                               **
***------------------------------------------------------------------***


***------------------------------------------------------------------***
**                             RANGES                                 **
***------------------------------------------------------------------***


***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
TABLES: sscrfields.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
DATA : gs_attribute_detail TYPE ts_attribute_detail.
DATA : gs_transport_target TYPE ts_transport_target.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
DATA : go_main TYPE REF TO lcl_main.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
DATA : ok_code TYPE sy-ucomm.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
