FUNCTION zh_value_help_hardcode.

*"----------------------------------------------------------------------
*& Copyright © 13/01/2016, Olivier Véhier                              *
*&                                                                     *
*& Permission is hereby granted, free of charge, to any person         *
*& obtaining a copy of this software and associated documentation      *
*& files (the "Software"), to deal in the Software without restriction *
*& including without limitation the rights to use, copy, modify,       *
*& merge, publish, distribute, sublicense, and/or sell copies of the   *
*& Software, and to permit persons to whom the Software is furnished   *
*& to do so, subject to the following conditions:                      *
*&                                                                     *
*& The above copyright notice and this permission notice shall be      *
*& included in all copies or substantial portions of the Software.     *
*&                                                                     *
*& THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,     *
*& EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES     *
*& OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND            *
*& NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS *
*& BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN  *
*& ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN   *
*& CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE    *
*& SOFTWARE.                                                           *
*&                                                                     *
*& Except as contained in this notice, the name of Olivier Véhier      *
*& shall not be used in advertising or otherwise to promote the sale,  *
*& use or other dealings in this Software without prior written        *
*& authorization from Olivier Véhier.                                  *
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  TABLES
*"      SHLP_TAB TYPE  SHLP_DESCT
*"      RECORD_TAB STRUCTURE  SEAHLPRES
*"  CHANGING
*"     VALUE(SHLP) TYPE  SHLP_DESCR
*"     VALUE(CALLCONTROL) LIKE  DDSHF4CTRL STRUCTURE  DDSHF4CTRL
*"----------------------------------------------------------------------

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Suivant l'étape
  " -----------------------------------------------------------

*CALLCONTROL-CONT_OUT = abap_true.
CALLCONTROL-RETALLFLDS = abap_true.
*CALLCONTROL-STEPRC = 10.
*CALLCONTROL-OCXHANDLE = 10.

*RETALLFLDS 1 Types   CHAR  1 0 Retourner contenu de toutes les zones
*CONT_OUT 1 Types   CHAR  1 0 Dynpro-Step Control Out (Combobox)
*OCXHANDLE  1 Types   INT4  10  0 Utilisation interne. Ne pas modifier !
*STEPRC 1 Types   INT4  10  0 Utilisation interne. Ne pas modifier !
  CASE callcontrol-step.

    WHEN cl_ehsgbc_constants=>gc_shlp_control_step_select.
      " Sélection

    WHEN cl_ehsgbc_constants=>gc_shlp_control_step_disp.
      " Affichage
*      REFRESH : record_tab.

    WHEN OTHERS.
      " Autres
      ""  --> On ne traite pas ces étapes
      RETURN.

  ENDCASE.

ENDFUNCTION.
