class ZCL_GUI_ALV_TREE_UTIL definition
  public
  final
  create public .

public section.

  types:
    BEGIN OF ts_node_text_dynamic,
        fieldname     TYPE string,
        separator     TYPE string,
        alpha_in      TYPE flag,
        condense      TYPE flag,
        even_if_empty TYPE flag,
      END OF   ts_node_text_dynamic .
  types:
    tt_node_text_dynamic TYPE STANDARD TABLE OF ts_node_text_dynamic
                        WITH NON-UNIQUE KEY primary_key COMPONENTS fieldname .
  types:
    BEGIN OF ts_hierarchy,
        node_level               TYPE i,
        fieldname                TYPE name_komp,
        t_component_display      TYPE cgpl_field_names,
        t_component_excluded     TYPE cgpl_field_names,
        node_text_fixed          TYPE string,
        node_text_dynamic        TYPE zcl_gui_alv_tree_util=>tt_node_text_dynamic,
        node_text_separator      TYPE string,
        node_text_alpha_in       TYPE flag,
        node_layout              TYPE lvc_s_layn,
        t_item_layout            TYPE lvc_t_layi,
        node_level_key_fieldname TYPE name_komp,
        hide_if_empty            TYPE flag,
        hide_if_null             TYPE flag,
      END OF   ts_hierarchy .
  types:
    tt_hierarchy TYPE SORTED TABLE OF ts_hierarchy
                                                  WITH UNIQUE KEY primary_key COMPONENTS node_level
                                                  WITH UNIQUE SORTED KEY second_key COMPONENTS fieldname .
  types:
    BEGIN OF ts_level_node_key,
        node_text          TYPE string,
        node_key           TYPE lvc_nkey,
        fieldname          TYPE string,
        node_text_complete TYPE string,
        node_level_key     TYPE string,
        parent_node_key    TYPE lvc_nkey,
      END OF   ts_level_node_key .
  types:
    tt_level_node_key TYPE STANDARD TABLE OF ts_level_node_key
                                               WITH NON-UNIQUE KEY primary_key COMPONENTS node_text .

  methods CONSTRUCTOR
    importing
      !IO_ALV_TREE type ref to CL_GUI_ALV_TREE
    preferred parameter IO_ALV_TREE .
  methods NODE_DATA_ADD
    importing
      !IS_DATA type ANY
      !IV_NODE_TEXT type CLIKE optional
      !IV_HAS_CHILD type FLAG optional
      !IV_FIELDNAME type CLIKE optional
      !IS_NODE_LAYOUT type LVC_S_LAYN optional
      !IT_ITEM_LAYOUT type LVC_T_LAYI optional
      !IV_NODE_LEVEL_KEY type STRING optional
      !IV_PARENT_NODE_ID type SYSUUID_X16 optional
    returning
      value(RV_NODE_ID) type SYSUUID_X16 .
  methods ALV_TREE_POPULATE
    exporting
      !ET_LEVEL_NODE_KEY type zcl_gui_alv_tree_util=>TT_LEVEL_NODE_KEY .
  class-methods ALV_TREE_POPULATE_AUTO
    importing
      value(IT_ALV_TREE_DATA) type INDEX TABLE
      !IT_HIERARCHY type ZCL_GUI_ALV_TREE_UTIL=>TT_HIERARCHY
    exporting
      !ET_LEVEL_NODE_KEY type zcl_gui_alv_tree_util=>TT_LEVEL_NODE_KEY
    changing
      !CO_ALV_TREE type ref to CL_GUI_ALV_TREE .
  class-methods EXPORT_TO_EXCEL
    importing
      !IO_ALV_TREE type ref to CL_GUI_ALV_TREE
      !IV_FILENAME type CLIKE optional
      !IV_FILEPATH type CLIKE optional
      !IV_WORKSHEET_NAME type CLIKE optional
    returning
      value(RV_SUBRC) type SY-SUBRC .
  class-methods HIERARCHY_USAGE
    importing
      value(IS_DATA) type ANY
      !IS_HIERARCHY type zcl_gui_alv_tree_util=>TS_HIERARCHY
    exporting
      !ES_NODE_DATA type ANY
      !EV_NODE_TEXT type CLIKE
      !EV_NODE_LEVEL_KEY type CLIKE .
protected section.
PRIVATE SECTION.

  TYPES:
    BEGIN OF ts_node_data,
      parent_node_id TYPE        sysuuid_x16,
      node_id        TYPE        sysuuid_x16,
      node_data      TYPE REF TO data,
      fieldname      TYPE string,
      node_text      TYPE        lvc_value,
      node_layout    TYPE        lvc_s_layn,
      t_item_layout  TYPE        lvc_t_layi,
      node_level_key TYPE        string,
      has_child      TYPE        flag,
    END OF   ts_node_data .
  TYPES:
    tt_node_data TYPE SORTED TABLE OF ts_node_data
                                WITH UNIQUE KEY primary_key COMPONENTS parent_node_id node_id .
  TYPES:
    BEGIN OF ts_key,
      key     TYPE string,
      node_id TYPE sysuuid_x16,
    END OF   ts_key .
  TYPES:
    tt_key TYPE SORTED TABLE OF ts_key
                          WITH UNIQUE KEY primary_key COMPONENTS key .

  DATA mo_alv_tree TYPE REF TO cl_gui_alv_tree .
  DATA mt_key TYPE zcl_gui_alv_tree_util=>tt_key .
  DATA mt_node_data TYPE zcl_gui_alv_tree_util=>tt_node_data .

  METHODS node_add_recursive
    IMPORTING
      !is_node_data           TYPE zcl_gui_alv_tree_util=>ts_node_data
      !iv_parent_node_key     TYPE lvc_nkey OPTIONAL
      !iv_parent_node_text    TYPE string OPTIONAL
      !iv_fill_level_node_key TYPE flag OPTIONAL
        PREFERRED PARAMETER is_node_data
    CHANGING
      !ct_level_node_key      TYPE zcl_gui_alv_tree_util=>tt_level_node_key OPTIONAL .
  METHODS add_to_appropriate_node
    IMPORTING
      !is_data            TYPE any
      !it_hierarchy       TYPE zcl_gui_alv_tree_util=>tt_hierarchy OPTIONAL
      !it_component_key   TYPE cgpl_field_names OPTIONAL
      !is_hierarchy_lower TYPE zcl_gui_alv_tree_util=>ts_hierarchy OPTIONAL .
  CLASS-METHODS display_data_set
    IMPORTING
      !is_data               TYPE any
      !it_component_display  TYPE cgpl_field_names
      !it_component_excluded TYPE cgpl_field_names
    RETURNING
      VALUE(ro_data)         TYPE REF TO data .
  CLASS-METHODS _node_text_set
    IMPORTING
      !is_data            TYPE any
      !is_hierarchy       TYPE zcl_gui_alv_tree_util=>ts_hierarchy
    RETURNING
      VALUE(rv_node_text) TYPE string .
ENDCLASS.



CLASS ZCL_GUI_ALV_TREE_UTIL IMPLEMENTATION.


METHOD add_to_appropriate_node.
*&---------------------------------------------------------------------*
*& Méthode         : ADD_TO_APPROPRIATE_NODE                           *
*& Classe          : ZCL_GUI_ALV_TREE_UTIL                             *
*& Description     : Ajout de l'entrée dans le Noeud approprié         *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 28/01/2016                                           *
*                                                                      *
*& Responsable Technique  : Véhier Olivier                             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
      lt_node_text_fieldname TYPE stringtab.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_key       TYPE zcl_gui_alv_tree_util=>ts_key,
    ls_node_data TYPE zcl_gui_alv_tree_util=>ts_node_data,
    ls_hierarchy TYPE zcl_gui_alv_tree_util=>ts_hierarchy.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_data TYPE REF TO data.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_key            TYPE string,
    lv_key_value      TYPE string,
    lv_node_text      TYPE string,
    lv_node_level     TYPE int4,
    lv_last_node_id   TYPE sysuuid_x16,
    lv_node_level_key TYPE string.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_key_value>      TYPE any,
    <lfs_node_data>      TYPE any,
    <lfs_node_level_key> TYPE any.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Constitution de la Clef et détermination du Noeud où
  " ajouter l'entrée
  " -----------------------------------------------------------

  " Parcours l'ensemble des Clefs
  LOOP AT it_component_key ASSIGNING FIELD-SYMBOL(<lfs_s_component_key>).

    " Incrémentation niveau Hiérarchique
    ADD 1 TO lv_node_level.

    " Récupération de la valeur de la clef
    ASSIGN COMPONENT <lfs_s_component_key> OF STRUCTURE is_data
                                                     TO <lfs_key_value>.
    IF sy-subrc NE 0.
      " Pas de correspondance
      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    IF lv_key IS INITIAL.
      " Initialisation de la Clef
      lv_key = <lfs_key_value>.

    ELSE.
      " Concaténe la clef
      lv_key_value = |{ <lfs_key_value> }|.
      CONCATENATE lv_key lv_key_value INTO lv_key RESPECTING BLANKS.

    ENDIF.

    TRY.
        " Récupération du Noeud correspondant à cette clef
        lv_last_node_id = me->mt_key[ key = lv_key ]-node_id.

      CATCH cx_sy_itab_line_not_found.
        " Le Noeud correspondant à cette clef n'existe pas
        ""  --> Récupération données Hiérarchique
        CLEAR : ls_hierarchy.
        READ TABLE it_hierarchy WITH TABLE KEY node_level = lv_node_level
                                          INTO ls_hierarchy.

        IF  <lfs_key_value> IS INITIAL
        AND ls_hierarchy-hide_if_empty EQ abap_true.
          " Ne pas afficher si vide
          ""  --> Passe à l'itération suivante
          CONTINUE.

        ENDIF.

        " Initialisation des données à afficher
        lo_data = zcl_gui_alv_tree_util=>display_data_set(
          is_data               = is_data
          it_component_display  = ls_hierarchy-t_component_display
          it_component_excluded = ls_hierarchy-t_component_excluded
        ).

        " Initialisation pointeur sur les données
        ASSIGN lo_data->* TO <lfs_node_data>.

        " Initialisation Texte du Noeud
        lv_node_text = zcl_gui_alv_tree_util=>_node_text_set(
          is_data      = is_data
          is_hierarchy = ls_hierarchy
        ).

        IF NOT ls_hierarchy-node_level_key_fieldname IS INITIAL.
          " Récupération valeur Clef niveau de Noeud
          ASSIGN COMPONENT ls_hierarchy-node_level_key_fieldname
              OF STRUCTURE <lfs_node_data>
                        TO <lfs_node_level_key>.
          lv_node_level_key = <lfs_node_level_key>.

        ENDIF.

        ""  --> Création du Noeud
        ls_key-node_id = me->node_data_add(
          is_data           = <lfs_node_data>
          iv_fieldname      = ls_hierarchy-fieldname
          iv_node_text      = lv_node_text
          iv_has_child      = abap_true
          is_node_layout    = ls_hierarchy-node_layout
          it_item_layout    = ls_hierarchy-t_item_layout
          iv_node_level_key = lv_node_level_key
          iv_parent_node_id = lv_last_node_id
        ).

        ""  --> Création d'une nouvelle entrée
        ls_key-key = lv_key.
        INSERT ls_key INTO TABLE me->mt_key.

        ""  --> Initialisation dernière clef
        lv_last_node_id = ls_key-node_id.

    ENDTRY.

  ENDLOOP.

  " -----------------------------------------------------------
  " Création Noeud le plus bas
  " -----------------------------------------------------------

  " Récupération valeur du champ à afficher
  ASSIGN COMPONENT is_hierarchy_lower-fieldname
      OF STRUCTURE is_data TO <lfs_key_value>.
  IF  <lfs_key_value> IS INITIAL
  AND is_hierarchy_lower-hide_if_empty EQ abap_true.
    " Ne pas afficher si vide
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  IF NOT is_hierarchy_lower-node_level_key_fieldname IS INITIAL.
    " Récupération valeur Clef niveau de Noeud
    ASSIGN COMPONENT is_hierarchy_lower-node_level_key_fieldname
        OF STRUCTURE is_data TO <lfs_node_level_key>.
    IF  <lfs_node_level_key> IS INITIAL
    AND is_hierarchy_lower-hide_if_null EQ abap_true.
      " Ne pas afficher si vide
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

  ENDIF.

  " Initialisation Texte du Noeud
  lv_node_text = zcl_gui_alv_tree_util=>_node_text_set(
    is_data      = is_data
    is_hierarchy = is_hierarchy_lower
  ).

  " Initialisation des données à afficher
  lo_data = zcl_gui_alv_tree_util=>display_data_set(
    is_data               = is_data
    it_component_display  = is_hierarchy_lower-t_component_display
    it_component_excluded = is_hierarchy_lower-t_component_excluded
  ).

  " Initialisation pointeur sur les données à afficher
  ASSIGN lo_data->* TO <lfs_node_data>.

  IF NOT ls_hierarchy-node_level_key_fieldname IS INITIAL.
    " Récupération valeur Clef niveau de Noeud
    ASSIGN COMPONENT ls_hierarchy-node_level_key_fieldname OF STRUCTURE <lfs_node_data>
                                                                     TO <lfs_node_level_key>.
    lv_node_level_key = <lfs_node_level_key>.

  ENDIF.

  " Création du Noeud
  me->node_data_add(
    is_data           = <lfs_node_data>
    iv_node_text      = lv_node_text
    iv_has_child      = abap_false
    iv_fieldname      = is_hierarchy_lower-fieldname
    is_node_layout    = is_hierarchy_lower-node_layout
    it_item_layout    = is_hierarchy_lower-t_item_layout
    iv_node_level_key = lv_node_level_key
    iv_parent_node_id = lv_last_node_id
  ).

ENDMETHOD.


METHOD alv_tree_populate.
*&---------------------------------------------------------------------*
*& Méthode         : ALV_TREE_POPULATE                                 *
*& Classe          : ZCL_GUI_ALV_TREE_UTIL                             *
*& Description     : Alimentation ALV Tree à partir des Noeuds chargés *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 28/01/2016                                           *
*                                                                      *
*& Responsable Technique  : Véhier Olivier                             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  REFRESH : et_level_node_key.

  " -----------------------------------------------------------
  " Alimentation de l'ALV Tree
  " -----------------------------------------------------------

  LOOP AT me->mt_node_data ASSIGNING FIELD-SYMBOL(<lfs_s_node_data>).

    " Ajout et de ses enfants
    me->node_add_recursive(
      EXPORTING
        is_node_data           = <lfs_s_node_data>
        iv_fill_level_node_key = boolc( et_level_node_key IS SUPPLIED )
      CHANGING
        ct_level_node_key      = et_level_node_key
    ).

    " Allège la table au fur et à mesure
    DELETE me->mt_node_data USING KEY loop_key.

  ENDLOOP.

  " ----------------------------------------------------------
  " Mise à jour des données à afficher
  " -----------------------------------------------------------

  me->mo_alv_tree->update_calculations( ).

ENDMETHOD.


METHOD alv_tree_populate_auto.
*&---------------------------------------------------------------------*
*& Méthode         : ALV_TREE_POPULATE_AUTO                            *
*& Classe          : ZCL_GUI_ALV_TREE_UTIL                             *
*& Description     : Alimentation automatique de l'ALV Tree            *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 28/01/2016                                           *
*                                                                      *
*& Responsable Technique  : Véhier Olivier                             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_sort_table    TYPE abap_sortorder_tab,
    lt_component_key TYPE cgpl_field_names.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_sort_table TYPE abap_sortorder.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_alv_tree_util TYPE REF TO zcl_gui_alv_tree_util.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_lines TYPE i.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  REFRESH : et_level_node_key.

  " -----------------------------------------------------------
  " Création de l'instance utilitaire
  " -----------------------------------------------------------

  CREATE OBJECT lo_alv_tree_util
    EXPORTING
      io_alv_tree = co_alv_tree.

  " Suppression de tous les Noeuds existant
  co_alv_tree->delete_all_nodes( ).

  " -----------------------------------------------------------
  " Constitution des champs clefs
  " -----------------------------------------------------------

  LOOP AT it_hierarchy ASSIGNING FIELD-SYMBOL(<lfs_s_hierarchy>)."TO lines( it_hierarchy ) - 1.

    IF sy-tabix LE lines( it_hierarchy ) - 1.
      " Ajout du champ Clef
      APPEND <lfs_s_hierarchy>-fieldname TO lt_component_key.

    ENDIF.

    " Ajout dans la table de Tri
    ls_sort_table-name = <lfs_s_hierarchy>-fieldname.
    APPEND ls_sort_table TO lt_sort_table.

  ENDLOOP.

  " Récupération de la personnalisation du dernier niveau
  READ TABLE it_hierarchy INDEX lines( it_hierarchy ) ASSIGNING FIELD-SYMBOL(<lfs_s_hierarchy_lower>).

  " -----------------------------------------------------------
  " Constitution des champs clefs
  " -----------------------------------------------------------

  SORT it_alv_tree_data BY (lt_sort_table).

  " -----------------------------------------------------------
  " Alimentation des Noeuds (interne)
  " -----------------------------------------------------------

  LOOP AT it_alv_tree_data ASSIGNING FIELD-SYMBOL(<lfs_s_alv_tree_data>).

    " Place la donnée dans le Noeud appropriée (Création Noeud Racine et Enfant si besoin)
    lo_alv_tree_util->add_to_appropriate_node(
        is_data            = <lfs_s_alv_tree_data>
        it_hierarchy       = it_hierarchy
        it_component_key   = lt_component_key
        is_hierarchy_lower = <lfs_s_hierarchy_lower>
    ).

  ENDLOOP.

  " -----------------------------------------------------------
  " Initialisation des Noeuds de l'ALV (ALV Tree)
  " -----------------------------------------------------------

  IF et_level_node_key IS SUPPLIED.
    " Avec récupération des Niveaux
    lo_alv_tree_util->alv_tree_populate( IMPORTING et_level_node_key = et_level_node_key ).

  ELSE.
    " Sans récupération des Niveaux
    lo_alv_tree_util->alv_tree_populate( ).

  ENDIF.

ENDMETHOD.


METHOD constructor.
*&---------------------------------------------------------------------*
*& Méthode         : CONSTRUCTOR                                       *
*& Classe          : ZCL_GUI_ALV_TREE_UTIL                             *
*& Description     : Création d'une instance                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 28/01/2016                                           *
*                                                                      *
*& Responsable Technique  : Véhier Olivier                             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation des attributs
  " -----------------------------------------------------------

  me->mo_alv_tree = io_alv_tree.

ENDMETHOD.


METHOD display_data_set.
*&---------------------------------------------------------------------*
*& Méthode         : DISPLAY_DATA_SET                                  *
*& Classe          : ZCL_GUI_ALV_TREE_UTIL                             *
*& Description     : Initialisation des données à afficher             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 28/01/2016                                           *
*                                                                      *
*& Responsable Technique  : Véhier Olivier                             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_value_source> TYPE any,
    <lfs_value_target> TYPE any.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Création de la structure de Travail
  " -----------------------------------------------------------

  " Création de la donnée
  CREATE DATA ro_data LIKE is_data.
  ASSIGN ro_data->* TO FIELD-SYMBOL(<lfs_data>).

  " -----------------------------------------------------------
  " Initialisation des données à afficher
  " -----------------------------------------------------------

  IF it_component_display[] IS INITIAL.
    " Affiche toutes les données
    MOVE-CORRESPONDING is_data TO <lfs_data>.

    " Exclusion des données à afficher
    IF NOT it_component_excluded[] IS INITIAL.

      LOOP AT it_component_excluded ASSIGNING FIELD-SYMBOL(<lfs_s_component_excluded>).

        UNASSIGN : <lfs_value_source>, <lfs_value_target>.

        " Initialisation pointeur sur champ cible
        ASSIGN COMPONENT <lfs_s_component_excluded>
            OF STRUCTURE <lfs_data>
                      TO <lfs_value_target>.
        IF sy-subrc NE 0.
          " Pas de correspondance
          ""  --> Passe à l'itération suivante
          CONTINUE.

        ENDIF.

        CLEAR : <lfs_value_target>.

      ENDLOOP.

    ENDIF.

  ELSE.
    " Initialisation des données à afficher
    LOOP AT it_component_display ASSIGNING FIELD-SYMBOL(<lfs_s_component_display>).

      UNASSIGN : <lfs_value_source>, <lfs_value_target>.

      " Initialisation pointeur sur champ source
      ASSIGN COMPONENT <lfs_s_component_display>
          OF STRUCTURE is_data
                    TO <lfs_value_source>.
      IF sy-subrc NE 0.
        " Pas de correspondance
        ""  --> Passe à l'itération suivante
        CONTINUE.

      ENDIF.

      " Initialisation pointeur sur champ cible
      ASSIGN COMPONENT <lfs_s_component_display>
                    OF STRUCTURE <lfs_data>
                    TO <lfs_value_target>.

      " initialisation de la valeur
      <lfs_value_target> = <lfs_value_source>.

    ENDLOOP.

  ENDIF.

ENDMETHOD.


METHOD export_to_excel.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_solix         TYPE solix_tab,
    lt_children      TYPE lvc_t_nkey,
    lt_components    TYPE abap_component_tab,
    lt_fieldcatalog  TYPE lvc_t_fcat,
    lt_subtree_nodes TYPE lvc_t_nkey.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_components     TYPE abap_componentdescr,
    ls_table_settings TYPE zexcel_s_table_settings.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lot_outtab      TYPE REF TO data,
    lo_datadescr    TYPE REF TO cl_abap_datadescr,
    lo_outtab_line  TYPE REF TO data,
    lo_table_descr  TYPE REF TO cl_abap_tabledescr,
    lo_struct_descr TYPE REF TO cl_abap_structdescr.

  DATA :
    lo_excel        TYPE REF TO zcl_excel,
    lo_worksheet    TYPE REF TO zcl_excel_worksheet,
    lo_excel_writer TYPE REF TO zcl_excel_writer_2007.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_path     TYPE string,
    lv_xstrlen  TYPE i,
    lv_xstring  TYPE xstring,
    lv_filename TYPE string,
    lv_fullpath TYPE string.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_s_outtab> TYPE                 any,
    <lfs_t_outtab> TYPE STANDARD TABLE.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Récupération du FieldCatalog
  " -----------------------------------------------------------

  io_alv_tree->get_frontend_fieldcatalog(
    IMPORTING
      et_fieldcatalog   = lt_fieldcatalog
    EXCEPTIONS
      error_get_width   = 1
      cntl_system_error = 2
      dp_error          = 3
      failed            = 4
      OTHERS            = 5
  ).
  IF sy-subrc NE 0.
    " Une erreur est survenue
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Constitution du type de la ligne
  " -----------------------------------------------------------

  LOOP AT lt_fieldcatalog ASSIGNING FIELD-SYMBOL(<lfs_s_fieldcatalog>).

    CLEAR : ls_components.

    ls_components-name = <lfs_s_fieldcatalog>-fieldname.
    ls_components-type ?= cl_abap_datadescr=>describe_by_name( <lfs_s_fieldcatalog>-rollname ).
    APPEND ls_components TO lt_components.

  ENDLOOP.

  TRY.
      " Création de la structure dynamique
      lo_struct_descr ?= cl_abap_structdescr=>create( lt_components ).

      " Création du type de ligne
      CREATE DATA lo_outtab_line TYPE HANDLE lo_struct_descr.
      ASSIGN lo_outtab_line->* TO <lfs_s_outtab>.

      " Création de la table dynamique
      lo_datadescr ?= lo_struct_descr.
      lo_table_descr = cl_abap_tabledescr=>create( p_line_type = lo_datadescr ).

      " Création de la table dynmaique
      CREATE DATA lot_outtab TYPE HANDLE lo_table_descr.
      ASSIGN lot_outtab->* TO <lfs_t_outtab>.

    CATCH cx_sy_struct_creation cx_sy_table_creation.

  ENDTRY.

  " -----------------------------------------------------------
  " Récupération de tous les noeuds
  " -----------------------------------------------------------

  io_alv_tree->get_subtree(
    EXPORTING
      i_node_key         = cl_gui_alv_tree=>c_virtual_root_node
    IMPORTING
      et_subtree_nodes   = lt_subtree_nodes
    EXCEPTIONS
      node_key_not_found = 1
      OTHERS             = 2
  ).
  IF sy-subrc NE 0.
    " Une erreur est survenue
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Récupération des données affichées
  " -----------------------------------------------------------

  LOOP AT lt_subtree_nodes ASSIGNING FIELD-SYMBOL(<lfs_s_subtree_nodes>).

    " Récupération des Noeuds enfants
    io_alv_tree->get_children(
      EXPORTING
        i_node_key         = <lfs_s_subtree_nodes>
      IMPORTING
        et_children        = lt_children
      EXCEPTIONS
        historic_error     = 1
        node_key_not_found = 2
        OTHERS             = 3
    ).
    IF sy-subrc           EQ 0
    AND NOT lt_children[] IS INITIAL.
      " Niveau parent
      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    " Récupération des données affichées
    io_alv_tree->get_outtab_line(
      EXPORTING
        i_node_key     = <lfs_s_subtree_nodes>
      IMPORTING
        e_outtab_line  = <lfs_s_outtab>
      EXCEPTIONS
        node_not_found = 1
        OTHERS         = 2
    ).
    IF sy-subrc NE 0.
      " Une erreur est survenue
      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    " Ajout de l'entrée dans la table
    APPEND <lfs_s_outtab> TO <lfs_t_outtab>.

  ENDLOOP.

  " -----------------------------------------------------------
  " Détermination Emplacement de Sauvegarde
  " -----------------------------------------------------------

  IF  NOT iv_filename IS INITIAL
  AND NOT iv_filepath IS INITIAL.
    " Nom de fichier et Emplacement
    ""  --> Initialisation Emplacement de Sauvegarde
    lv_filename = |{ iv_filepath }\\{ iv_filename }|.

  ELSE.
    " Autres
    ""  --> Détermination Emplacement de Sauvegarde
    cl_gui_frontend_services=>file_save_dialog(
      EXPORTING
        default_extension         = '.xlsx'
        default_file_name         = CONV string( iv_filename )
        file_filter               = '*.xlsx'
        initial_directory         = CONV string( iv_filepath )
      CHANGING
        filename                  = lv_filename
        path                      = lv_path
        fullpath                  = lv_fullpath
      EXCEPTIONS
        cntl_error                = 1
        error_no_gui              = 2
        not_supported_by_gui      = 3
        invalid_default_file_name = 4
        OTHERS                    = 5
    ).

  ENDIF.

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF lv_filename IS INITIAL.
    " Aucun nom de fichier déterminé
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Export sous Excel
  " -----------------------------------------------------------

  TRY.
      " Création instance Excel
      CREATE OBJECT lo_excel.
      CREATE OBJECT lo_excel_writer.

      " Récupération feuille de travail
      lo_worksheet = lo_excel->get_active_worksheet( ).
      IF NOT lo_worksheet IS BOUND.
        " Aucune feuille de travail
        ""  --> Création nouvelle feuille de travail
        lo_worksheet = lo_excel->add_new_worksheet( CONV zexcel_sheet_title( iv_worksheet_name ) ).

      ELSE.
        " Renomme la feuille de travail
        lo_worksheet->set_title( ip_title = CONV zexcel_sheet_title( iv_worksheet_name ) ).

      ENDIF.

      " Initialisation propriétées
      ls_table_settings-top_left_row = 1.
      ls_table_settings-top_left_column = 'A'.

      " Pousse la table dans la feuille de travail
      lo_worksheet->bind_table(
          ip_table          = <lfs_t_outtab>
          is_table_settings = ls_table_settings
      ).

      " Transforme le fichier en binaire
      lv_xstring = lo_excel_writer->zif_excel_writer~write_file( io_excel = lo_excel ).
      lt_solix   = cl_bcs_convert=>xstring_to_solix( iv_xstring = lv_xstring ).
      lv_xstrlen = xstrlen( lv_xstring ).

      " Enregistre le fichier
      cl_gui_frontend_services=>gui_download(
        EXPORTING
          bin_filesize              = lv_xstrlen
          filename                  = lv_filename
          filetype                  = 'BIN'
        CHANGING
          data_tab                  = lt_solix
        EXCEPTIONS
          file_write_error          = 1
          no_batch                  = 2
          gui_refuse_filetransfer   = 3
          invalid_type              = 4
          no_authority              = 5
          unknown_error             = 6
          header_not_allowed        = 7
          separator_not_allowed     = 8
          filesize_not_allowed      = 9
          header_too_long           = 10
          dp_error_create           = 11
          dp_error_send             = 12
          dp_error_write            = 13
          unknown_dp_error          = 14
          access_denied             = 15
          dp_out_of_memory          = 16
          disk_full                 = 17
          dp_timeout                = 18
          file_not_found            = 19
          dataprovider_exception    = 20
          control_flush_error       = 21
          not_supported_by_gui      = 22
          error_no_gui              = 23
          OTHERS                    = 24
      ).

      " Retourne le code retour
      rv_subrc = sy-subrc.

    CATCH zcx_excel.
      " Une erreur est survenue
      ""  --> Initialisation code retour en erreur
      rv_subrc = 4.

  ENDTRY.

ENDMETHOD.


METHOD hierarchy_usage.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_data TYPE REF TO data.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_node_data> TYPE any.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Exploitation des données de la Hiérarchie
  " -----------------------------------------------------------

  " Initialisation des données à afficher
  lo_data = zcl_gui_alv_tree_util=>display_data_set(
    is_data               = is_data
    it_component_display  = is_hierarchy-t_component_display
    it_component_excluded = is_hierarchy-t_component_excluded
  ).

  " Initialisation pointeur sur les données
  ASSIGN lo_data->* TO <lfs_node_data>.

  " Retourne les données
  es_node_data = <lfs_node_data>.

  IF ev_node_text IS SUPPLIED.
    " -----------------------------------------------------------
    " Retourne Texte du Noeud
    " -----------------------------------------------------------

    " Retourne Texte du Noeud
    ev_node_text = zcl_gui_alv_tree_util=>_node_text_set(
      is_data      = is_data
      is_hierarchy = is_hierarchy
    ).

  ENDIF.

  IF  ev_node_level_key IS SUPPLIED
  AND NOT is_hierarchy-node_level_key_fieldname IS INITIAL.
    " -----------------------------------------------------------
    " Retourne Clef niveau de Noeud
    " -----------------------------------------------------------

    ASSIGN COMPONENT is_hierarchy-node_level_key_fieldname
        OF STRUCTURE is_data
                  TO FIELD-SYMBOL(<lfs_node_level_key>).
    ev_node_level_key = <lfs_node_level_key>.

  ENDIF.

ENDMETHOD.


METHOD node_add_recursive.
*&---------------------------------------------------------------------*
*& Méthode         : NODE_ADD_RECURSIVE                                *
*& Classe          : ZCL_GUI_ALV_TREE_UTIL                             *
*& Description     : Création Noeud dans l'ALV Tree (récursif)         *
*& Description     : Création Noeud dans l'ALV Tree (récursif)         *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 28/01/2016                                           *
*                                                                      *
*& Responsable Technique  : Véhier Olivier                             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_level_node_key TYPE zcl_gui_alv_tree_util=>ts_level_node_key.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_new_node_key    TYPE lvc_nkey,
    lv_parent_node_key TYPE lvc_nkey.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_node_data> TYPE any.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Création du Noeud
  " -----------------------------------------------------------

  " Initialisation pointeur sur les données
  ASSIGN is_node_data-node_data->* TO <lfs_node_data>.

  " Création Noeud entête
  me->mo_alv_tree->add_node(
    EXPORTING
      i_relat_node_key     = iv_parent_node_key
      i_relationship       = cl_gui_column_tree=>relat_last_child
      is_outtab_line       = <lfs_node_data>
      is_node_layout       = is_node_data-node_layout
      it_item_layout       = is_node_data-t_item_layout
      i_node_text          = is_node_data-node_text
   IMPORTING
     e_new_node_key        = lv_new_node_key
    EXCEPTIONS
      relat_node_not_found = 1
      node_not_found       = 2
      OTHERS               = 3
  ).

  IF  iv_fill_level_node_key EQ abap_true
  AND ct_level_node_key      IS SUPPLIED.
    " Ajout du niveau de la Clef
    ls_level_node_key-node_key  = lv_new_node_key.
    ls_level_node_key-node_text = is_node_data-node_text.
    ls_level_node_key-fieldname = is_node_data-fieldname.
    IF iv_parent_node_text IS INITIAL.
      " Initialisation Texte
      ls_level_node_key-node_text_complete = ls_level_node_key-node_text.

    ELSE.
      " Concaténation Texte (complet)
      ls_level_node_key-node_text_complete = |{ iv_parent_node_text }{ ls_level_node_key-node_text_complete }|.

    ENDIF.

    ls_level_node_key-node_level_key  = is_node_data-node_level_key.
    ls_level_node_key-parent_node_key = iv_parent_node_key.
    INSERT ls_level_node_key INTO TABLE ct_level_node_key.

  ENDIF.

  IF is_node_data-has_child EQ abap_true.
    " -----------------------------------------------------------
    " Création Noeud(s) Enfant
    " -----------------------------------------------------------

    " Récupération position première entrée correspondant aux enfants
    READ TABLE me->mt_node_data WITH KEY parent_node_id = is_node_data-node_id
                            TRANSPORTING NO FIELDS BINARY SEARCH.
    IF sy-subrc EQ 0.
      " Parcours des enfants
      LOOP AT me->mt_node_data ASSIGNING FIELD-SYMBOL(<lfs_s_child_node_data>)
                  FROM sy-tabix.

        IF <lfs_s_child_node_data>-parent_node_id NE is_node_data-node_id.
          " On ne traite plus le même Noeud Parent
          ""  --> Arrêt de la boucle
          EXIT.

        ENDIF.

        " Création du Noeud
        me->node_add_recursive(
          EXPORTING
            is_node_data           = <lfs_s_child_node_data>
            iv_parent_node_key     = lv_new_node_key
            iv_parent_node_text    = ls_level_node_key-node_text_complete
            iv_fill_level_node_key = iv_fill_level_node_key
          CHANGING
            ct_level_node_key      = ct_level_node_key
        ).

        " Suppression de l'entrée
        DELETE me->mt_node_data USING KEY loop_key.

      ENDLOOP.

    ENDIF.

  ENDIF.

ENDMETHOD.


METHOD node_data_add.
*&---------------------------------------------------------------------*
*& Méthode         : NODE_DATA_ADD                                     *
*& Classe          : ZCL_GUI_ALV_TREE_UTIL                             *
*& Description     : Alimentation table interne des Noeuds à créer     *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 28/01/2016                                           *
*                                                                      *
*& Responsable Technique  : Véhier Olivier                             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_key       TYPE zcl_gui_alv_tree_util=>ts_key,
    ls_node_data TYPE zcl_gui_alv_tree_util=>ts_node_data.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_abap_structdescr TYPE REF TO cl_abap_structdescr.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_key_value> TYPE any,
    <lfs_node_data> TYPE any.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Création nouveau Noeud
  " -----------------------------------------------------------

  " Récupération description
  lo_abap_structdescr ?= cl_abap_structdescr=>describe_by_data( p_data = is_data ).

  " Création de la données
  CREATE DATA ls_node_data-node_data TYPE HANDLE lo_abap_structdescr.
  ASSIGN ls_node_data-node_data->* TO <lfs_node_data>.

  " Initialisation des données
  <lfs_node_data>             = is_data.
  ls_node_data-node_id        = rv_node_id = cl_system_uuid=>create_uuid_x16_static( ).
  ls_node_data-has_child      = iv_has_child.
  ls_node_data-fieldname      = iv_fieldname.
  ls_node_data-node_text      = iv_node_text.
  ls_node_data-node_layout    = is_node_layout.
  ls_node_data-t_item_layout  = it_item_layout.
  ls_node_data-node_level_key = iv_node_level_key.
  ls_node_data-parent_node_id = iv_parent_node_id.

  " Ajout du Noeud
  INSERT ls_node_data INTO TABLE me->mt_node_data.

ENDMETHOD.


METHOD _node_text_set.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
      lt_node_text_dynamic TYPE zcl_gui_alv_tree_util=>tt_node_text_dynamic.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_node_text TYPE string,
    lv_separator TYPE string.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation Texte du Noeud
  " -----------------------------------------------------------

  IF NOT is_hierarchy-node_text_fixed IS INITIAL.
    " Texte fixe
    ""  --> Utilisation du Texte fournis
    rv_node_text = is_hierarchy-node_text_fixed.

  ELSE.
    " Texte dynamique
    IF NOT is_hierarchy-node_text_dynamic[] IS INITIAL.
      " Table de champs à utiliser
      ""  --> Utilisation de ces champs
      lt_node_text_dynamic[] = is_hierarchy-node_text_dynamic[].

    ELSE.
      " Aucun texte défini
      ""  --> Utilisation du champ relatif au Noeud
      APPEND VALUE #(
        fieldname = is_hierarchy-fieldname
        alpha_in  = is_hierarchy-node_text_alpha_in
      ) TO lt_node_text_dynamic.

    ENDIF.

    " Texte dynamique
    LOOP AT lt_node_text_dynamic
      ASSIGNING FIELD-SYMBOL(<lfs_s_node_text_dyn>).

      IF <lfs_s_node_text_dyn>-separator IS INITIAL.
        " Pas de séparateur
        ""  --> Ajoute un espace
        lv_separator = ' '.                                 "#EC NOTEXT

      ELSE.
        " Séparateur défini
        ""  --> Utilisation de ce séparateur
        lv_separator = <lfs_s_node_text_dyn>-separator.

      ENDIF.

      " Initialisation Texte à afficher à la valeur du champ relatif au Noeud
      ASSIGN COMPONENT <lfs_s_node_text_dyn>-fieldname
          OF STRUCTURE is_data
                    TO FIELD-SYMBOL(<lfs_node_text>).
      IF sy-subrc NE 0 OR (
        <lfs_node_text> IS INITIAL AND <lfs_s_node_text_dyn>-even_if_empty EQ abap_false
        ).
        " Champ inexistant
        ""  --> Passe à l'itération suivante
        CONTINUE.

      ENDIF.

      IF <lfs_s_node_text_dyn>-alpha_in EQ abap_false.
        " Affichage Format Externe
        lv_node_text = |{ <lfs_node_text> ALPHA = OUT }|.

      ELSE.
        " Texte Format Interne
        lv_node_text = <lfs_node_text>.

      ENDIF.

      IF <lfs_s_node_text_dyn>-condense EQ abap_true.
        " Concaténation sans espace
        CONDENSE lv_node_text.

      ENDIF.

      IF rv_node_text IS INITIAL.
        " Pas de texte
        ""  --> Affichage Format Interne
        rv_node_text = lv_node_text.

      ELSE.
        " Texte déjà initialisé
        ""  --> Concaténation
        rv_node_text = |{ rv_node_text }{ lv_separator }{ lv_node_text }|.

      ENDIF.

    ENDLOOP.

  ENDIF.

ENDMETHOD.
ENDCLASS.
