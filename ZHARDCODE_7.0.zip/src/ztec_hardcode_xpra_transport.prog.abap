*&---------------------------------------------------------------------*
*& Report  ZTEC_HARDCODE_XPRA_TRANSPORT
*&
*&---------------------------------------------------------------------*
*& Copyright © 13/01/2016, Olivier Véhier                              *
*&                                                                     *
*& Permission is hereby granted, free of charge, to any person         *
*& obtaining a copy of this software and associated documentation      *
*& files (the "Software"), to deal in the Software without restriction *
*& including without limitation the rights to use, copy, modify,       *
*& merge, publish, distribute, sublicense, and/or sell copies of the   *
*& Software, and to permit persons to whom the Software is furnished   *
*& to do so, subject to the following conditions:                      *
*&                                                                     *
*& The above copyright notice and this permission notice shall be      *
*& included in all copies or substantial portions of the Software.     *
*&                                                                     *
*& THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,     *
*& EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES     *
*& OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND            *
*& NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS *
*& BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN  *
*& ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN   *
*& CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE    *
*& SOFTWARE.                                                           *
*&                                                                     *
*& Except as contained in this notice, the name of Olivier Véhier      *
*& shall not be used in advertising or otherwise to promote the sale,  *
*& use or other dealings in this Software without prior written        *
*& authorization from Olivier Véhier.                                  *
*&---------------------------------------------------------------------*
*& Transport Hardcode
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*& Créé le      : 13/01/2016                                           *
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*

REPORT ztec_hardcode_xpra_transport.

***==================================================================***
**                         START-OF-SELECTION                         **
***==================================================================***
START-OF-SELECTION.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_xmsg         TYPE sprot_u_tab,
    lt_hardcode     TYPE zvtec_t_hc_tt,
    lt_hc_version   TYPE ztec_t_hc_vers_tt,
    lt_hc_parameter TYPE ztec_t_hc_param_tt,
    lt_hc_attribute TYPE ztec_t_hc_attr_tt,
    lt_source_code  TYPE ztec_t_hc_attribute_source.

***------------------------------------------------------------------***
**                             RANGES                                 **
***------------------------------------------------------------------***
  DATA :
        lr_mandt TYPE fkk_rt_mandt.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_return TYPE bapiret2.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_subrc       TYPE sy-subrc,
    lv_message     TYPE char255,
    lv_destination TYPE rfcdest.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " Récupération registre des Hardcodes à transporter
  SELECT * FROM ztec_t_hc_trans
          WHERE processed_at EQ @space
     INTO TABLE @DATA(lt_hc_trans).
  IF sy-subrc NE 0.
    " Aucun HC à transporter
    ""  --> Arrêt du programme
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Récupération HC à transporter
  " -----------------------------------------------------------

  " Extraction des Mandants
  LOOP AT lt_hc_trans ASSIGNING FIELD-SYMBOL(<lfs_s_hc_trans>).

    " Ajout du Mandant
    APPEND VALUE #(
      sign   = if_trba_selection_c=>gc_sign_incl
      option = SWITCH #( <lfs_s_hc_trans>-mandt_target
                          WHEN /spe/if_cons_constants_mvc=>c_range_wildcard THEN if_trba_selection_c=>gc_option_cp
                          ELSE if_trba_selection_c=>gc_option_eq
                        )
      low    = <lfs_s_hc_trans>-mandt_target
    ) TO lr_mandt.

  ENDLOOP.

  " Récupération des Destinations
  SELECT mandt, logsys FROM t000
        WHERE mandt      IN @lr_mandt
          AND cccategory NE 'S'  ##NO_TEXT
          AND logsys     NE @space
   INTO TABLE @DATA(lt_t000).
  IF sy-subrc NE 0.
    " Aucun système cible défini
    ""  --> Arrêt du programme
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Traitement de mise à jour des HC
  " -----------------------------------------------------------

  LOOP AT lt_hc_trans ASSIGNING <lfs_s_hc_trans>.

    " Ajout Log - Récupération HC Début
    IF 1 = 2. MESSAGE s701(zhardcode). ENDIF.
    APPEND VALUE #(
      langu    = sy-langu
      ag       = zcl_hardcode=>mc_my_msgid
      msgnr    = 701 ##NO_TEXT
      newobj   = abap_true
      var1     = <lfs_s_hc_trans>-repid
      var2     = <lfs_s_hc_trans>-system_source
      severity = if_msg_output=>msgtype_info
    ) TO lt_xmsg.

    " Récupération des Hardcodes dans le système Source
    CALL FUNCTION 'Z_HC_READ'
      DESTINATION <lfs_s_hc_trans>-system_source
      EXPORTING
        iv_repid                = <lfs_s_hc_trans>-repid
      IMPORTING
        et_hardcode             = lt_hardcode
        et_hardcode_source_code = lt_source_code
      EXCEPTIONS
        error_message           = 1
        system_failure          = 2 MESSAGE lv_message
        communication_failure   = 3 MESSAGE lv_message
        OTHERS                  = 4.
    IF sy-subrc NE 0.
      " Erreur
      ""  --> Ajout dans la Log
      IF 1 = 2. MESSAGE s702(zhardcode). ENDIF.
      APPEND VALUE #(
        langu    = sy-langu
        ag       = zcl_hardcode=>mc_my_msgid
        msgnr    = 702 ##NO_TEXT
        var1     = <lfs_s_hc_trans>-repid
        var2     = <lfs_s_hc_trans>-system_source
        severity = if_msg_output=>msgtype_error
      ) TO lt_xmsg.

      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    " Ajout Log - Récupération HC Fin
    IF 1 = 2. MESSAGE s703(zhardcode). ENDIF.
    APPEND VALUE #(
      langu    = sy-langu
      ag       = zcl_hardcode=>mc_my_msgid
      msgnr    = 703 ##NO_TEXT
      var1     = <lfs_s_hc_trans>-repid
      var2     = <lfs_s_hc_trans>-system_source
      severity = if_msg_output=>msgtype_success
    ) TO lt_xmsg.

    " Découpage des HC par typologie
    LOOP AT lt_hardcode ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode>).

      " Initialisation données Version
      APPEND CORRESPONDING #( <lfs_s_hardcode> ) TO lt_hc_version.

      " Initialisation données Paramètres
      APPEND CORRESPONDING #( <lfs_s_hardcode> ) TO lt_hc_parameter.

      " Initialisation données Attributs
      APPEND CORRESPONDING #( <lfs_s_hardcode> ) TO lt_hc_attribute.

    ENDLOOP.

    " Tri et suppression des doublons
    SORT lt_hc_version   BY version_guid.
    SORT lt_hc_parameter BY parameter_guid.
    SORT lt_hc_attribute BY attribute_guid_regroup attribute_guid.
    DELETE ADJACENT DUPLICATES FROM lt_hc_version   COMPARING version_guid.
    DELETE ADJACENT DUPLICATES FROM lt_hc_parameter COMPARING parameter_guid.
    DELETE ADJACENT DUPLICATES FROM lt_hc_attribute COMPARING attribute_guid_regroup attribute_guid.

    " Alimentation des Hardcodes
    LOOP AT lt_t000 ASSIGNING FIELD-SYMBOL(<lfs_s_t000>).

      " Ajout Log - Mise à jour HC début
      IF 1 = 2. MESSAGE s704(zhardcode). ENDIF.
      APPEND VALUE #(
        langu    = sy-langu
        ag       = zcl_hardcode=>mc_my_msgid
        msgnr    = 704 ##NO_TEXT
        newobj   = abap_true
        var1     = <lfs_s_hc_trans>-repid
        var2     = <lfs_s_t000>-mandt
        var3     = <lfs_s_t000>-logsys
        severity = if_msg_output=>msgtype_info
      ) TO lt_xmsg.

      " MàJ HC dans le mandant cible
      CALL FUNCTION 'Z_HC_TRANSPORT'
        DESTINATION <lfs_s_t000>-logsys
        EXPORTING
          iv_repid              = <lfs_s_hc_trans>-repid
          it_hc_version         = lt_hc_version
          it_hc_parameter       = lt_hc_parameter
          it_hc_attribute       = lt_hc_attribute
          it_hc_source_code     = lt_source_code
        IMPORTING
          es_return             = ls_return
        EXCEPTIONS
          error_message         = 1
          system_failure        = 2 MESSAGE lv_message
          communication_failure = 3 MESSAGE lv_message
          OTHERS                = 4.
      IF sy-subrc NE 0.
        " Erreur appel RFC
        ""  --> Ajout dans la Log
        IF 1 = 2. MESSAGE s705(zhardcode). ENDIF.
        APPEND VALUE #(
          langu    = sy-langu
          ag       = zcl_hardcode=>mc_my_msgid
          msgnr    = 705 ##NO_TEXT
          var1     = <lfs_s_hc_trans>-repid
          var2     = <lfs_s_t000>-mandt
          var3     = <lfs_s_t000>-logsys
          severity = if_msg_output=>msgtype_error
        ) TO lt_xmsg.

        ""  --> Passe à l'itération suivante
        CONTINUE.

      ELSEIF ls_return-type CS 'AE'. ##NO_TEXT
        " Erreur lors de la MàJ
        APPEND VALUE #(
          langu    = sy-langu
          ag       = ls_return-id
          msgnr    = ls_return-number
          var1     = ls_return-message_v1
          var2     = ls_return-message_v2
          var3     = ls_return-message_v3
          var4     = ls_return-message_v4
          severity = if_msg_output=>msgtype_error
        ) TO lt_xmsg.

        ""  --> Passe à l'itération suivante
        CONTINUE.

      ELSE.
        " MàJ effectuée
        ""  --> Ajout Log - Mise à jour HC Fin
        IF 1 = 2. MESSAGE s706(zhardcode). ENDIF.
        APPEND VALUE #(
          langu    = sy-langu
          ag       = zcl_hardcode=>mc_my_msgid
          msgnr    = 706 ##NO_TEXT
          var1     = <lfs_s_hc_trans>-repid
          var2     = <lfs_s_t000>-mandt
          var3     = <lfs_s_t000>-logsys
          severity = if_msg_output=>msgtype_success
        ) TO lt_xmsg.

        ""  --> Initialisation TS traitement
        GET TIME STAMP FIELD <lfs_s_hc_trans>-processed_at.

      ENDIF.

    ENDLOOP.

    REFRESH : lt_source_code,  lt_hardcode.
    REFRESH : lt_hc_attribute, lt_hc_parameter, lt_hc_version.

  ENDLOOP.

  " -----------------------------------------------------------
  " Modification
  " -----------------------------------------------------------

  " MàJ table
  MODIFY ztec_t_hc_trans FROM TABLE lt_hc_trans.
  COMMIT WORK.

  " -----------------------------------------------------------
  " Alimentation protocole
  " -----------------------------------------------------------

  " Ajout dans le Protocole
  CALL FUNCTION 'TR_APPEND_LOG'
    TABLES
      xmsg   = lt_xmsg
    EXCEPTIONS
      OTHERS = 1.

  " Pousse en mémoire
  CALL FUNCTION 'TR_FLUSH_LOG'.
