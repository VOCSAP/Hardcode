*&---------------------------------------------------------------------*
*& Include         : ZTEC_HARDCODE_C01                                 *
*& Programme Cadre : ZTEC_HARDCODE                                     *
*&---------------------------------------------------------------------*
*& Gestion Hardcode                                                    *
*& Include Définition Classe                                           *
*&---------------------------------------------------------------------*
*& Créé le      : 13/01/2016                                           *
*&                                                                     *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*



*----------------------------------------------------------------------*
*       CLASS LCL_MAIN DEFINIION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main DEFINITION FINAL CREATE PRIVATE.

*-- Publique
  PUBLIC SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

    TYPES :
      BEGIN OF ts_work_area_public,
        filename_import TYPE string,
      END OF   ts_work_area_public.

***------------------------------------------------------------------***
**                           ÉVENEMENTS                               **
***------------------------------------------------------------------***

*	Déclaration d'évènement

    " Evènement Sauvegarde
    EVENTS on_save.

    " Evènement Fermeture affichage
    EVENTS on_display_leave.

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Initialisation
    CLASS-METHODS initialization
      RETURNING VALUE(ro_instance) TYPE REF TO lcl_main.

    " Ordre de Transport - Création
    CLASS-METHODS transport_request_create
      IMPORTING
                !iv_repid        TYPE clike
      RETURNING VALUE(rv_trkorr) TYPE trkorr .

    " PopUp Confirmation Perte de données
    CLASS-METHODS call_popup_confirm_data_loss
      RETURNING VALUE(rv_confirmed) TYPE xsdboolean.

    " Aide à la Recherche Systeme
    CLASS-METHODS value_help_system
      RETURNING VALUE(rv_system) TYPE syst_sysid.

    " Editeur Range
    CLASS-METHODS range_editor_open
      IMPORTING !iv_read_only   TYPE xsdboolean DEFAULT abap_true
      CHANGING  !cr_range       TYPE tt_r_ranges
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Editeur de Code Source
    CLASS-METHODS source_code_editor_open
      IMPORTING !iv_read_only   TYPE xsdboolean DEFAULT abap_true
      CHANGING  !ct_source_code TYPE stringtab
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Traitement principal
    METHODS process
      IMPORTING
        !iv_event    TYPE clike OPTIONAL
        !io_argument TYPE REF TO data OPTIONAL
          PREFERRED PARAMETER !iv_event.

    " Sauvegarde
    METHODS save.

    " Evènement action utilisateur
    METHODS at_selection_screen.

    " Affichage écran de sélection
    METHODS at_selection_screen_output.

    " PBO - Gestion
    METHODS pbo.

    " PAI - Gestion
    METHODS pai.

    " Affichage Comparaison
    METHODS hardcode_compare_display
      IMPORTING !is_system_target  TYPE ts_system OPTIONAL
                !iv_refresh_local  TYPE xsdboolean OPTIONAL
                !iv_refresh_target TYPE xsdboolean OPTIONAL
                  PREFERRED PARAMETER !is_system_target.

    " Données modifiées
    METHODS is_changed
      RETURNING VALUE(rv_changed) TYPE flag.

    " Saisie
    METHODS call_popup_input_simple
      IMPORTING
                !iv_text        TYPE clike OPTIONAL
                !iv_title       TYPE clike
                !iv_read_only   TYPE xsdboolean DEFAULT abap_false
      EXPORTING
                !ev_subrc       TYPE sy-subrc
                ev_cancel       TYPE xsdboolean
      RETURNING VALUE(rv_input) TYPE ug_txtlg.

    " Enregistre Evènement
    METHODS event_register
      IMPORTING
        !iv_event TYPE clike.

    " Générateur d'évènement
    METHODS event_raise
      IMPORTING
        !iv_event TYPE clike.


***------------------------------------------------------------------***
**                           CONSTANTES                               **
***------------------------------------------------------------------***
    CONSTANTS :
      BEGIN OF mc_event,
        ecan                 TYPE string VALUE 'ECAN',             ##NO_TEXT
        back                 TYPE string VALUE 'BACK',             ##NO_TEXT
        exit                 TYPE string VALUE 'EXIT',             ##NO_TEXT
        save                 TYPE string VALUE 'SAVE',             ##NO_TEXT
        copy                 TYPE string VALUE 'COPY',             ##NO_TEXT
        ushm                 TYPE string VALUE 'USHM',             ##NO_TEXT
        dummy                TYPE string VALUE 'DUMMY',            ##NO_TEXT
        impex                TYPE string VALUE 'IMPEX',            ##NO_TEXT
        leave                TYPE string VALUE 'LEAVE',            ##NO_TEXT
        valid                TYPE string VALUE 'VALID',            ##NO_TEXT
        search               TYPE string VALUE 'SEARCH',           ##NO_TEXT
        cancel               TYPE string VALUE 'CANCEL',           ##NO_TEXT
        delete               TYPE string VALUE 'DELETE',           ##NO_TEXT
        refresh              TYPE string VALUE 'REFRESH',          ##NO_TEXT
        display              TYPE string VALUE 'DISPLAY',          ##NO_TEXT
        compare              TYPE string VALUE 'COMPARE',          ##NO_TEXT
        execute              TYPE string VALUE 'EXECUTE',          ##NO_TEXT
        transport            TYPE string VALUE 'TRANSPORT',        ##NO_TEXT
        range_set            TYPE string VALUE 'RANGE_SET',        ##NO_TEXT
        source_set           TYPE string VALUE 'SOURCE_SET',       ##NO_TEXT
        source_dispay        TYPE string VALUE 'SOURCE_DIS',       ##NO_TEXT
        range_display        TYPE string VALUE 'RANGE_DIS',        ##NO_TEXT
        display_leave        TYPE string VALUE 'DIS_LEAV',         ##NO_TEXT
        display_after_cancel TYPE string VALUE 'DISPLAY_AC',       ##NO_TEXT
      END OF mc_event.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    DATA : ms_work_area_public TYPE lcl_main=>ts_work_area_public READ-ONLY.
    DATA : mo_hardcode_maintain TYPE REF TO zcl_hardcode_maintain.

*-- Privée
  PRIVATE SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

    TYPES : tr_repid LIKE s_repid[].
    TYPES : tr_parameter_name LIKE s_pname[].
    TYPES : tr_attribute_name LIKE s_aname[].
    TYPES : tr_attribute_value_l LIKE s_alow[].
    TYPES : tr_attribute_value_h LIKE s_ahigh[].

    TYPES :
      BEGIN OF ts_selection_criteria_main,
        ov_repid TYPE REF TO sy-repid,
      END OF   ts_selection_criteria_main.

    TYPES :
      BEGIN OF ts_search_option,
        parameter_or  TYPE REF TO xsdboolean,
        attribute_or  TYPE REF TO xsdboolean,
        value_or      TYPE REF TO xsdboolean,
        value_high_or TYPE REF TO xsdboolean,
      END OF   ts_search_option.

    TYPES :
      BEGIN OF ts_selection_criteria_search,
        or_repid                TYPE REF TO lcl_main=>tr_repid,
        or_parameter_name       TYPE REF TO lcl_main=>tr_parameter_name,
        or_attribute_name       TYPE REF TO lcl_main=>tr_attribute_name,
        or_attribute_value_low  TYPE REF TO lcl_main=>tr_attribute_value_l,
        or_attribute_value_high TYPE REF TO lcl_main=>tr_attribute_value_h,
        search_option           TYPE lcl_main=>ts_search_option,
      END OF   ts_selection_criteria_search.

    " Type stockage critère de sélection
    TYPES :
      BEGIN OF ts_selection_criteria,
        ov_load_work TYPE REF TO flag,
        main         TYPE lcl_main=>ts_selection_criteria_main BOXED,
        search       TYPE lcl_main=>ts_selection_criteria_search BOXED,
      END OF   ts_selection_criteria.

    " Composantes élèments à afficher
    TYPES :
      BEGIN OF ts_process_instance,
        main_tree          TYPE REF TO lcl_main_tree,
        v_first_dispay     TYPE xsdboolean,
        v_registered_event TYPE string,
      END OF   ts_process_instance.

    TYPES :
      BEGIN OF ts_hardcode_search,
        repid          TYPE zvtec_t_hc-repid,
        parameter_name TYPE zvtec_t_hc-parameter_name,
        attribute_name TYPE zvtec_t_hc-attribute_name,
        attribute_key1 TYPE zvtec_t_hc-attribute_key1,
        attribute_key2 TYPE zvtec_t_hc-attribute_key2,
        attribute_key3 TYPE zvtec_t_hc-attribute_key3,
        attribute_key4 TYPE zvtec_t_hc-attribute_key4,
        attribute_low  TYPE zvtec_t_hc-attribute_low,
        attribute_high TYPE zvtec_t_hc-attribute_high,
      END OF   ts_hardcode_search.

    TYPES : tt_hardcode_search TYPE STANDARD TABLE OF ts_hardcode_search
                    WITH NON-UNIQUE KEY primary_key COMPONENTS repid parameter_name attribute_name
                                                               attribute_key1 attribute_key2 attribute_key3 attribute_key4.

    TYPES :
      BEGIN OF ts_work_area_private,
        t_hardcode_search TYPE lcl_main=>tt_hardcode_search,
      END OF   ts_work_area_private.

***------------------------------------------------------------------***
**                           ÉVENEMENTS                               **
***------------------------------------------------------------------***

*	Déclaration d'évènement

    " Evènement Affichage après Annulation
    EVENTS on_display_after_cancel.

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Constructeur
    METHODS constructor
      IMPORTING
        !iov_repid                    TYPE REF TO sy-repid
        !iov_load_work                TYPE REF TO flag
        !iov_value_or                 TYPE REF TO xsdboolean
        !iov_parameter_or             TYPE REF TO xsdboolean
        !iov_attribute_or             TYPE REF TO xsdboolean
        !iov_value_high_or            TYPE REF TO xsdboolean
        !ior_search_repid             TYPE REF TO tr_repid
        !ior_search_parameter_name    TYPE REF TO tr_parameter_name
        !ior_search_attribute_name    TYPE REF TO tr_attribute_name
        !ior_search_attribute_value_l TYPE REF TO tr_attribute_value_l
        !ior_search_attribute_value_h TYPE REF TO tr_attribute_value_h.

    " Hardcode - Affichage
    METHODS programm_display.

    " Hardcode - Recherche
    METHODS programm_search.

    " Hardcode - Suppression
    METHODS programm_deletion.

    " Hardcode - Copie
    METHODS programm_copy.

    " Hardcode - Transporter
    METHODS programm_transport.

    " Hardcode - Mettre à Jour la SHM
    METHODS programm_update_shm.

    " Hardcode - Programme Import / Export
    METHODS programm_impex_local.

    " Hardcode - Comparaison
    METHODS program_compare.

    " Hardcode - Export Local
    METHODS _programm_export_local.

    " Hardcode - Import Local
    METHODS _programm_import_local.

    " Hardcode - Recherche
    METHODS _programm_search.

    " Hardcode - Recherche - Exécution
    METHODS _programm_search_execute
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Hardcode - Recherche - Affichage
    METHODS _programm_search_display
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " PBO - Hardcode - Affichage
    METHODS pbo_0101.

    " PBO - Attribut
    METHODS pbo_0201.

    " PBO - Hardcode - Transport
    METHODS pbo_0301.

    " PBO - Hardcode - Transport Cible
    METHODS pbo_0302.

    " PBO - Hardcode - Recherche
    METHODS pbo_2000.

    " PBO - Hardcode - Affichage
    METHODS pai_0101
      IMPORTING
        !iv_ucomm TYPE sy-ucomm.

    " PAI - Attribut
    METHODS pai_0201
      IMPORTING
        !iv_ucomm TYPE sy-ucomm.

    " PAI - Hardcode - Transport
    METHODS pai_0301
      IMPORTING
        !iv_ucomm TYPE sy-ucomm.

    " PAI - Hardcode - Transport Cible
    METHODS pai_0302
      IMPORTING
        !iv_ucomm TYPE sy-ucomm.

    " PAI - Hardcode - Recherche
    METHODS pai_2000
      IMPORTING
        !iv_ucomm TYPE sy-ucomm.

    " Handler - Affichage après Annulation
    METHODS handler_on_display_aft_can
         FOR EVENT on_display_after_cancel OF lcl_main.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    DATA : ms_process_instance TYPE lcl_main=>ts_process_instance.
    DATA : ms_work_area_private TYPE lcl_main=>ts_work_area_private.
    DATA : ms_selection_criteria TYPE lcl_main=>ts_selection_criteria.

ENDCLASS.             "LCL_MAIN DEFINITION

*----------------------------------------------------------------------*
*       CLASS LCL_MAIN_TREE DEFINIION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main_tree DEFINITION FINAL FRIENDS lcl_main_tree_toolbar_handler.

*-- Publique
  PUBLIC SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

    " Type données à afficher
    TYPES :
      BEGIN OF ts_hc_data,
        version_guid                  TYPE ztec_t_hc_vers-version_guid,
        parameter_guid                TYPE ztec_t_hc_param-parameter_guid,
        attribute_guid_regroup        TYPE ztec_t_hc_attr-attribute_guid_regroup,
        repid                         TYPE ztec_t_hc_vers-repid,
        version_id                    TYPE ztec_t_hc_vers-version_id,
        version_primary               TYPE ztec_t_hc_vers-version_primary,
        version_primary_icon          TYPE icon-id,
        parameter_name                TYPE ztec_t_hc_param-parameter_name,
        attribute_name                TYPE ztec_t_hc_attr-attribute_name,
        attribute_key1                TYPE ztec_t_hc_attr-attribute_key1,
        attribute_key2                TYPE ztec_t_hc_attr-attribute_key2,
        attribute_key3                TYPE ztec_t_hc_attr-attribute_key3,
        attribute_key4                TYPE ztec_t_hc_attr-attribute_key4,
        attribute_as_range            TYPE ztec_t_hc_attr-attribute_as_range,
        attribute_as_range_icon       TYPE icon-id,
        attribute_as_source_code      TYPE ztec_t_hc_attr-attribute_as_source_code,
        attribute_as_source_code_icon TYPE icon-id,
      END OF   ts_hc_data.

    TYPES : tt_t_hc_data TYPE STANDARD TABLE OF ts_hc_data
                                        WITH NON-UNIQUE KEY primary_key
                                                 COMPONENTS version_guid parameter_guid attribute_guid_regroup.

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Constructor
    METHODS constructor
      IMPORTING
        !io_main           TYPE REF TO lcl_main
        !iv_repid          TYPE sy-repid
        !is_system         TYPE ts_system OPTIONAL
        !iv_read_only      TYPE xsdboolean DEFAULT abap_false
        !iv_container_name TYPE clike.

    " Destructeur
    METHODS free.

    " Traitement
    METHODS process
      IMPORTING
                !it_hardcode    TYPE zvtec_t_hc_tt
                !iv_event       TYPE clike
                !io_argument    TYPE REF TO data OPTIONAL
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Handler - ON_SAVE
    METHODS handler_on_save FOR EVENT on_save OF lcl_main.

    " Handler - ON_DISPLAY_LEAVE
    METHODS handler_on_display_leave FOR EVENT on_display_leave OF lcl_main.

    " Récupération ligne sélectionnée
    METHODS line_selected_get
      IMPORTING
                !iv_parent_node_ref   TYPE clike OPTIONAL
      EXPORTING
                !ev_subrc             TYPE sy-subrc
                !ev_selected_node     TYPE lvc_nkey
                !ev_node_text         TYPE lvc_value
                !et_item_layout       TYPE lvc_t_layi
                !es_node_layout       TYPE lvc_s_layn
                !ev_parent_node_key   TYPE lvc_nkey
      RETURNING VALUE(rs_outtab_line) TYPE lcl_main_tree=>ts_hc_data.

    " Récupération détail de l'Attribut
    METHODS attribute_detail_get_ref
      IMPORTING
        !iv_attribute_guid_regroup TYPE zvtec_t_hc-attribute_guid_regroup
      EXPORTING
        !eot_range                 TYPE REF TO zcl_hardcode_maintain=>tt_attribute_range_value_det
        !eot_source_code           TYPE REF TO stringtab.

***------------------------------------------------------------------***
**                           ÉVENEMENTS                               **
***------------------------------------------------------------------***

*	Déclaration d'évènement

    " Evènement changement
    EVENTS submit_change.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs
    CONSTANTS :
      BEGIN OF mc_node_level,
        version   TYPE zcl_gui_alv_tree_util=>ts_hierarchy-node_level VALUE 1, ##NO_TEXT
        parameter TYPE zcl_gui_alv_tree_util=>ts_hierarchy-node_level VALUE 2, ##NO_TEXT
        attribute TYPE zcl_gui_alv_tree_util=>ts_hierarchy-node_level VALUE 3, ##NO_TEXT
      END OF mc_node_level.

    DATA : mv_repid TYPE sy-repid READ-ONLY.
    DATA : ms_system TYPE ts_system READ-ONLY.

*-- Privée
  PRIVATE SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type


    TYPES :
      BEGIN OF ts_attribute_range,
        attribute_guid_regroup  TYPE ztec_t_hc_attr-attribute_guid_regroup,
        t_attribute_range_value TYPE zcl_hardcode_maintain=>tt_attribute_range_value_det,
      END OF   ts_attribute_range.

    TYPES : tt_attribute_range TYPE SORTED TABLE OF ts_attribute_range
                                      WITH UNIQUE KEY primary_key COMPONENTS attribute_guid_regroup.

    TYPES :
      BEGIN OF ts_source_code,
        attribute_guid_regroup TYPE ztec_t_hc_attr-attribute_guid_regroup,
        t_source_code          TYPE stringtab,
      END OF   ts_source_code.

    TYPES : tt_source_code TYPE SORTED TABLE OF ts_source_code
            WITH UNIQUE KEY primary_key COMPONENTS attribute_guid_regroup.

    TYPES :
      BEGIN OF ts_hc_data_internal,
        repid TYPE sy-repid.
    INCLUDE TYPE : ts_system AS system_key.
    TYPES :
      t_hardcode              TYPE zvtec_t_hc_tt,
      t_attribute_range       TYPE tt_attribute_range,
      t_source_code           TYPE tt_source_code,
      hierarchy_header_length TYPE int4,
      END OF   ts_hc_data_internal.

    TYPES : tt_t_hc_data_internal TYPE SORTED TABLE OF ts_hc_data_internal
                                       WITH UNIQUE KEY primary_key
                                            COMPONENTS repid system_key.

    " Données persistantes
    TYPES :
      BEGIN OF ts_persistent_data,
        t_hc_data TYPE tt_t_hc_data_internal,
      END OF   ts_persistent_data.

    " Container données
    TYPES :
      BEGIN OF ts_container_data,
        t_display_data TYPE tt_t_hc_data,
      END OF   ts_container_data.

    " Elèments pour affichage
    TYPES :
      BEGIN OF ts_display_element,
        t_fieldcatalog          TYPE        lvc_t_fcat,
        t_hierarchy             TYPE        zcl_gui_alv_tree_util=>tt_hierarchy,
        o_event                 TYPE REF TO lcl_main_tree_event,
        o_alv_tree              TYPE REF TO cl_gui_alv_tree,
        o_drag_and_drop         TYPE REF TO cl_dragdrop,
        o_drag_and_drop_handler TYPE REF TO lcl_tree_drag_and_drop,
        v_handle_tree           TYPE i,
        o_container             TYPE REF TO cl_gui_container,
        o_ccontainer            TYPE REF TO cl_gui_custom_container,
        v_container_name        TYPE char120,
        o_toolbar               TYPE REF TO cl_gui_toolbar,
        s_hierarchy_header      TYPE        treev_hhdr,
        o_toolbar_event         TYPE REF TO lcl_main_tree_toolbar_event,
        o_toolbar_handler       TYPE REF TO lcl_main_tree_toolbar_handler,
        t_toolbar_excluding     TYPE        ui_functions,
        v_header_length         TYPE treev_hhdr-width,
      END OF   ts_display_element.

    " Ensemble des composantes
    TYPES :
      BEGIN OF ts_main_tree,
        data            TYPE ts_container_data,
        display_element TYPE ts_display_element,
      END OF   ts_main_tree.

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Chargement des données
    METHODS load_data
      IMPORTING
                !it_hardcode    TYPE zvtec_t_hc_tt
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Initialisation données à afficher
    METHODS build_hierarchy_node
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Création des élèments à afficher
    METHODS build_display_element
      IMPORTING
        !iv_drag_and_drop TYPE xsdboolean DEFAULT abap_false.

    " Création barre de Tâche
    METHODS build_toolbar.

    " Création du Container
    METHODS build_container.

    " Création de l'ALV Tree
    METHODS build_alv_tree.

    " Création du FieldCatalog
    METHODS build_fieldcatalog.

    " Création de la Hiérarchie d'affichagee
    METHODS build_hierarchy.

    " Affichage des données
    METHODS display.

    " Initialisation Icône Primarité
    METHODS icon_version_primary_set
      IMPORTING !iv_version_primary    TYPE ztec_t_hc_vers-version_primary
      RETURNING VALUE(rv_icon_primary) TYPE icon-id.

    " Initialisation Icône Valeurs Multiple
    METHODS icon_attribute_range_set
      IMPORTING !iv_attribute_as_range TYPE ztec_t_hc_attr-attribute_as_range
      RETURNING VALUE(rv_icon_range)   TYPE icon-id.

    " Initialisation Icône Code Source
    METHODS icon_attribute_source_code_set
      IMPORTING !iv_attribute_as_source_code TYPE ztec_t_hc_attr-attribute_as_source_code
      RETURNING VALUE(rv_icon_range)         TYPE icon-id.

    " Ajout d'un Noeud
    METHODS node_add
      IMPORTING
                !is_data           TYPE ts_hc_data
                !iv_node_level     TYPE zcl_gui_alv_tree_util=>ts_hierarchy-node_level
                !iv_node_parent    TYPE lvc_nkey OPTIONAL
      RETURNING VALUE(rv_node_key) TYPE lvc_nkey.

    " Affichage du Détail de l'Attribut
    METHODS attribute_detail_display
      EXPORTING
                !ev_cancel                     TYPE flag
                !et_source_code                TYPE stringtab
                !er_ranges_value               TYPE tt_r_ranges
                !es_hardcode_data              TYPE ts_hc_data
                !es_new_attribute_logical_key  TYPE zcl_hardcode_maintain=>ts_attribute_logical_key
                !es_new_attribute_logical_keyx TYPE zcl_hardcode_maintain=>ts_attribute_logical_keyx
                !et_attribute_range_value      TYPE zcl_hardcode_maintain=>tt_attribute_range_value_det
      CHANGING  !cs_hardcode_data              TYPE ts_hc_data.

    " Modification affichage des boutons
    METHODS _toolbar_button_visibility_set
      IMPORTING
        !iv_cancel_visible    TYPE xsdboolean DEFAULT abap_undefined
        !iv_primarity_visible TYPE xsdboolean DEFAULT abap_undefined.

***------------------------------------------------------------------***
**                           ÉVENEMENTS                               **
***------------------------------------------------------------------***

*	Déclaration d'évènement

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    DATA : ms_persistent_data TYPE lcl_main_tree=>ts_persistent_data.
    DATA : mo_main TYPE REF TO lcl_main.
    DATA : mv_read_only TYPE xsdboolean.
    DATA : mo_attribute_detail TYPE REF TO lcl_attribute_detail.
    DATA : ms_display_element TYPE lcl_main_tree=>ts_main_tree.
    DATA : mt_level_node_key TYPE zcl_gui_alv_tree_util=>tt_level_node_key.

ENDCLASS.             "lcl_MAIN_TREE DEFINITION

*----------------------------------------------------------------------*
*       CLASS LCL_MAIN_TREE_TOOLBAR_EVENT DEFINIION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main_tree_toolbar_event DEFINITION FINAL CREATE PRIVATE.

*-- Publique
  PUBLIC SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type
    CONSTANTS :
      BEGIN OF mc_function,
        none             TYPE ui_func VALUE 'NONE',         ##NO_TEXT
        copy             TYPE ui_func VALUE 'COPY',         ##NO_TEXT
        cancel           TYPE ui_func VALUE 'CANCEL',       ##NO_TEXT
        delete           TYPE ui_func VALUE 'DELETE',       ##NO_TEXT
        modify           TYPE ui_func VALUE 'MODIFY',       ##NO_TEXT
        display          TYPE ui_func VALUE 'DISPLAY',      ##NO_TEXT
        compare          TYPE ui_func VALUE 'COMPARE',      ##NO_TEXT
        transport        TYPE ui_func VALUE 'TRANSPORT',    ##NO_TEXT
        update_shm       TYPE ui_func VALUE 'UPDATE_SHM',   ##NO_TEXT
        primary_set      TYPE ui_func VALUE 'PRIMARY_SET',  ##NO_TEXT
        export_local     TYPE ui_func VALUE 'EXPORT_LOCAL', ##NO_TEXT
        import_local     TYPE ui_func VALUE 'IMPORT_LOCAL', ##NO_TEXT
        version_create   TYPE ui_func VALUE 'VERSION_CREATE', ##NO_TEXT
        transport_menu   TYPE ui_func VALUE 'TRANSPORT_MENU',    ##NO_TEXT
        attribute_create TYPE ui_func VALUE 'ATTRIBUTE_CREATE', ##NO_TEXT
        parameter_create TYPE ui_func VALUE 'PARAMETERS_CREATE', ##NO_TEXT
      END OF mc_function.

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Génération instance Handler
    CLASS-METHODS factory
      IMPORTING !io_toolbar        TYPE REF TO cl_gui_toolbar
      RETURNING VALUE(ro_instance) TYPE REF TO lcl_main_tree_toolbar_event.

    " Handler Menu déroulant
    METHODS handler_dropdown_clicked
      FOR EVENT dropdown_clicked
                  OF cl_gui_toolbar
      IMPORTING !fcode !posx !posy.

    " Handler Clique Toolbar
    METHODS handler_function_selected
      FOR EVENT function_selected
                  OF cl_gui_toolbar
      IMPORTING !fcode.

***------------------------------------------------------------------***
**                           ÉVENEMENTS                               **
***------------------------------------------------------------------***

*	Déclaration d'évènement

    " Evènement Global - Copier
    EVENTS on_copy.

    " Evènement Global - Suppression
    EVENTS on_delete.

    " Evènement Global - Modification
    EVENTS on_modify.

    " Evènement Global - Affichage
    EVENTS on_display.

    " Evènement Global - Comparer
    EVENTS on_compare.

    " Evènement Global - Transporter
    EVENTS on_transport
      EXPORTING VALUE(iv_advanced_mode)    TYPE xsdboolean OPTIONAL
                VALUE(is_transport_target) TYPE ts_transport_target OPTIONAL.

    " Evènement Global - Mettre à Jour la SHM
    EVENTS on_update_shm.

    " Evènement Global - Export Local
    EVENTS on_export_local.

    " Evènement Global - Import Local
    EVENTS on_import_local
      EXPORTING VALUE(iv_filename) TYPE clike OPTIONAL.

    " Evènement Annuler
    EVENTS on_cancel.

    " Evènement Version - Création
    EVENTS on_version_create.

    " Evènement Version - Primarité
    EVENTS on_version_primary_set.

    " Evènement Paramètre - Création
    EVENTS on_parameter_create.

    " Evènement Attribut - Création
    EVENTS on_attribute_create.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    CLASS-DATA : my_id TYPE string VALUE 'MAIN_TOOLBAR'.    ##NO_TEXT

*-- Privée
  PRIVATE SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Constructeur
    METHODS constructor
      IMPORTING !io_toolbar TYPE REF TO cl_gui_toolbar.

***------------------------------------------------------------------***
**                           ÉVENEMENTS                               **
***------------------------------------------------------------------***

*	Déclaration d'évènement

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    DATA : mo_toolbar TYPE REF TO cl_gui_toolbar.

ENDCLASS.             "LCL_TOOLBAR_EVENT DEFINITION

*----------------------------------------------------------------------*
*       CLASS LCL_MAIN_TREE_EVENT DEFINIION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main_tree_event DEFINITION FINAL CREATE PRIVATE.

*-- Publique
  PUBLIC SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Génération instance
    CLASS-METHODS factory
      IMPORTING
                !io_main           TYPE REF TO lcl_main
                !io_main_tree      TYPE REF TO lcl_main_tree
                !io_alv_tree       TYPE REF TO cl_gui_alv_tree
      RETURNING VALUE(ro_instance) TYPE REF TO lcl_main_tree_event.

    " Handler Double Clique
    METHODS handler_item_double_click
      FOR EVENT item_double_click
          OF cl_gui_alv_tree
      IMPORTING
          !fieldname !node_key.

    " Handler Clique Bouton
    METHODS handler_button_click
      FOR EVENT button_click
                  OF cl_gui_alv_tree
      IMPORTING !fieldname !node_key.

***------------------------------------------------------------------***
**                           ÉVENEMENTS                               **
***------------------------------------------------------------------***

*  Déclaration d'évènements

    " Edition noeud hiérarchie
    EVENTS on_hierarchy_edit
      EXPORTING
        VALUE(iv_node_key) TYPE lvc_nkey.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

*-- Privée
  PRIVATE SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

***------------------------------------------------------------------***
**                           ÉVENEMENTS                               **
***------------------------------------------------------------------***


***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Constructeur
    METHODS constructor
      IMPORTING
        !io_main      TYPE REF TO lcl_main
        !io_main_tree TYPE REF TO lcl_main_tree
        !io_alv_tree  TYPE REF TO cl_gui_alv_tree.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    DATA : mo_main TYPE REF TO lcl_main.
    DATA : mo_main_tree TYPE REF TO lcl_main_tree.
    DATA : mo_alv_tree TYPE REF TO cl_gui_alv_tree.

ENDCLASS.             "LCL_MAIN_TREE_EVENT DEFINITION


*----------------------------------------------------------------------*
*       CLASS LCL_TREE_DRAG_AND_DROP DEFINIION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_tree_drag_and_drop DEFINITION FINAL.

*-- Publique
  PUBLIC SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    METHODS flavor_select FOR EVENT on_drop_get_flavor OF cl_gui_alv_tree
      IMPORTING !drag_drop_object !node_key.

    METHODS left_drag FOR EVENT on_drag_multiple OF cl_gui_alv_tree
      IMPORTING !drag_drop_object !fieldname !node_key_table.

    METHODS right_drop FOR EVENT on_drop OF cl_gui_alv_tree
      IMPORTING !drag_drop_object !node_key.

    METHODS drop_complete FOR EVENT on_drop_complete_multiple OF
                  cl_gui_alv_tree
      IMPORTING !drag_drop_object !fieldname !node_key_table.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs


*-- Privée
  PRIVATE SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs


ENDCLASS.             "lcl_TREE_DRAG_AND_DROP DEFINITION

*----------------------------------------------------------------------*
*       CLASS LCL_MAIN_TREE_TOOLBAR_HANDLER DEFINIION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main_tree_toolbar_handler DEFINITION FINAL CREATE PRIVATE.

*-- Publique
  PUBLIC SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Factory
    CLASS-METHODS factory
      IMPORTING
                !io_main_tree      TYPE REF TO lcl_main_tree
                !io_toolbar_event  TYPE REF TO lcl_main_tree_toolbar_event
      RETURNING VALUE(ro_instance) TYPE REF TO lcl_main_tree_toolbar_handler.

***------------------------------------------------------------------***
**                           ÉVENEMENTS                               **
***------------------------------------------------------------------***

*	Déclaration d'évènement

***------------------------------------------------------------------***
**                             HANDLER                                **
***------------------------------------------------------------------***

*	Déclaration des Handler

    METHODS handler_on_copy                FOR EVENT on_copy
         OF lcl_main_tree_toolbar_event.
    METHODS handler_on_cancel              FOR EVENT on_cancel
         OF lcl_main_tree_toolbar_event.
    METHODS handler_submit_change              FOR EVENT submit_change
         OF lcl_main_tree.
    METHODS handler_on_delete              FOR EVENT on_delete
         OF lcl_main_tree_toolbar_event.
    METHODS handler_on_modify              FOR EVENT on_modify
         OF lcl_main_tree_toolbar_event.
    METHODS handler_on_hierarchy_edit      FOR EVENT on_hierarchy_edit
         OF lcl_main_tree_event.
    METHODS handler_on_display             FOR EVENT on_display
         OF lcl_main_tree_toolbar_event.
    METHODS handler_on_compare             FOR EVENT on_compare
         OF lcl_main_tree_toolbar_event.
    METHODS handler_on_transport           FOR EVENT on_transport
                  OF lcl_main_tree_toolbar_event
      IMPORTING !iv_advanced_mode
                  !is_transport_target.
    METHODS handler_on_update_shm          FOR EVENT on_update_shm
         OF lcl_main_tree_toolbar_event.
    METHODS handler_on_export_local        FOR EVENT on_export_local
         OF lcl_main_tree_toolbar_event.
    METHODS handler_on_import_local        FOR EVENT on_import_local
                  OF lcl_main_tree_toolbar_event
      IMPORTING !iv_filename.
    METHODS handler_on_version_create      FOR EVENT on_version_create
         OF lcl_main_tree_toolbar_event.
    METHODS handler_on_parameter_create    FOR EVENT on_parameter_create
         OF lcl_main_tree_toolbar_event.
    METHODS handler_on_attribute_create    FOR EVENT on_attribute_create
         OF lcl_main_tree_toolbar_event.
    METHODS handler_on_version_primary_set FOR EVENT on_version_primary_set
         OF lcl_main_tree_toolbar_event.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

*-- Privée
  PRIVATE SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Constructeur
    METHODS constructor
      IMPORTING
        !io_main_tree     TYPE REF TO lcl_main_tree
        !io_toolbar_event TYPE REF TO lcl_main_tree_toolbar_event.

    " Déploie l'arborescence
    METHODS expand_first_node.

    " Hardcode - Transport
    METHODS _hardcode_transport
      IMPORTING
                !iv_direct           TYPE xsdboolean DEFAULT abap_true
                !iv_advanced_mode    TYPE xsdboolean
                !is_transport_target TYPE ts_transport_target OPTIONAL
      RETURNING VALUE(rs_return)     TYPE bapiret2.

    " Hardcode - Transport - OT
    METHODS _hardcode_transport_tr
      RETURNING VALUE(rs_return) TYPE bapiret2.

    " Hardcode - Transport - Direct
    METHODS _hardcode_transport_direct
      IMPORTING
                !iv_advanced_mode    TYPE xsdboolean
                !is_transport_target TYPE ts_transport_target OPTIONAL
      RETURNING VALUE(rs_return)     TYPE bapiret2.

    " Affichage de la ligne
    METHODS _node_edit.

    " Modification Noeud Version
    METHODS _node_edit_version
      CHANGING cs_selected_line TYPE lcl_main_tree=>ts_hc_data
      RAISING  zcx_hardcode_maintain.

    " Modification Noeud Paramètre
    METHODS _node_edit_parameter
      CHANGING cs_selected_line TYPE lcl_main_tree=>ts_hc_data
      RAISING  zcx_hardcode_maintain.

    " Modification Noeud Attribute
    METHODS _node_edit_attribute
      CHANGING cs_selected_line TYPE lcl_main_tree=>ts_hc_data
      RAISING  zcx_hardcode_maintain.

    " Modification affichage des boutons
    METHODS _button_visibility_set
      IMPORTING
        !iv_cancel_visible    TYPE xsdboolean DEFAULT abap_undefined
        !iv_primarity_visible TYPE xsdboolean DEFAULT abap_undefined.

***------------------------------------------------------------------***
**                           ÉVENEMENTS                               **
***------------------------------------------------------------------***

*	Déclaration d'évènement

***------------------------------------------------------------------***
**                             HANDLER                                **
***------------------------------------------------------------------***

*	Déclaration des Handler

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    DATA : mo_main_tree TYPE REF TO lcl_main_tree.
    DATA : mo_toolbar_event TYPE REF TO lcl_main_tree_toolbar_event.

ENDCLASS.             "lcl_MAIN_TREE_TOOLBAR_HANDLER DEFINITION

*----------------------------------------------------------------------*
*       CLASS LCL_ATTRIBUTE_DETAIL DEFINIION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_attribute_detail DEFINITION FINAL.

*-- Publique
  PUBLIC SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Constructeur
    METHODS constructor
      IMPORTING
        !io_main      TYPE REF TO lcl_main
        !io_main_tree TYPE REF TO lcl_main_tree
        !iv_read_only TYPE xsdboolean DEFAULT abap_false.

    " Affichage
    METHODS display
      EXPORTING
        !ev_cancel                     TYPE flag
        !es_new_attribute_logical_key  TYPE zcl_hardcode_maintain=>ts_attribute_logical_key
        !es_new_attribute_logical_keyx TYPE zcl_hardcode_maintain=>ts_attribute_logical_keyx
      CHANGING
        !cs_attribute_detail           TYPE ts_attribute_detail_ref
        !cot_source_code               TYPE REF TO stringtab OPTIONAL
        !cot_attribute_range_value     TYPE REF TO zcl_hardcode_maintain=>tt_attribute_range_value_det OPTIONAL.

    " Récupération Range
    METHODS range_value_get
      RETURNING VALUE(ror_range_value) TYPE REF TO tt_r_ranges.

    " Récupération Code Source
    METHODS source_code_get
      RETURNING VALUE(rot_source_code) TYPE REF TO stringtab.

    " Récupération instance
    CLASS-METHODS instance_get
      IMPORTING
                !is_system         TYPE ts_system OPTIONAL
      RETURNING VALUE(ro_instance) TYPE REF TO lcl_attribute_detail.

***------------------------------------------------------------------***
**                           ÉVENEMENTS                               **
***------------------------------------------------------------------***

*	Déclaration d'évènement

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    DATA : mv_read_only TYPE xsdboolean READ-ONLY.

*-- Privée
  PRIVATE SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type
    TYPES :
      BEGIN OF ts_instance_sytem,
        repid TYPE sy-repid.
    INCLUDE TYPE : ts_system AS system_key.
    TYPES :
      instance TYPE REF TO lcl_attribute_detail,
      END OF   ts_instance_sytem.

    TYPES : tt_instance_sytem TYPE SORTED TABLE OF ts_instance_sytem
                    WITH UNIQUE KEY primary_key COMPONENTS repid system_key.

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

***------------------------------------------------------------------***
**                           ÉVENEMENTS                               **
***------------------------------------------------------------------***

*	Déclaration d'évènement

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    DATA : mo_main TYPE REF TO lcl_main.
    DATA : mo_main_tree TYPE REF TO lcl_main_tree.
    DATA : mo_attribute_detail TYPE REF TO ts_attribute_detail.
    DATA : mor_ranges_value TYPE REF TO tt_r_ranges.
    DATA : mot_source_code TYPE REF TO stringtab.
    CLASS-DATA : mos_system TYPE REF TO ts_system.
    CLASS-DATA : mt_instance TYPE lcl_attribute_detail=>tt_instance_sytem.

ENDCLASS.             "lcl_ATTRIBUTE_DETAIL DEFINITION
