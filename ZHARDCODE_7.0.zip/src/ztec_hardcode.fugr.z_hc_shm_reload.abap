FUNCTION z_hc_shm_reload.
*"----------------------------------------------------------------------
*& Copyright © 13/01/2016, Olivier Véhier                              *
*&                                                                     *
*& Permission is hereby granted, free of charge, to any person         *
*& obtaining a copy of this software and associated documentation      *
*& files (the "Software"), to deal in the Software without restriction *
*& including without limitation the rights to use, copy, modify,       *
*& merge, publish, distribute, sublicense, and/or sell copies of the   *
*& Software, and to permit persons to whom the Software is furnished   *
*& to do so, subject to the following conditions:                      *
*&                                                                     *
*& The above copyright notice and this permission notice shall be      *
*& included in all copies or substantial portions of the Software.     *
*&                                                                     *
*& THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,     *
*& EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES     *
*& OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND            *
*& NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS *
*& BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN  *
*& ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN   *
*& CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE    *
*& SOFTWARE.                                                           *
*&                                                                     *
*& Except as contained in this notice, the name of Olivier Véhier      *
*& shall not be used in advertising or otherwise to promote the sale,  *
*& use or other dealings in this Software without prior written        *
*& authorization from Olivier Véhier.                                  *
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(IV_REPID) TYPE  REPID
*"----------------------------------------------------------------------
*&---------------------------------------------------------------------*
*& Module Fonction : Z_HC_SHM_RELOAD                                   *
*& Groupe Fonction : ZTEC_HARDCODE                                     *
*& Description     : Recharge la SHM                                   *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF zcl_hardcode_shm=>hardcode_is_load( iv_repid ) NE abap_true.
    " Hardcode non chargée en SHM
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Modification de la SHM
  " -----------------------------------------------------------

  " Recharge les Hardcodes dans la SHM
  zcl_hardcode_shm=>get_instance( iv_repid )->hardcode_reload( abap_true ).

ENDFUNCTION.
