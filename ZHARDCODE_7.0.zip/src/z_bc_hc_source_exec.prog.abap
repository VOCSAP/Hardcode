*&---------------------------------------------------------------------*
*& Report  Z_BC_HC_SOURCE_EXEC
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT z_bc_hc_source_exec.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***
TYPES :
  BEGIN OF ts_log_execution,
    srtfd            TYPE ztb_dynamic_exec-srtfd,
    launch_user      TYPE ztb_dynamic_exec-launch_user,
    launch_at_date   TYPE ztb_dynamic_exec-launch_at_date,
    launch_at_time   TYPE ztb_dynamic_exec-launch_at_time,
    icon_source_code TYPE icon_d,
  END OF   ts_log_execution.

TYPES : tt_log_execution TYPE STANDARD TABLE OF ts_log_execution
                WITH NON-UNIQUE KEY primary_key COMPONENTS srtfd.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
DATA :
      gt_log_execution TYPE tt_log_execution.

*---------------------------------------------------------------------*
*       CLASS lcl_handle_events DEFINITION
*---------------------------------------------------------------------*
*
*---------------------------------------------------------------------*
CLASS lcl_handle_events DEFINITION.

*-- Publique
  PUBLIC SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Constructeur
    METHODS constructor
      IMPORTING
        !io_salv_table TYPE REF TO cl_salv_table.

    " Handler - Double clique
    METHODS on_double_click FOR EVENT double_click OF cl_salv_events_table
      IMPORTING !row !column.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

*-- Privée
  PRIVATE SECTION.

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

    " Affichage Code Source
    METHODS _source_code_display
      IMPORTING
        !iv_srtfd TYPE ztb_dynamic_exec-srtfd.

    " Récupération Code Source
    METHODS _source_code_get
      IMPORTING
                !iv_srtfd             TYPE ztb_dynamic_exec-srtfd
      RETURNING VALUE(rt_source_code) TYPE stringtab.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type
    TYPES :
      BEGIN OF ts_source_code,
        srtfd         TYPE ztb_dynamic_exec-srtfd,
        t_source_code TYPE stringtab,
      END OF   ts_source_code.

    TYPES : tt_source_code TYPE SORTED TABLE OF ts_source_code
                    WITH NON-UNIQUE KEY primary_key COMPONENTS srtfd.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

    DATA : mo_salv_table TYPE REF TO cl_salv_table.
    DATA : mt_source_code TYPE lcl_handle_events=>tt_source_code.

ENDCLASS.                    "lcl_handle_events DEFINITION


*---------------------------------------------------------------------*
*       CLASS lcl_handle_events IMPLEMENTATION
*---------------------------------------------------------------------*
*
*---------------------------------------------------------------------*
CLASS lcl_handle_events IMPLEMENTATION.

  METHOD constructor.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation attributs
    " -----------------------------------------------------------

    " Grille ALV
    me->mo_salv_table = io_salv_table.

  ENDMETHOD.

  METHOD on_double_click.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_method TYPE string.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    TRY.
        " -----------------------------------------------------------
        " Traitement du double-clique
        " -----------------------------------------------------------

        " Affiche le Code Source
        me->_source_code_display(
          iv_srtfd = gt_log_execution[ row ]-srtfd
        ).

      CATCH cx_root.
        " Erreur lors de l'appel de la méthode
        ""  --> Arrêt du traitement
        RETURN.

    ENDTRY.

  ENDMETHOD.

  METHOD _source_code_display.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
        lt_source_code TYPE stringtab.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération Code Source
    " -----------------------------------------------------------

    " Récupération Code Source
    lt_source_code = me->_source_code_get( iv_srtfd ).

    " -----------------------------------------------------------
    " Affichage du Code Source
    " -----------------------------------------------------------

    " Affichage Code Source
    CALL FUNCTION 'ENH_SCPCONT_SOURCE_EDITOR'
      EXPORTING
        im_changemode = abap_false
      CHANGING
        ch_text       = lt_source_code.

  ENDMETHOD.

  METHOD _source_code_get.
***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
          ls_source_code TYPE lcl_handle_events=>ts_source_code.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération Code Source
    " -----------------------------------------------------------

    " Récupération Code Source en buffer
    READ TABLE me->mt_source_code WITH TABLE KEY srtfd = iv_srtfd
     ASSIGNING FIELD-SYMBOL(<lfs_s_source_code>).
    IF sy-subrc NE 0.
      " Aucune correspondance
      ""  --> Récupération Code Source en DB
      ls_source_code-srtfd         = iv_srtfd.
      ls_source_code-t_source_code = zcl_dynamic_source_code=>execution_log_source_code_get( iv_srtfd ).

      ""  --> Ajout de l'entrée
      INSERT ls_source_code INTO TABLE me->mt_source_code ASSIGNING <lfs_s_source_code>.

    ENDIF.

    " Retourne Code Source
    rt_source_code[] = <lfs_s_source_code>-t_source_code[].

  ENDMETHOD.

ENDCLASS.                    "lcl_handle_events IMPLEMENTATION

***==================================================================***
**                         SELECTION-SCREEN                           **
***==================================================================***
TABLES : ztb_dynamic_exec.

" -----------------------------------------------------------
" Ecran d'exécution
" -----------------------------------------------------------

SELECTION-SCREEN BEGIN OF SCREEN 2000 AS SUBSCREEN.
" -----------------------------------------------------------
" Critère de sélection
" -----------------------------------------------------------

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-tb1.

" Paramètre
PARAMETERS : p_param TYPE ztec_t_hc_param-parameter_name OBLIGATORY DEFAULT 'SOURCE_CODE'. "#EC NOTEXT

" Attribut
PARAMETERS : p_attr TYPE ztec_t_hc_attr-attribute_name OBLIGATORY DEFAULT 'DEMO'. "#EC NOTEXT

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN END OF SCREEN 2000.

" -----------------------------------------------------------
" Ecran de Log
" -----------------------------------------------------------

SELECTION-SCREEN BEGIN OF SCREEN 3000 AS SUBSCREEN.
" -----------------------------------------------------------
" Critère de sélection
" -----------------------------------------------------------

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE text-tb2.

" Nom utilisateur
SELECT-OPTIONS : s_uname FOR ztb_dynamic_exec-launch_user.

" Date
SELECT-OPTIONS : s_datum FOR sy-datum.

" Heure
SELECT-OPTIONS : s_uzeit FOR sy-uzeit.

SELECTION-SCREEN END OF BLOCK b2.

SELECTION-SCREEN END OF SCREEN 3000.

" -----------------------------------------------------------
" Gestion Onglets
" -----------------------------------------------------------

SELECTION-SCREEN BEGIN OF TABBED BLOCK tab FOR 10 LINES.

" Exécution
SELECTION-SCREEN TAB (30) text-sc1 USER-COMMAND ucomm1
  DEFAULT SCREEN 2000 MODIF ID mi1.

" Log exécution
SELECTION-SCREEN TAB (30) text-sc2 USER-COMMAND ucomm4
  DEFAULT SCREEN 3000 MODIF ID mi2.

SELECTION-SCREEN END OF BLOCK tab.

DATA : gv_dynnr TYPE sy-dynnr.

***==================================================================***
**                           INITIALIZATION                           **
***==================================================================***
INITIALIZATION.

***==================================================================***
**                     AT SELECTION-SCREEN OUTPUT                     **
***==================================================================***
AT SELECTION-SCREEN OUTPUT.
  " Modification écran sélection
  gv_dynnr = sy-dynnr.

START-OF-SELECTION.

***------------------------------------------------------------------***
**                           CONSTANTES                               **
***------------------------------------------------------------------***

  CONSTANTS : gc_icon_source_code TYPE icon_d VALUE '@9U@'. "#EC NOTEXT
  CONSTANTS : gc_separation_process TYPE string
    VALUE '- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -'. "#EC NOTEXT

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        go_hardcode TYPE REF TO zcl_hardcode.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Traitement suivant l'Onglet
  " -----------------------------------------------------------

  " Suivant l'écran affiché
  CASE gv_dynnr.

    WHEN '2000'.
      " Exécution
      PERFORM execution.

    WHEN '3000'.
      " Log exécution
      PERFORM display_previous_execution.

    WHEN OTHERS.
      " Autre
      RETURN.

  ENDCASE.

END-OF-SELECTION.

*&---------------------------------------------------------------------*
*&      Form  EXECUTION
*&---------------------------------------------------------------------*
*       Exécution
*----------------------------------------------------------------------*
FORM execution.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_string_write TYPE string.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Récupération Code Source
      " -----------------------------------------------------------

      " Récupération Instance Hardcode du programme
      go_hardcode = zcl_hardcode=>get_instance( 'Z_BC_HC_SOURCE_EXEC' ). "#EC NOTEXT

      " Récupération de l'Attribut spécifié
      DATA(ls_attribute) = go_hardcode->attribute_value_get(
          iv_parameter_name = p_param
          iv_attribute_name = p_attr
      ).

      IF ls_attribute-source_code[] IS INITIAL.
        " Pas de Code Soufce
        ""  --> Arrêt du traitement
        MESSAGE s001(zharcode)." TYPE if_msg_output=>msgtype_success DISPLAY LIKE if_msg_output=>msgtype_warning.
        RETURN.

      ENDIF.

    CATCH zcx_hardcode.
      " Aucun Hardcode
      ""  --> Arrêt du traitement
      RETURN.

  ENDTRY.

  " -----------------------------------------------------------
  " Pré-Exécution
  " -----------------------------------------------------------

  " Inscrit le début de l'exécution
  FORMAT COLOR COL_HEADING.
  WRITE : 'Début du traitement dynamique'.                  "#EC NOTEXT
  FORMAT COLOR COL_TOTAL.
  WRITE :  /, gc_separation_process, /.

  " Couleur "classique"
  FORMAT COLOR COL_BACKGROUND.

  " -----------------------------------------------------------
  " Exécution du Code Source
  " -----------------------------------------------------------

  " Exécution du Code Source
  DATA(ls_result) = zcl_dynamic_source_code=>execute( ls_attribute-source_code ).

  " -----------------------------------------------------------
  " Post-Exécution
  " -----------------------------------------------------------

  IF ls_result-syntax_properties-syntax_error EQ abap_true.
    " Erreur contrôle syntaxique
    ""  --> Affiche le message
    FORMAT COLOR COL_NEGATIVE.
    WRITE : 'Erreur contrôle syntaxique : ', /.             "#EC NOTEXT

    ""  --> Affiche les retours du contrôle syntaxique
    LOOP AT ls_result-syntax_properties-t_syntax_check_result
      ASSIGNING FIELD-SYMBOL(<lfs_s_syntax_result>).

      FORMAT COLOR COL_BACKGROUND.
      WRITE : 'Ligne : '.                                   "#EC NOTEXT
      FORMAT COLOR COL_KEY.
      lv_string_write = <lfs_s_syntax_result>-line.
      CONDENSE : lv_string_write.
      WRITE: lv_string_write.
      FORMAT COLOR COL_BACKGROUND.
      WRITE : 'Colonne : '.                                 "#EC NOTEXT
      FORMAT COLOR COL_KEY.
      lv_string_write = <lfs_s_syntax_result>-col.
      CONDENSE : lv_string_write.
      WRITE: lv_string_write.
      FORMAT COLOR COL_BACKGROUND.
      WRITE : ' - '.                                        "#EC NOTEXT
      FORMAT COLOR COL_NEGATIVE.
      lv_string_write = <lfs_s_syntax_result>-message.
      CONDENSE : lv_string_write.
      WRITE : lv_string_write, /.
      FORMAT COLOR COL_BACKGROUND.
      TRY.
*          DO 5 TIMES. WRITE : space. ENDDO.
          ASSIGN ls_attribute-source_code[ <lfs_s_syntax_result>-line - 1 ] TO FIELD-SYMBOL(<lfs_source_code>).
          lv_string_write = <lfs_source_code>(<lfs_s_syntax_result>-col).
          WRITE : <lfs_source_code>(<lfs_s_syntax_result>-col) UNDER 'Colonne : '. "#EC NOTEXT
          FORMAT COLOR COL_NEGATIVE.
          WRITE : <lfs_source_code>+<lfs_s_syntax_result>-col.
          FORMAT COLOR COL_BACKGROUND.
        CATCH cx_sy_itab_line_not_found.
      ENDTRY.
      WRITE : /.

    ENDLOOP.

  ELSEIF ls_result-execution_properties-execution_error EQ abap_true.
    " Traitement en erreur
    ""  --> Affichage message
    FORMAT COLOR COL_NEGATIVE.
    WRITE : 'Erreur traitement : ', ls_result-execution_properties-message, /. "#EC NOTEXT

  ELSE.
    " Traitement effectuée
    ""  --> Marque la fin de l'exécution
    FORMAT COLOR COL_TOTAL.
    WRITE : /, gc_separation_process, /.
    FORMAT COLOR COL_POSITIVE. "Vert
    WRITE : 'Fin du traitement dynamique. Temps exécution : '. "#EC NOTEXT
    FORMAT COLOR COL_GROUP. "Orange
    lv_string_write = ls_result-execution_properties-execution_duration.
    CONDENSE : lv_string_write.
    WRITE : lv_string_write.
    FORMAT COLOR COL_POSITIVE.
    WRITE : ' ms'.                                          "#EC NOTEXT

  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  DISPLAY_PREVIOUS_EXECUTION
*&---------------------------------------------------------------------*
*       Affichage exécution précédente
*----------------------------------------------------------------------*
FORM display_previous_execution.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_salv          TYPE REF TO cl_salv_table,
    lo_events        TYPE REF TO cl_salv_events_table,
    lo_event_handler TYPE REF TO lcl_handle_events.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Récupération des exécutions précédentes
  " -----------------------------------------------------------

  " Récupération des exécutions
  SELECT srtfd, launch_user,
         launch_at_date, launch_at_time,
         @gc_icon_source_code AS icon_source_code
    FROM ztb_dynamic_exec
   WHERE launch_user    IN @s_uname[]
     AND launch_at_date IN @s_datum[]
     AND launch_at_time IN @s_uzeit[]
    INTO TABLE @gt_log_execution.
  IF sy-subrc NE 0.
    " Aucune exécution
    ""  --> Affiche message
    MESSAGE s001(zhardcode) DISPLAY LIKE if_msg_output=>msgtype_warning.
    RETURN.

  ENDIF.

  " Tri
  SORT gt_log_execution BY launch_at_date DESCENDING
                           launch_at_time DESCENDING
                           launch_user.

  TRY.
      " -----------------------------------------------------------
      " Création SALV
      " -----------------------------------------------------------

      " Génération instance SALV
      cl_salv_table=>factory(
        IMPORTING
          r_salv_table   = lo_salv
        CHANGING
          t_table        = gt_log_execution
      ).

      " Souscription aux Evènements
      lo_events = lo_salv->get_event( ).
      CREATE OBJECT lo_event_handler
        EXPORTING
          io_salv_table = lo_salv.
      SET HANDLER lo_event_handler->on_double_click FOR lo_events.

      " Affichage
      lo_salv->display( ).

    CATCH cx_salv_msg.
      " Erreur génération instance SALV

  ENDTRY.

ENDFORM.
