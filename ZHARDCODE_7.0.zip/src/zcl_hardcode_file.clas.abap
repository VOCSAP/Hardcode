class ZCL_HARDCODE_FILE definition
  public
  final
  create public .

public section.

  class-methods HARDCODE_UPLOAD
    importing
      !IV_FILENAME type CLIKE
      !IV_REPLACE type XSDBOOLEAN default ABAP_TRUE
      !IV_COMMIT type XSDBOOLEAN default ABAP_TRUE
    exporting
      !EO_HARDCODE_MAINTAIN type ref to ZCL_HARDCODE_MAINTAIN
    returning
      value(RV_DONE) type XSDBOOLEAN
    raising
      ZCX_HARDCODE_MAINTAIN .
  class-methods HARDCODE_DOWNLOAD
    importing
      !IV_REPID type REPID
      !IV_FILENAME type CLIKE
    returning
      value(RV_DONE) type XSDBOOLEAN
    raising
      ZCX_HARDCODE_MAINTAIN .
  class-methods HARDCODE_GET_REPID
    importing
      !IV_FILENAME type CLIKE
    returning
      value(RV_REPID) type REPID
    raising
      ZCX_HARDCODE_MAINTAIN .
protected section.
private section.

  class-methods _HARDCODE_GET_FROM_FILE
    importing
      !IV_FILENAME type CLIKE
    exporting
      !ET_HARDCODE_VERSION type ZCL_HARDCODE_MAINTAIN=>TT_HARDCODE_VERSION
      !ET_HARDCODE_PARAMETER type ZCL_HARDCODE_MAINTAIN=>TT_HARDCODE_PARAMETER
      !ET_HARDCODE_ATTRIBUTE type ZCL_HARDCODE_MAINTAIN=>TT_HARDCODE_ATTRIBUTE
      !ET_HC_ATTRIBUTE_SOURCE_CODE type ZCL_HARDCODE_MAINTAIN=>TT_ATTRIBUTE_SOURCE_CODE
    returning
      value(RV_REPID) type REPID .
ENDCLASS.



CLASS ZCL_HARDCODE_FILE IMPLEMENTATION.


METHOD hardcode_download.
*&---------------------------------------------------------------------*
*& Méthode         : HARDCODE_DOWNLOAD                                 *
*& Classe          : ZCL_HARDCODE_FILE                                 *
*& Description     : Hardcode - Extraction dans un fichier             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
      lt_data_tab TYPE solix_tab.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_zip               TYPE REF TO cl_abap_zip,
    lo_hardcode_maintain TYPE REF TO zcl_hardcode_maintain.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_xstring      TYPE xstring,
    lv_bin_filesize TYPE int4.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Récupération des Hardcodes
      " -----------------------------------------------------------

      " Création instance Hardcode MàJ
      CREATE OBJECT lo_hardcode_maintain
        EXPORTING
          iv_repid = iv_repid.

    CATCH zcx_hardcode INTO DATA(lo_cx_hardcode).
      " Une erreur est survenue
      ""  --> Retourne l'exception
      RAISE EXCEPTION TYPE zcx_hardcode_maintain
        EXPORTING
          previous = lo_cx_hardcode.

  ENDTRY.

  " -----------------------------------------------------------
  " Compression des Hardcodes
  " -----------------------------------------------------------

  " Récupération Hardcode sous forme XML
  CALL TRANSFORMATION id
               SOURCE repid       = lo_hardcode_maintain->mv_repid
                      version     = lo_hardcode_maintain->ms_work_data-t_hardcode_version
                      parameter   = lo_hardcode_maintain->ms_work_data-t_hardcode_parameter
                      attribute   = lo_hardcode_maintain->ms_work_data-t_hardcode_attribute
                      source_code = lo_hardcode_maintain->ms_work_data-t_hc_attribute_source_code
           RESULT XML lv_xstring.

  " Création instance compression
  CREATE OBJECT lo_zip.
  lo_zip->support_unicode_names = abap_true.

  " Compression
  lo_zip->add(
      name    = CONV #( lo_hardcode_maintain->mv_repid )
      content = lv_xstring
  ).

  " Sauvegarde de l'archive
  lv_xstring = lo_zip->save( ).

  " Conversion XSTRING -> SOLIX
  lt_data_tab = cl_bcs_convert=>xstring_to_solix( lv_xstring ).

  " Détermination taille BIN
  lv_bin_filesize = xstrlen( lv_xstring ).

  " -----------------------------------------------------------
  " Télédéchargement sur le PC
  " -----------------------------------------------------------

  " Télédéchargement sur le PC
  cl_gui_frontend_services=>gui_download(
    EXPORTING
      filename                  = iv_filename
      filetype                  = CONV #( if_rcc_file_c=>gc_file_type_binary )
      bin_filesize              = lv_bin_filesize
    CHANGING
      data_tab                  = lt_data_tab
    EXCEPTIONS
      file_write_error          = 1
      no_batch                  = 2
      gui_refuse_filetransfer   = 3
      invalid_type              = 4
      no_authority              = 5
      unknown_error             = 6
      header_not_allowed        = 7
      separator_not_allowed     = 8
      filesize_not_allowed      = 9
      header_too_long           = 10
      dp_error_create           = 11
      dp_error_send             = 12
      dp_error_write            = 13
      unknown_dp_error          = 14
      access_denied             = 15
      dp_out_of_memory          = 16
      disk_full                 = 17
      dp_timeout                = 18
      file_not_found            = 19
      dataprovider_exception    = 20
      control_flush_error       = 21
      not_supported_by_gui      = 22
      error_no_gui              = 23
      OTHERS                    = 24
  ).
  IF sy-subrc NE 0.
    " Une erreur est survenue
    ""  --> Lève une Exception
    RAISE EXCEPTION TYPE zcx_hardcode_maintain
      EXPORTING
        textid = VALUE #(
          msgid = sy-msgid msgno = sy-msgno
          attr1 = sy-msgv1 attr2 = sy-msgv2
          attr3 = sy-msgv3 attr4 = sy-msgv4
        ).

  ENDIF.

ENDMETHOD.


METHOD hardcode_get_repid.
*&---------------------------------------------------------------------*
*& Méthode         : HARDCODE_GET_REPID                                *
*& Classe          : ZCL_HARDCODE_FILE                                 *
*& Description     : Hardcode - Récupération identifiant depuis fichier*
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Récupération Identifiant Hardcode
      " -----------------------------------------------------------

      " Récupération Identifiant du fichier
      rv_repid = zcl_hardcode_file=>_hardcode_get_from_file( iv_filename ).

    CATCH zcx_hardcode_maintain INTO DATA(lo_cx_hardcode).
      " Exception survenue
      ""  --> Retourne l'Exception
      WHILE lo_cx_hardcode->previous IS BOUND.
        lo_cx_hardcode ?= lo_cx_hardcode->previous.
      ENDWHILE.
      RAISE EXCEPTION TYPE zcx_hardcode_maintain
        EXPORTING
          textid = VALUE #(
            msgid = lo_cx_hardcode->if_t100_message~t100key-msgid
            msgno = lo_cx_hardcode->if_t100_message~t100key-msgno
            attr1 = lo_cx_hardcode->if_t100_message~t100key-attr1
            attr2 = lo_cx_hardcode->if_t100_message~t100key-attr2
            attr3 = lo_cx_hardcode->if_t100_message~t100key-attr3
            attr4 = lo_cx_hardcode->if_t100_message~t100key-attr4
          ).

  ENDTRY.

ENDMETHOD.


METHOD hardcode_upload.
*&---------------------------------------------------------------------*
*& Méthode         : HARDCODE_UPLOAD                                   *
*& Classe          : ZCL_HARDCODE_FILE                                 *
*& Description     : Hardcode - Chargement depuis un fichier           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_hardcode_version         TYPE zcl_hardcode_maintain=>tt_hardcode_version,
    lt_hardcode_parameter       TYPE zcl_hardcode_maintain=>tt_hardcode_parameter,
    lt_hardcode_attribute       TYPE zcl_hardcode_maintain=>tt_hardcode_attribute,
    lt_hc_attribute_source_code TYPE zcl_hardcode_maintain=>tt_attribute_source_code.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_repid TYPE zvtec_t_hc-repid.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF iv_filename IS INITIAL.
    " Nom du fichier vide
    ""  --> Retourne l'exception
    IF 1 = 2. MESSAGE e504(zhardcode). ENDIF.
    RAISE EXCEPTION TYPE zcx_hardcode_maintain
      EXPORTING
        textid = VALUE #(
          msgid = zcl_hardcode=>mc_my_msgid
          msgno = 504
        ).

  ENDIF.

  TRY.
      " -----------------------------------------------------------
      " Récupération des Hardcodes du fichier
      " -----------------------------------------------------------

      " Récupération données du fichier
      lv_repid = zcl_hardcode_file=>_hardcode_get_from_file(
        EXPORTING
          iv_filename                 = iv_filename
        IMPORTING
          et_hardcode_version         = lt_hardcode_version
          et_hardcode_parameter       = lt_hardcode_parameter
          et_hardcode_attribute       = lt_hardcode_attribute
          et_hc_attribute_source_code = lt_hc_attribute_source_code
      ).

      " Création instance Hardcode MàJ
      CREATE OBJECT eo_hardcode_maintain
        EXPORTING
          iv_repid = CONV #( lv_repid ).

      IF iv_replace EQ abap_false.
        " -----------------------------------------------------------
        " Contrôle avant écrasement
        " -----------------------------------------------------------

        " Vérifie si le Hardcode existe déjà
        SELECT SINGLE repid FROM ztec_t_hc_vers
                WHERE repid EQ @lv_repid
                 INTO @DATA(lv_repid_exist).
        IF sy-subrc EQ 0.
          " Hardcode existe et remplacement non souhaité
          ""  --> Arrêt du traitement
          RETURN.

        ENDIF.

      ELSE.
        " -----------------------------------------------------------
        " Supprime les Hardcodes existant
        " -----------------------------------------------------------

        " Suppression des Hardcodes existant
        eo_hardcode_maintain->version_del( ).

      ENDIF.

      " -----------------------------------------------------------
      " Modification attributs instance
      " -----------------------------------------------------------

      " Initialisation des Attributs
      eo_hardcode_maintain->ms_work_data-t_hardcode_version         = lt_hardcode_version.
      eo_hardcode_maintain->ms_work_data-t_hardcode_parameter       = lt_hardcode_parameter.
      eo_hardcode_maintain->ms_work_data-t_hardcode_attribute       = lt_hardcode_attribute.
      eo_hardcode_maintain->ms_work_data-t_hc_attribute_source_code = lt_hc_attribute_source_code.

      " -----------------------------------------------------------
      " Regnère de nouveaux GUID (pour éviter des doublons)
      " -------------------------------------------------- ---------

      " Regénaration des GUIDs
      eo_hardcode_maintain->guid_renew( abap_false ).

      IF iv_commit EQ abap_true.
        " -----------------------------------------------------------
        " Mise à jour en DB
        " -----------------------------------------------------------

        " Sauvegarde en DB
        eo_hardcode_maintain->save_to_db( abap_true ).

      ENDIF.

    CATCH zcx_hardcode_maintain INTO DATA(lo_cx_hardcode_maintain).
      " Une erreur est survenue
      ""  --> Retourne l'exception
      RAISE EXCEPTION TYPE zcx_hardcode_maintain
        EXPORTING
          textid = VALUE #(
            msgid = lo_cx_hardcode_maintain->if_t100_message~t100key-msgid
            msgno = lo_cx_hardcode_maintain->if_t100_message~t100key-msgno
            attr1 = lo_cx_hardcode_maintain->if_t100_message~t100key-attr1
            attr2 = lo_cx_hardcode_maintain->if_t100_message~t100key-attr2
            attr3 = lo_cx_hardcode_maintain->if_t100_message~t100key-attr3
            attr4 = lo_cx_hardcode_maintain->if_t100_message~t100key-attr4
          ).

  ENDTRY.

ENDMETHOD.


METHOD _hardcode_get_from_file.
*&---------------------------------------------------------------------*
*& Méthode         : _HARDCODE_GET_FROM_FILE                           *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Récupération des Hardcodes                        *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_data_tab TYPE solix_tab.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_zip TYPE REF TO cl_abap_zip.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_header     TYPE xstring,
    lv_content    TYPE xstring,
    lv_filelength TYPE int4.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  REFRESH : et_hardcode_attribute,       et_hardcode_version,
            et_hc_attribute_source_code, et_hardcode_parameter.

  " -----------------------------------------------------------
  " Récupération du contenu du fichier
  " -----------------------------------------------------------

  " Récupération du contenu du fichier
  cl_gui_frontend_services=>gui_upload(
    EXPORTING
      filename                = CONV #( iv_filename )
      filetype                = CONV #( if_rcc_file_c=>gc_file_type_binary )
    IMPORTING
      filelength              = lv_filelength
      header                  = lv_header
    CHANGING
      data_tab                = lt_data_tab
    EXCEPTIONS
      file_open_error         = 1
      file_read_error         = 2
      no_batch                = 3
      gui_refuse_filetransfer = 4
      invalid_type            = 5
      no_authority            = 6
      unknown_error           = 7
      bad_data_format         = 8
      header_not_allowed      = 9
      separator_not_allowed   = 10
      header_too_long         = 11
      unknown_dp_error        = 12
      access_denied           = 13
      dp_out_of_memory        = 14
      disk_full               = 15
      dp_timeout              = 16
      not_supported_by_gui    = 17
      error_no_gui            = 18
      OTHERS                  = 19
  ).
  IF sy-subrc EQ 0.
    " -----------------------------------------------------------
    " Décompression de l'Archive
    " -----------------------------------------------------------

    " Conversion SOLIX -> XSTRING
    lv_content = cl_bcs_convert=>solix_to_xstring( lt_data_tab ).

    " Création instance compression
    CREATE OBJECT lo_zip.
    lo_zip->support_unicode_names = abap_true.

    " Chargement de l'Archive
    lo_zip->load(
      EXPORTING
        zip             = lv_content
      EXCEPTIONS
        zip_parse_error = 1
        OTHERS          = 2
    ).

  ENDIF.

  IF sy-subrc EQ 0.
    " Décompression
    lo_zip->get(
      EXPORTING
        index                   = 1
      IMPORTING
        content                 = lv_content
      EXCEPTIONS
        zip_index_error         = 1
        zip_decompression_error = 2
        OTHERS                  = 3
    ).

  ENDIF.

  IF sy-subrc NE 0.
    ""  --> Lève une Exception
    RAISE EXCEPTION TYPE zcx_hardcode_maintain
      EXPORTING
        textid = VALUE #(
          msgid = sy-msgid msgno = sy-msgno
          attr1 = sy-msgv1 attr2 = sy-msgv2
          attr3 = sy-msgv3 attr4 = sy-msgv4
        ).

  ENDIF.

  " -----------------------------------------------------------
  " Récupération Hardcodes
  " -----------------------------------------------------------

  " Récupération Hardcode depuis leur forme XML
  CALL TRANSFORMATION id
           SOURCE XML lv_content
               RESULT repid       = rv_repid
                      version     = et_hardcode_version
                      parameter   = et_hardcode_parameter
                      attribute   = et_hardcode_attribute
                      source_code = et_hc_attribute_source_code.

ENDMETHOD.
ENDCLASS.
