PROCESS BEFORE OUTPUT.
  MODULE status.

PROCESS AFTER INPUT.
  MODULE user_command.

PROCESS ON VALUE-REQUEST.
  " Aide à la Recherche Système Cible
  FIELD gs_transport_target-system MODULE value_help_system_target.
