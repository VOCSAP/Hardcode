*&---------------------------------------------------------------------*
*& Include         : ZTEC_HARDCODE_SEL                                 *
*& Programme Cadre : ZTEC_HARDCODE                                     *
*&---------------------------------------------------------------------*
*& Gestion Hardcode                                                    *
*& Include Ecran de Sélection                                          *
*&---------------------------------------------------------------------*
*& Créé le      : 13/01/2016                                           *
*&                                                                     *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*

***==================================================================***
**                         SELECTION-SCREEN                           **
***==================================================================***

TABLES : zvtec_t_hc.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-tb1.
" -----------------------------------------------------------
" Critères de Sélection
" -----------------------------------------------------------

" Nom du Programme
PARAMETERS : p_repid TYPE sy-repid MATCHCODE OBJECT ztec_harcode_repid_help_value.

" Charger Hardcode En cours de Modif.
PARAMETER : p_work TYPE flag NO-DISPLAY.

" Action utilisateur
PARAMETERS : p_ucomm TYPE sy-ucomm NO-DISPLAY.

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF SCREEN 2100 AS SUBSCREEN.
" -----------------------------------------------------------
" Recherche
" -----------------------------------------------------------

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE text-tb2.
" -----------------------------------------------------------
" Critères de Recherche
" -----------------------------------------------------------

SELECTION-SCREEN BEGIN OF BLOCK b3 WITH FRAME TITLE text-tb3.
" -----------------------------------------------------------
" Critères de Recherche - Nom
" -----------------------------------------------------------

" Programme
SELECT-OPTIONS : s_repid FOR zvtec_t_hc-repid.

" OR ?
PARAMETERS : p_orparn AS CHECKBOX MODIF ID orp USER-COMMAND cor.

" Paramètres
SELECT-OPTIONS : s_pname FOR zvtec_t_hc-parameter_name.

" OR ?
PARAMETERS : p_orattn AS CHECKBOX MODIF ID ora USER-COMMAND cor.

" Attributs
SELECT-OPTIONS : s_aname FOR zvtec_t_hc-attribute_name.

SELECTION-SCREEN END OF BLOCK b3.

SELECTION-SCREEN SKIP 1.
SELECTION-SCREEN BEGIN OF LINE.
SELECTION-SCREEN POSITION 10.
" OR ?
PARAMETERS : p_orval AS CHECKBOX MODIF ID orv USER-COMMAND cor.
SELECTION-SCREEN COMMENT 12(5) text-tor MODIF ID orv.
SELECTION-SCREEN END OF LINE.

SELECTION-SCREEN SKIP 1.

SELECTION-SCREEN BEGIN OF BLOCK b4 WITH FRAME TITLE text-tb4.
" -----------------------------------------------------------
" Critères de Recherche - Valeur
" -----------------------------------------------------------

" Valeur basse
SELECT-OPTIONS : s_alow FOR zvtec_t_hc-attribute_low.

" OR ?
PARAMETERS : p_orhigh AS CHECKBOX MODIF ID orh USER-COMMAND cor.

" Valeur haute
SELECT-OPTIONS : s_ahigh FOR zvtec_t_hc-attribute_high.

SELECTION-SCREEN END OF BLOCK b4.

SELECTION-SCREEN END OF BLOCK b2.

SELECTION-SCREEN END OF SCREEN 2100.
