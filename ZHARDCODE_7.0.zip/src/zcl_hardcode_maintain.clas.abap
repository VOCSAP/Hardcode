class ZCL_HARDCODE_MAINTAIN definition
  public
  final
  create public

  global friends ZCL_HARDCODE_FILE .

public section.

  types:
    BEGIN OF ts_attribute_range_value,
        attribute_sign TYPE ztec_t_hc_attr-attribute_sign,
        attribute_opti TYPE ztec_t_hc_attr-attribute_opti,
        attribute_low	 TYPE ztec_t_hc_attr-attribute_low,
        attribute_high TYPE ztec_t_hc_attr-attribute_high,
      END OF   ts_attribute_range_value .
  types:
    tt_attribute_range_value TYPE STANDARD TABLE OF ts_attribute_range_value
                      WITH NON-UNIQUE KEY primary_key COMPONENTS attribute_sign attribute_opti attribute_low attribute_high .
  types:
    BEGIN OF ts_attribute_range_value_det,
        attribute_guid TYPE ztec_t_hc_attr-attribute_guid.
            INCLUDE TYPE ts_attribute_range_value.
    TYPES :
  END OF   ts_attribute_range_value_det .
  types:
    tt_attribute_range_value_det TYPE SORTED TABLE OF ts_attribute_range_value_det
                                          WITH NON-UNIQUE KEY primary_key COMPONENTS attribute_guid .
  types:
    BEGIN OF ts_attribute_range_data,
        attribute_guid_regroup  TYPE ztec_t_hc_attr-attribute_guid_regroup,
        t_attribute_range_value TYPE tt_attribute_range_value_det,
      END OF   ts_attribute_range_data .
  types:
    tt_attribute_range_data TYPE SORTED TABLE OF ts_attribute_range_data
                    WITH NON-UNIQUE KEY primary_key COMPONENTS attribute_guid_regroup .
  types:
    BEGIN OF ts_attribute_source_code_data,
        attribute_guid_regroup TYPE ztec_t_hc_attr-attribute_guid_regroup,
        t_source_code          TYPE stringtab,
      END OF   ts_attribute_source_code_data .
  types:
    tt_attribute_source_code_data TYPE SORTED TABLE OF ts_attribute_source_code_data
                    WITH NON-UNIQUE KEY primary_key COMPONENTS attribute_guid_regroup .
  types:
    BEGIN OF ts_attribute_logical_key,
        attribute_name TYPE ztec_t_hc_attr-attribute_name,
        attribute_key1 TYPE ztec_t_hc_attr-attribute_key1,
        attribute_key2 TYPE ztec_t_hc_attr-attribute_key2,
        attribute_key3 TYPE ztec_t_hc_attr-attribute_key3,
        attribute_key4 TYPE ztec_t_hc_attr-attribute_key4,
      END OF   ts_attribute_logical_key .
  types:
    tt_attribute_logical_key TYPE SORTED TABLE OF ts_attribute_logical_key
                                               WITH UNIQUE KEY primary_key COMPONENTS attribute_name attribute_key1 attribute_key3 attribute_key4 .
  types:
    BEGIN OF ts_attribute_logical_keyx,
        attribute_name TYPE flag,
        attribute_key1 TYPE flag,
        attribute_key2 TYPE flag,
        attribute_key3 TYPE flag,
        attribute_key4 TYPE flag,
      END OF   ts_attribute_logical_keyx .
  types:
    BEGIN OF ts_hardcode_attribute_data.
            INCLUDE TYPE ts_attribute_logical_key.
            INCLUDE TYPE ts_attribute_range_value.
    TYPES :
      attribute_as_range TYPE ztec_t_hc_attr-attribute_as_range,
      END OF   ts_hardcode_attribute_data .
  types:
    t_hardcode_attribute_data TYPE SORTED TABLE OF ts_hardcode_attribute_data
                                                  WITH UNIQUE KEY primary_key COMPONENTS attribute_name attribute_key1 attribute_key3 attribute_key4 .

  constants MC_FILE_TYPE_HARDCODE type STRING value 'hc' ##NO_TEXT.
  data MV_REPID type ZTEC_HC_REPID read-only .

  methods CONSTRUCTOR
    importing
      !IV_REPID type SY-REPID
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods HARDCODE_COPY
    importing
      !IV_REPID_NEW type ZTEC_T_HC_VERS-REPID optional
    returning
      value(RO_HARDCODE_MAINTAIN) type ref to ZCL_HARDCODE_MAINTAIN
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods HARDCODE_DATA_GET
    exporting
      !ET_VERSION type ZTEC_T_HC_VERS_TT
      !ET_PARAMETER type ZTEC_T_HC_PARAM_TT
      !ET_ATTRIBUTE type ZTEC_T_HC_ATTR_TT
      !ET_SOURCE_CODE type ZTEC_T_HC_ATTRIBUTE_SOURCE
      !ET_JOIN type ZVTEC_T_HC_TT .
  methods VERSION_ADD
    importing
      !IV_VERSION_ID type ZTEC_HC_VERSION_ID
      !IV_IS_PRIMARY type FLAG
    exporting
      !ES_VERSION_DATA type ZTEC_T_HC_VERS
    returning
      value(RV_VERSION_GUID) type ZTEC_HC_VERSION_GUID
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods VERSION_SET
    importing
      !IV_VERSION_GUID type ZTEC_T_HC_VERS-VERSION_GUID
      !IV_NEW_VERSION_ID type ZTEC_T_HC_VERS-VERSION_ID optional
      !IV_NEW_VERSION_PRIMARY type ZTEC_T_HC_VERS-VERSION_PRIMARY optional
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods VERSION_DEL
    importing
      !IV_VERSION_GUID type ZTEC_HC_VERSION_GUID optional
    preferred parameter IV_VERSION_GUID
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods VERSION_COPY
    importing
      !IV_VERSION_GUID_COPY type ZTEC_T_HC_VERS-VERSION_GUID
      !IV_VERSION_ID_NEW type ZTEC_T_HC_VERS-VERSION_ID optional
      !IV_COPY_CHILDREN type XFELD optional
    preferred parameter IV_VERSION_GUID_COPY
    exporting
      !ES_VERSION_DATA type ZTEC_T_HC_VERS
      !ET_PARAMETER_DATA type ZTEC_T_HC_PARAM_TT
      !ET_ATTRIBUTE_DATA type ZTEC_T_HC_ATTR_TT
      !ET_ATTRIBUTE_RANGE_DATA type ZCL_HARDCODE_MAINTAIN=>TT_ATTRIBUTE_RANGE_DATA
      !ET_ATTRIBUTE_SOURCE_CODE_DATA type ZCL_HARDCODE_MAINTAIN=>TT_ATTRIBUTE_SOURCE_CODE_DATA
    returning
      value(RV_VERSION_GUID) type ZTEC_HC_VERSION_GUID
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods VERSION_GET_NEXT
    returning
      value(RV_VERSION) type ZTEC_HC_VERSION_ID .
  methods VERSION_PRIMARY_SET
    importing
      !IV_VERSION_GUID type ZTEC_HC_VERSION_GUID
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods PARAMETER_ADD
    importing
      !IV_VERSION_GUID type ZTEC_HC_VERSION_GUID
      !IV_PARAMETER_NAME type ZTEC_HC_PARAMETER_NAME
    exporting
      !ES_PARAMETER_DATA type ZTEC_T_HC_PARAM
    returning
      value(RV_PARAMETER_GUID) type ZTEC_HC_PARAMETER_GUID
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods PARAMETER_SET
    importing
      !IV_PARAMETER_GUID type ZTEC_T_HC_PARAM-PARAMETER_GUID
      !IV_NEW_PARAMETER_NAME type ZTEC_T_HC_PARAM-PARAMETER_NAME optional
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods PARAMETER_DEL
    importing
      !IV_VERSION_GUID type ZTEC_T_HC_VERS-VERSION_GUID optional
      !IV_PARAMETER_GUID type ZTEC_HC_PARAMETER_GUID optional
    preferred parameter IV_PARAMETER_GUID .
  methods PARAMETER_COPY
    importing
      !IV_VERSION_GUID_COPY type ZTEC_T_HC_VERS-VERSION_GUID optional
      !IV_VERSION_GUID_NEW type ZTEC_HC_VERSION_GUID optional
      !IV_PARAMETER_GUID_COPY type ZTEC_HC_PARAMETER_GUID optional
      !IV_PARAMETER_NAME_NEW type ZTEC_T_HC_PARAM-PARAMETER_NAME optional
      !IV_COPY_CHILDREN type XFELD optional
    preferred parameter IV_PARAMETER_GUID_COPY
    exporting
      !ES_PARAMETER_DATA type ZTEC_T_HC_PARAM
      !ET_PARAMETER_DATA type ZTEC_T_HC_PARAM_TT
      !ET_ATTRIBUTE_DATA type ZTEC_T_HC_ATTR_TT
      !ET_ATTRIBUTE_RANGE_DATA type ZCL_HARDCODE_MAINTAIN=>TT_ATTRIBUTE_RANGE_DATA
      !ET_ATTRIBUTE_SOURCE_CODE_DATA type ZCL_HARDCODE_MAINTAIN=>TT_ATTRIBUTE_SOURCE_CODE_DATA
    returning
      value(RV_PARAMETER_GUID) type ZTEC_HC_PARAMETER_GUID
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods ATTRIBUTE_ADD
    importing
      !IV_PARAMETER_GUID type ZTEC_HC_PARAMETER_GUID
      !IS_ATTRIBUTE_LOGICAL_KEY type TS_ATTRIBUTE_LOGICAL_KEY
      !IR_RANGES_VALUE type STANDARD TABLE optional
      !IT_SOURCE_CODE type STRINGTAB optional
    exporting
      !ES_ATTRIBUTE_DATA type ZTEC_T_HC_ATTR
      !ES_ATTRIBUTE_RANGE_DATA type ZCL_HARDCODE_MAINTAIN=>TS_ATTRIBUTE_RANGE_DATA
      !ES_ATTRIBUTE_SOURCE_CODE_DATA type ZCL_HARDCODE_MAINTAIN=>TS_ATTRIBUTE_SOURCE_CODE_DATA
    returning
      value(RV_ATTRIBUTE_GUID_REGROUP) type ZTEC_HC_ATTRIBUTE_GUID_REGROUP
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods ATTRIBUTE_SET
    importing
      !IV_PARAMETER_GUID type ZTEC_T_HC_PARAM-PARAMETER_GUID
      !IV_ATTRIBUTE_GUID_REGROUP type ZTEC_T_HC_ATTR-ATTRIBUTE_GUID
      !IS_NEW_ATTRIBUTE_LOGICAL_KEY type TS_ATTRIBUTE_LOGICAL_KEY optional
      !IS_NEW_ATTRIBUTE_LOGICAL_KEYX type TS_ATTRIBUTE_LOGICAL_KEYX optional
      !IR_NEW_RANGES_VALUE type STANDARD TABLE optional
      !IV_REPLACE_RANGES_VALUE type XSDBOOLEAN optional
      !IT_NEW_SOURCE_CODE_VALUE type STRINGTAB optional
      !IV_REPLACE_SOURCE_CODE type XSDBOOLEAN optional
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods ATTRIBUTE_DEL
    importing
      !IV_PARAMETER_GUID type ZTEC_T_HC_PARAM-PARAMETER_GUID optional
      !IV_ATTRIBUTE_GUID_REGROUP type ZTEC_HC_ATTRIBUTE_GUID_REGROUP optional
      !IV_ATTRIBUTE_GUID type ZTEC_HC_ATTRIBUTE_GUID optional
      !IV_EXCEPT_HIMSELF type FLAG optional
    preferred parameter IV_ATTRIBUTE_GUID_REGROUP .
  methods ATTRIBUTE_COPY
    importing
      !IV_PARAMETER_GUID_COPY type ZTEC_T_HC_PARAM-PARAMETER_GUID optional
      !IV_PARAMETER_GUID_NEW type ZTEC_T_HC_PARAM-PARAMETER_GUID optional
      !IV_ATTRIBUTE_GUID_REGROUP_COPY type ZTEC_HC_ATTRIBUTE_GUID_REGROUP optional
      !IV_ATTRIBUTE_NAME_NEW type ZTEC_T_HC_ATTR-ATTRIBUTE_NAME optional
    preferred parameter IV_ATTRIBUTE_GUID_REGROUP_COPY
    exporting
      !ES_ATTRIBUTE_DATA type ZTEC_T_HC_ATTR
      !ET_ATTRIBUTE_DATA type ZTEC_T_HC_ATTR_TT
      !ET_ATTRIBUTE_RANGE_DATA type ZCL_HARDCODE_MAINTAIN=>TT_ATTRIBUTE_RANGE_DATA
      !ET_ATTRIBUTE_SOURCE_CODE_DATA type ZCL_HARDCODE_MAINTAIN=>TT_ATTRIBUTE_SOURCE_CODE_DATA
    returning
      value(RV_ATTRIBUTE_GUID_REGROUP) type ZTEC_HC_ATTRIBUTE_GUID_REGROUP
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods SAVE_TO_DB
    importing
      !IV_COMMIT type FLAG default ABAP_TRUE
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods IS_CHANGED
    returning
      value(RV_CHANGED) type FLAG .
  class-methods INTEGRITY_CHECK .
  class-methods TRANSPORT_REQUEST_CREATE
    importing
      !IV_REPID type ZTEC_HC_REPID
    returning
      value(RV_TRKORR) type TRKORR
    raising
      ZCX_HARDCODE_MAINTAIN .
  PROTECTED SECTION.
private section.

  types:
    BEGIN OF ts_hardcode_version.
          INCLUDE TYPE ztec_t_hc_vers.
  TYPES :
    volatile TYPE flag,
    updated  TYPE flag,
    END OF   ts_hardcode_version .
  types:
    tt_hardcode_version TYPE SORTED TABLE OF ts_hardcode_version WITH UNIQUE KEY primary_key COMPONENTS version_guid
                                                              WITH UNIQUE SORTED KEY second_key  COMPONENTS repid version_id .
  types:
    BEGIN OF ts_hardcode_parameter.
          INCLUDE TYPE ztec_t_hc_param.
  TYPES :
    volatile TYPE flag,
    updated  TYPE flag,
    END OF   ts_hardcode_parameter .
  types:
    tt_hardcode_parameter TYPE SORTED TABLE OF ts_hardcode_parameter WITH UNIQUE KEY primary_key COMPONENTS parameter_guid
                                                                  WITH UNIQUE SORTED KEY second_key  COMPONENTS version_guid parameter_name .
  types:
    BEGIN OF ts_hardcode_attribute.
          INCLUDE TYPE ztec_t_hc_attr.
  TYPES :
    volatile TYPE flag,
    updated  TYPE flag,
    END OF   ts_hardcode_attribute .
  types:
    tt_hardcode_attribute TYPE SORTED TABLE OF ts_hardcode_attribute WITH UNIQUE KEY primary_key COMPONENTS attribute_guid_regroup attribute_guid
                                                              WITH NON-UNIQUE SORTED KEY second_key  COMPONENTS parameter_guid attribute_name attribute_key1 attribute_key2 attribute_key3 attribute_key4 .
  types:
    BEGIN OF ts_attribute_key,
      attribute_guid_regroup TYPE ztec_t_hc_attr-attribute_guid_regroup,
      attribute_guid         TYPE ztec_t_hc_attr-attribute_guid,
    END OF   ts_attribute_key .
  types:
    tt_attribute_key TYPE STANDARD TABLE OF ts_attribute_key
                                 WITH NON-UNIQUE KEY primary_key COMPONENTS attribute_guid_regroup attribute_guid .
  types:
    BEGIN OF ts_attribute_source_code,
      attribute_guid_regroup TYPE ztec_t_hc_attr-attribute_guid_regroup,
      t_source_code          TYPE stringtab,
      volatile               TYPE flag,
      updated                TYPE flag,
    END OF   ts_attribute_source_code .
  types:
    tt_attribute_source_code TYPE SORTED TABLE OF ts_attribute_source_code
            WITH UNIQUE KEY primary_key COMPONENTS attribute_guid_regroup .
  types:
    BEGIN OF ts_work_data,
      t_hardcode_version         TYPE zcl_hardcode_maintain=>tt_hardcode_version,
      t_hardcode_parameter       TYPE zcl_hardcode_maintain=>tt_hardcode_parameter,
      t_hardcode_attribute       TYPE zcl_hardcode_maintain=>tt_hardcode_attribute,
      t_hc_attribute_source_code TYPE zcl_hardcode_maintain=>tt_attribute_source_code,
    END OF   ts_work_data .
  types:
    BEGIN OF ts_deleted_data,
      t_version_guid     TYPE epic_t_guid,
      t_parameter_guid   TYPE epic_t_guid,
      t_attribute_guid   TYPE zcl_hardcode_maintain=>tt_attribute_key,
      t_source_code_guid TYPE epic_t_guid,
    END OF   ts_deleted_data .

  data MS_WORK_DATA type ZCL_HARDCODE_MAINTAIN=>TS_WORK_DATA .
  data MS_DELETED_DATA type ZCL_HARDCODE_MAINTAIN=>TS_DELETED_DATA .

  methods HARDCODE_DATA_LOAD .
  methods VERSION_EXIST
    importing
      !IV_VERSION_ID type ZTEC_HC_VERSION_ID optional
      !IV_VERSION_GUID type ZTEC_HC_VERSION_GUID optional
    preferred parameter IV_VERSION_GUID
    returning
      value(RV_EXIST) type FLAG
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods VERSION_GET
    importing
      !IV_VERSION_GUID type ZTEC_HC_VERSION_GUID
    exporting
      !ES_HARDCODE_VERSION type ZCL_HARDCODE_MAINTAIN=>TS_HARDCODE_VERSION
    returning
      value(RO_HARDCODE_VERSION) type ref to ZCL_HARDCODE_MAINTAIN=>TS_HARDCODE_VERSION
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods PARAMETER_EXIST
    importing
      !IV_PARAMETER_GUID type ZTEC_HC_PARAMETER_GUID optional
      !IV_VERSION_GUID type ZTEC_T_HC_VERS-VERSION_GUID optional
      !IV_PARAMETER_NAME type ZTEC_HC_PARAMETER_NAME optional
    preferred parameter IV_PARAMETER_GUID
    returning
      value(RV_EXIST) type FLAG
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods PARAMETER_GET
    importing
      !IV_PARAMETER_GUID type ZTEC_T_HC_PARAM-PARAMETER_GUID
    exporting
      !ES_HARDCODE_PARAMETER type TS_HARDCODE_PARAMETER
    returning
      value(RO_HARDCODE_PARAMETER) type ref to TS_HARDCODE_PARAMETER
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods ATTRIBUTE_EXIST
    importing
      !IV_ATTRIBUTE_GUID_REGROUP type ZTEC_HC_ATTRIBUTE_GUID_REGROUP optional
      !IV_ATTRIBUTE_GUID type ZTEC_T_HC_ATTR-ATTRIBUTE_GUID optional
      !IV_PARAMETER_GUID type ZTEC_HC_PARAMETER_GUID optional
      !IS_ATTRIBUTE_LOGICAL_KEY type TS_ATTRIBUTE_LOGICAL_KEY optional
    preferred parameter IV_ATTRIBUTE_GUID_REGROUP
    returning
      value(RV_EXIST) type FLAG
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods ATTRIBUTE_GET
    importing
      !IV_ATTRIBUTE_GUID_REGROUP type ZTEC_T_HC_ATTR-ATTRIBUTE_GUID_REGROUP
      !IV_ATTRIBUTE_GUID type ZTEC_T_HC_ATTR-ATTRIBUTE_GUID optional
    exporting
      !ES_HARDCODE_ATTRIBUTE type ZCL_HARDCODE_MAINTAIN=>TS_HARDCODE_ATTRIBUTE
    returning
      value(RO_HARDCODE_ATTRIBUTE) type ref to ZCL_HARDCODE_MAINTAIN=>TS_HARDCODE_ATTRIBUTE
    raising
      ZCX_HARDCODE_MAINTAIN .
  methods GUID_RENEW
    importing
      !IV_DELETE_OLDER type XSDBOOLEAN .
  methods __RAISE_EXCEPTION
    importing
      !IO_EXCEPTION type ref to CX_ROOT optional
      value(IV_MSGID) type SY-MSGID default ZCL_HARDCODE=>MC_MY_MSGID
      value(IV_MSGNO) type SY-MSGNO optional
      value(IV_MSGV1) type ANY optional
      value(IV_MSGV2) type ANY optional
      value(IV_MSGV3) type ANY optional
      value(IV_MSGV4) type ANY optional
    preferred parameter IV_MSGNO
    raising
      ZCX_HARDCODE_MAINTAIN .
ENDCLASS.



CLASS ZCL_HARDCODE_MAINTAIN IMPLEMENTATION.


METHOD attribute_add.
*&---------------------------------------------------------------------*
*& Méthode         : ATTRIBUTE_ADD                                     *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Attribut - Création                               *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_hardcode_attribute       TYPE zcl_hardcode_maintain=>ts_hardcode_attribute,
    ls_attribute_range_value    TYPE zcl_hardcode_maintain=>ts_attribute_range_value_det,
    ls_hc_attribute_source_code TYPE zcl_hardcode_maintain=>ts_attribute_source_code.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  CLEAR : es_attribute_source_code_data, es_attribute_range_data, es_attribute_data.

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF me->attribute_exist(
      iv_parameter_guid        = iv_parameter_guid
      is_attribute_logical_key = is_attribute_logical_key
  ) EQ abap_true.
    " L'entrée existe déjà
    ""  --> Lève une Exception
    IF 1 = 2. MESSAGE e302(zhardcode). ENDIF.
    me->__raise_exception(
        iv_msgno = 302
        iv_msgv1 = is_attribute_logical_key-attribute_name
    ).

  ENDIF.

  " -----------------------------------------------------------
  " Ajout du nouveau Paramètre
  " -----------------------------------------------------------

  " Initialisation des données
  ls_hardcode_attribute-mandt          = sy-mandt.
  ls_hardcode_attribute-volatile       = abap_true.
  ls_hardcode_attribute-parameter_guid = iv_parameter_guid.
  ls_hardcode_attribute-attribute_name = is_attribute_logical_key-attribute_name.
  ls_hardcode_attribute-attribute_key1 = is_attribute_logical_key-attribute_key1.
  ls_hardcode_attribute-attribute_key2 = is_attribute_logical_key-attribute_key2.
  ls_hardcode_attribute-attribute_key3 = is_attribute_logical_key-attribute_key3.
  ls_hardcode_attribute-attribute_key4 = is_attribute_logical_key-attribute_key4.

  " Initialisation donnés tracabilité
  ls_hardcode_attribute-created_by     = sy-uname.
  GET TIME STAMP FIELD ls_hardcode_attribute-created_at.

  TRY.
      " Création ID Unique
      ls_hardcode_attribute-attribute_guid_regroup = cl_system_uuid=>create_uuid_c32_static( ).

    CATCH cx_uuid_error.
      " Erreur lors de la création du GUID
      ""  --> Génération Nombre aléatoire
      ls_hardcode_attribute-attribute_guid_regroup = cl_abap_random=>seed( ).

  ENDTRY.

  " Initialisation ligne de référence (GUID Unique = GUID Regroupement)
  rv_attribute_guid_regroup = ls_hardcode_attribute-attribute_guid = ls_hardcode_attribute-attribute_guid_regroup.

  " Initialisation Témoin Range & Code Source
  ls_hardcode_attribute-attribute_as_range       = boolc( NOT ir_ranges_value[] IS INITIAL ).
  ls_hardcode_attribute-attribute_as_source_code = boolc( NOT it_source_code[] IS INITIAL ).

  " Ajout dans la table Interne
  INSERT ls_hardcode_attribute INTO TABLE me->ms_work_data-t_hardcode_attribute.

  " -----------------------------------------------------------
  " Gestion Code Source
  " -----------------------------------------------------------

  IF NOT it_source_code[] IS INITIAL.
    " Ajout du Code Source
    READ TABLE me->ms_work_data-t_hc_attribute_source_code
      WITH TABLE KEY attribute_guid_regroup = ls_hardcode_attribute-attribute_guid_regroup
      ASSIGNING FIELD-SYMBOL(<lfs_s_hc_attr_source_code>).
    IF sy-subrc NE 0.
      " Aucune correspondance
      ""  --> Création nouvelle entrée
      ls_hc_attribute_source_code-volatile               = abap_true.
      ls_hc_attribute_source_code-attribute_guid_regroup = ls_hardcode_attribute-attribute_guid_regroup.
      INSERT ls_hc_attribute_source_code INTO TABLE me->ms_work_data-t_hc_attribute_source_code
                                          ASSIGNING <lfs_s_hc_attr_source_code>.

    ELSE.
      " Existe déjà
      ""  --> Initialisation Témoin de MàJ
      <lfs_s_hc_attr_source_code>-updated = abap_true.

    ENDIF.

    " Initialisation Code Source
    <lfs_s_hc_attr_source_code>-t_source_code[] = it_source_code[].

  ENDIF.

  " -----------------------------------------------------------
  " Gestion Valeurs Multiple
  " -----------------------------------------------------------

  IF NOT ir_ranges_value[] IS INITIAL.
    " Ajout des Valeurs de Range
    me->attribute_set(
        iv_parameter_guid         = iv_parameter_guid
        iv_attribute_guid_regroup = ls_hardcode_attribute-attribute_guid_regroup
        ir_new_ranges_value       = ir_ranges_value
    ).

    IF es_attribute_range_data IS SUPPLIED.
      " Alimentation table de valeurs des Attributs
      READ TABLE me->ms_work_data-t_hardcode_attribute WITH KEY attribute_guid_regroup = ls_hardcode_attribute-attribute_guid_regroup
                                                   TRANSPORTING NO FIELDS BINARY SEARCH.
      IF sy-subrc EQ 0.
        " Au moins une correspondance
        ""  --> Création nouvelle entrée dans la table de sortie
        es_attribute_range_data-attribute_guid_regroup = ls_hardcode_attribute-attribute_guid_regroup.

        ""  --> Parcours l'ensemble des Attributs
        LOOP AT me->ms_work_data-t_hardcode_attribute ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode_attribute>)
                                                           FROM sy-tabix.

          CLEAR : ls_attribute_range_value.

          IF <lfs_s_hardcode_attribute>-attribute_guid_regroup NE ls_hardcode_attribute-attribute_guid_regroup.
            " On ne traite plus le même Attribut
            ""  --> Arrêt de la boucle
            EXIT.

          ENDIF.

          IF <lfs_s_hardcode_attribute>-attribute_guid_regroup EQ <lfs_s_hardcode_attribute>-attribute_guid.
            " Il s'agit de l'Attribut lui-même
            ""  --> Ne pas tenir compte
            CONTINUE.

          ENDIF.

          " Initialisation données
          MOVE-CORRESPONDING <lfs_s_hardcode_attribute> TO ls_attribute_range_value.
          ls_attribute_range_value-attribute_guid = <lfs_s_hardcode_attribute>-attribute_guid.

          " Ajout de la valeur dans la table de retour
          INSERT ls_attribute_range_value INTO TABLE es_attribute_range_data-t_attribute_range_value.

        ENDLOOP.    "Fin parcours des valeurs de l'Attribut

      ENDIF.        "Fin de test présence d'au moins une correspondance

    ENDIF.          "Fin de test réstitution des valeurs d'Attributs ?

  ENDIF.            "Fin valeurs d'Attributs présentes ?

  " -----------------------------------------------------------
  " Initialisation paramètres de retour
  " -----------------------------------------------------------

  IF es_attribute_data IS SUPPLIED.
    " Retourne les données
    MOVE-CORRESPONDING ls_hardcode_attribute TO es_attribute_data.

  ENDIF.

  IF es_attribute_source_code_data IS SUPPLIED.
    " Code Source - Retourne information
    es_attribute_source_code_data-t_source_code[] = it_source_code[].
    es_attribute_source_code_data-attribute_guid_regroup = ls_hardcode_attribute-attribute_guid_regroup.

  ENDIF.

ENDMETHOD.


METHOD attribute_copy.
*&---------------------------------------------------------------------*
*& Méthode         : ATTRIBUTE_COPY                                    *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Attribut - Copie                                  *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_source_code  TYPE stringtab,
    lr_ranges_value TYPE me->tt_attribute_range_value.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    lsr_ranges_value              TYPE me->ts_attribute_range_value,
    ls_attribute_data             TYPE ztec_t_hc_attr,
    ls_attribute_range_data       TYPE zcl_hardcode_maintain=>ts_attribute_range_data,
    ls_attribute_logical_key      TYPE me->ts_attribute_logical_key,
    ls_attribute_source_code_data TYPE zcl_hardcode_maintain=>ts_attribute_source_code_data.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        lo_cx_exception TYPE REF TO cx_root.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  CLEAR   : es_attribute_data.
  REFRESH : et_attribute_source_code_data, et_attribute_range_data, et_attribute_data.

  IF  NOT iv_parameter_guid_new  IS INITIAL
  AND NOT iv_parameter_guid_copy IS INITIAL.
    " -----------------------------------------------------------
    " Copie des Attributs du Paramètre
    " -----------------------------------------------------------

    " Récupération position première occurence des Attributs du Paramètre
    READ TABLE me->ms_work_data-t_hardcode_attribute WITH KEY second_key
                                                   COMPONENTS parameter_guid = iv_parameter_guid_copy
                                                TRANSPORTING NO FIELDS.
    IF sy-subrc NE 0.
      " Aucune correspondance
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Parcours l'ensemble des Attributs du Paramètre
    LOOP AT me->ms_work_data-t_hardcode_attribute ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode_attribute>)
                                                  USING KEY second_key
                                                       FROM sy-tabix.

      CLEAR : ls_attribute_data.

      IF <lfs_s_hardcode_attribute>-parameter_guid NE iv_parameter_guid_copy.
        " On ne traite plus le même Paramètre
        ""  --> Arrêt du traitement
        EXIT.

      ENDIF.

      AT NEW attribute_guid_regroup.
        " A chaque changement de GUID de Regrupement
        ""  --> Réinitialisation données
        CLEAR : ls_attribute_logical_key, lr_ranges_value[].

      ENDAT.

      IF NOT <lfs_s_hardcode_attribute>-attribute_sign IS INITIAL.
        " Range valorisé
        ""  --> Ajout des valeurs
        CLEAR : lsr_ranges_value.
        lsr_ranges_value-attribute_low  = <lfs_s_hardcode_attribute>-attribute_low.
        lsr_ranges_value-attribute_sign = <lfs_s_hardcode_attribute>-attribute_sign.
        lsr_ranges_value-attribute_high = <lfs_s_hardcode_attribute>-attribute_high.
        lsr_ranges_value-attribute_opti = <lfs_s_hardcode_attribute>-attribute_opti.
        APPEND lsr_ranges_value TO lr_ranges_value.

      ENDIF.

      AT END OF attribute_guid_regroup.
        " Lors du traitement du dernier GUID de Regroupement
        ""  --> Réinitialisation
        REFRESH : lt_source_code.

        ""  --> Initialisation Clef Logique
        ls_attribute_logical_key-attribute_name = <lfs_s_hardcode_attribute>-attribute_name.
        ls_attribute_logical_key-attribute_key1 = <lfs_s_hardcode_attribute>-attribute_key1.
        ls_attribute_logical_key-attribute_key2 = <lfs_s_hardcode_attribute>-attribute_key2.
        ls_attribute_logical_key-attribute_key3 = <lfs_s_hardcode_attribute>-attribute_key3.
        ls_attribute_logical_key-attribute_key4 = <lfs_s_hardcode_attribute>-attribute_key4.

        IF <lfs_s_hardcode_attribute>-attribute_as_source_code EQ abap_true.
          TRY.
              " Récupération Code Source
              lt_source_code = me->ms_work_data-t_hc_attribute_source_code[
                  attribute_guid_regroup = <lfs_s_hardcode_attribute>-attribute_guid_regroup
                ]-t_source_code.

            CATCH cx_sy_itab_line_not_found.
              " Pas de données

          ENDTRY.

        ELSE.
          ""  --> Réinitialisation
          REFRESH : lt_source_code.

        ENDIF.

        TRY.
            ""  --> Création du nouvel Attribut
            me->attribute_add(
              EXPORTING
                iv_parameter_guid             = iv_parameter_guid_new       "Sur le nouveau paramètre
                is_attribute_logical_key      = ls_attribute_logical_key
                ir_ranges_value               = lr_ranges_value
                it_source_code                = lt_source_code
              IMPORTING
                es_attribute_data             = ls_attribute_data
                es_attribute_range_data       = ls_attribute_range_data
                es_attribute_source_code_data = ls_attribute_source_code_data
            ).

            IF et_attribute_data IS SUPPLIED.
              " Alimentation table données
              APPEND ls_attribute_data TO et_attribute_data.

            ENDIF.

            IF  et_attribute_source_code_data     IS SUPPLIED
            AND NOT ls_attribute_source_code_data IS INITIAL.
              " Ajout Code Source
              APPEND ls_attribute_source_code_data TO et_attribute_source_code_data.

            ENDIF.

            IF  et_attribute_range_data     IS SUPPLIED
            AND NOT ls_attribute_range_data IS INITIAL.
              " Ajout valeur range
              INSERT ls_attribute_range_data INTO TABLE et_attribute_range_data.

            ENDIF.

          CATCH zcx_hardcode_maintain.
            " Erreur lors de la création de l'Attribut
            ""  --> Tant pis ...

        ENDTRY.

      ENDAT.

    ENDLOOP.

  ELSEIF NOT iv_attribute_guid_regroup_copy IS INITIAL.
    " -----------------------------------------------------------
    " Copie de l'Attribut du Paramètre
    " -----------------------------------------------------------

    " Récupération position première occurence des Attributs du Regroupement
    READ TABLE me->ms_work_data-t_hardcode_attribute WITH KEY attribute_guid_regroup = iv_attribute_guid_regroup_copy
                                              TRANSPORTING NO FIELDS
                                                       BINARY SEARCH.
    IF sy-subrc NE 0.
      " Aucune correspondance
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Parcours l'ensemble des Attributs du Regroupement
    LOOP AT me->ms_work_data-t_hardcode_attribute ASSIGNING <lfs_s_hardcode_attribute>
                                                       FROM sy-tabix.

      IF <lfs_s_hardcode_attribute>-attribute_guid_regroup NE iv_attribute_guid_regroup_copy.
        " On ne traite plus le même Regroupement d'Attribut
        ""  --> Arrêt du traitement
        EXIT.

      ENDIF.

      IF NOT <lfs_s_hardcode_attribute>-attribute_sign IS INITIAL.
        " Range valorisé
        ""  --> Ajout des valeurs
        CLEAR : lsr_ranges_value.
        lsr_ranges_value-attribute_low  = <lfs_s_hardcode_attribute>-attribute_low.
        lsr_ranges_value-attribute_sign = <lfs_s_hardcode_attribute>-attribute_sign.
        lsr_ranges_value-attribute_high = <lfs_s_hardcode_attribute>-attribute_high.
        lsr_ranges_value-attribute_opti = <lfs_s_hardcode_attribute>-attribute_opti.
        APPEND lsr_ranges_value TO lr_ranges_value.

      ENDIF.

      AT END OF attribute_guid_regroup.
        " Lors du traitement du dernier GUID de Regroupement
        ""  --> Réinitialisation
        REFRESH : lt_source_code.

        ""  --> Initialisation Clef Logique
        IF iv_attribute_name_new IS INITIAL.
          ls_attribute_logical_key-attribute_name = |{ <lfs_s_hardcode_attribute>-attribute_name }_COPY|. "#EC NOTEXT

        ELSE.
          ls_attribute_logical_key-attribute_name = iv_attribute_name_new.

        ENDIF.

        " Initialisation Clefs variantes
        ls_attribute_logical_key-attribute_key1 = <lfs_s_hardcode_attribute>-attribute_key1.
        ls_attribute_logical_key-attribute_key2 = <lfs_s_hardcode_attribute>-attribute_key2.
        ls_attribute_logical_key-attribute_key3 = <lfs_s_hardcode_attribute>-attribute_key3.
        ls_attribute_logical_key-attribute_key4 = <lfs_s_hardcode_attribute>-attribute_key4.

        IF <lfs_s_hardcode_attribute>-attribute_as_source_code EQ abap_true.
          TRY.
              " Récupération Code Source
              lt_source_code = me->ms_work_data-t_hc_attribute_source_code[
                  attribute_guid_regroup = <lfs_s_hardcode_attribute>-attribute_guid_regroup
                ]-t_source_code.

            CATCH cx_sy_itab_line_not_found.
              " Pas de données

          ENDTRY.

        ELSE.
          ""  --> Réinitialisation
          REFRESH : lt_source_code.

        ENDIF.

        TRY.
            ""  --> Création du nouvel Attribut
            me->attribute_add(
              EXPORTING
                iv_parameter_guid             = <lfs_s_hardcode_attribute>-parameter_guid
                is_attribute_logical_key      = ls_attribute_logical_key
                ir_ranges_value               = lr_ranges_value
                it_source_code                = lt_source_code
              IMPORTING
                es_attribute_data             = es_attribute_data
                es_attribute_range_data       = ls_attribute_range_data
                es_attribute_source_code_data = ls_attribute_source_code_data
            ).

            IF  NOT ls_attribute_range_data IS INITIAL
            AND NOT et_attribute_range_data IS SUPPLIED.
              " Ajout valeur range
              INSERT ls_attribute_range_data INTO TABLE et_attribute_range_data.

            ENDIF.

            IF  et_attribute_source_code_data     IS SUPPLIED
            AND NOT ls_attribute_source_code_data IS INITIAL.
              " Ajout Code Source
              APPEND ls_attribute_source_code_data TO et_attribute_source_code_data.

            ENDIF.

          CATCH zcx_hardcode_maintain INTO lo_cx_exception.
            " Erreur lors de la création de l'Attribut
            ""  --> Lève l'Exception
            me->__raise_exception( io_exception = lo_cx_exception ).

        ENDTRY.

      ENDAT.

    ENDLOOP.

  ELSE.
    " -----------------------------------------------------------
    " Pas assez de paramètre
    " -----------------------------------------------------------

    IF 1 = 2. MESSAGE e501(zhardcode). ENDIF.
    me->__raise_exception( iv_msgno = 501 ).                "#EC NOTEXT

  ENDIF.

ENDMETHOD.


METHOD attribute_del.
*&---------------------------------------------------------------------*
*& Méthode         : ATTRIBUTE_DEL                                     *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Attribut - Suppression                            *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_attribute_key TYPE zcl_hardcode_maintain=>ts_attribute_key.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_s_hardcode_attribute> TYPE zcl_hardcode_maintain=>ts_hardcode_attribute.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Suppression des données de l'Attribut
  " -----------------------------------------------------------

  IF NOT iv_parameter_guid IS INITIAL.
    " -----------------------------------------------------------
    " Suppression des Attributs du Paramètre
    " -----------------------------------------------------------

    " Suppression par Paramètre
    IF me->parameter_exist( iv_parameter_guid ) EQ abap_false.
      " Le Paramètre n'exise pas
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Récupération position première occurence des Attributs
    READ TABLE me->ms_work_data-t_hardcode_attribute WITH KEY second_key
                                                   COMPONENTS parameter_guid = iv_parameter_guid
                                                 TRANSPORTING NO FIELDS.
    IF sy-subrc EQ 0.
      " Parcours l'ensemble des Attributs du Paramètre
      LOOP AT me->ms_work_data-t_hardcode_attribute USING KEY second_key
                                                    ASSIGNING <lfs_s_hardcode_attribute>
                                                         FROM sy-tabix.

        IF <lfs_s_hardcode_attribute>-parameter_guid NE iv_parameter_guid.
          " On ne traite plus le même Paramètre
          ""  --> Arrêt de la boucle
          EXIT.

        ENDIF.

        IF  iv_except_himself EQ abap_true
        AND <lfs_s_hardcode_attribute>-attribute_guid_regroup EQ <lfs_s_hardcode_attribute>-attribute_guid.
          " Pas de suppression d'elle-même demandée
          ""  --> Passe à l'itération suivante
          CONTINUE.

        ENDIF.

        IF <lfs_s_hardcode_attribute>-volatile EQ abap_false.
          " Ajout du GUID de l'Attribut pour suppression en DB
          ls_attribute_key-attribute_guid         = <lfs_s_hardcode_attribute>-attribute_guid.
          ls_attribute_key-attribute_guid_regroup = <lfs_s_hardcode_attribute>-attribute_guid_regroup.
          APPEND ls_attribute_key TO me->ms_deleted_data-t_attribute_guid.

        ENDIF.

        IF iv_except_himself EQ abap_false.
          " Suppression de l'Attribut lui-même
          ""  --> Ajout dans table pour suppression Code Source
          APPEND <lfs_s_hardcode_attribute>-attribute_guid_regroup TO me->ms_deleted_data-t_source_code_guid.

          ""  --> Suppression du Code Source de l'Attribut
          DELETE me->ms_work_data-t_hc_attribute_source_code WHERE attribute_guid_regroup EQ <lfs_s_hardcode_attribute>-attribute_guid_regroup.

        ENDIF.

        " Suppression du Paramètre
        DELETE me->ms_work_data-t_hardcode_attribute USING KEY loop_key.

      ENDLOOP.

    ENDIF.

  ELSEIF NOT iv_attribute_guid IS INITIAL.
    " -----------------------------------------------------------
    " Suppression de l'Attribut
    " -----------------------------------------------------------

    " Suppression d'une entrée unique de l'Attribut
    IF me->attribute_exist(
          iv_attribute_guid_regroup = iv_attribute_guid_regroup
          iv_attribute_guid         = iv_attribute_guid
       ) EQ abap_false.
      " L'Attribut n'existe pas
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    IF me->ms_work_data-t_hardcode_attribute[
         attribute_guid_regroup = iv_attribute_guid_regroup
         attribute_guid         = iv_attribute_guid
       ]-volatile EQ abap_false.
      " Ajout du GUID de l'Attribut pour suppression
      ls_attribute_key-attribute_guid         = iv_attribute_guid.
      ls_attribute_key-attribute_guid_regroup = iv_attribute_guid_regroup.
      APPEND ls_attribute_key TO me->ms_deleted_data-t_attribute_guid.

    ENDIF.

    " Suppression de l'Attribut
    DELETE me->ms_work_data-t_hardcode_attribute WHERE attribute_guid_regroup EQ iv_attribute_guid_regroup
                                                   AND attribute_guid         EQ iv_attribute_guid.

    IF iv_except_himself EQ abap_false.
      " Suppression de l'Attribut lui-même
      ""  --> Ajout dans table pour suppression Code Source
      APPEND iv_attribute_guid_regroup TO me->ms_deleted_data-t_source_code_guid.

      ""  --> Suppression du Code Source de l'Attribut
      DELETE me->ms_work_data-t_hc_attribute_source_code WHERE attribute_guid_regroup EQ iv_attribute_guid_regroup.

    ENDIF.

  ELSEIF NOT iv_attribute_guid_regroup IS INITIAL.
    " -----------------------------------------------------------
    " Suppression des l'Attributs
    " -----------------------------------------------------------

    " Suppression de toutes les entrées de l'Attribut
    IF me->attribute_exist( iv_attribute_guid_regroup ) EQ abap_false.
      " L'Attribut n'existe pas
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Récupération position première occurence
    READ TABLE me->ms_work_data-t_hardcode_attribute
      WITH KEY attribute_guid_regroup = iv_attribute_guid_regroup
      TRANSPORTING NO FIELDS BINARY SEARCH.
    IF sy-subrc EQ 0.
      " Parcours l'ensemble des données de cette Attribut
      LOOP AT me->ms_work_data-t_hardcode_attribute ASSIGNING <lfs_s_hardcode_attribute>
                                                         FROM sy-tabix.

        IF <lfs_s_hardcode_attribute>-attribute_guid_regroup NE iv_attribute_guid_regroup.
          " On ne traite plus le même Attribut
          ""  --> Arrêt de la boucle
          EXIT.

        ENDIF.

        IF  iv_except_himself EQ abap_true
        AND <lfs_s_hardcode_attribute>-attribute_guid_regroup EQ <lfs_s_hardcode_attribute>-attribute_guid.
          " Pas de suppression d'elle-même demandée
          ""  --> Passe à l'itération suivante
          CONTINUE.

        ENDIF.

        IF <lfs_s_hardcode_attribute>-volatile EQ abap_false.
          " Ajout de l'entrée dans la table de Suppression
          ls_attribute_key-attribute_guid         = <lfs_s_hardcode_attribute>-attribute_guid.
          ls_attribute_key-attribute_guid_regroup = <lfs_s_hardcode_attribute>-attribute_guid_regroup.
          APPEND ls_attribute_key TO me->ms_deleted_data-t_attribute_guid.

        ENDIF.

      ENDLOOP.

      IF iv_except_himself EQ abap_true.
        " Suppression des Attributs sauf lui-même
        DELETE me->ms_work_data-t_hardcode_attribute
         WHERE attribute_guid_regroup EQ <lfs_s_hardcode_attribute>-attribute_guid_regroup
           AND attribute_guid         NE <lfs_s_hardcode_attribute>-attribute_guid_regroup.

      ELSE.
        " Suppression des Attributs
        ""  --> Ajout dans table pour suppression Code Source
        APPEND <lfs_s_hardcode_attribute>-attribute_guid_regroup TO me->ms_deleted_data-t_source_code_guid.

        ""  --> Suppression du Code Source de l'Attribut
        DELETE me->ms_work_data-t_hc_attribute_source_code
         WHERE attribute_guid_regroup EQ <lfs_s_hardcode_attribute>-attribute_guid_regroup.

        ""  --> Suppression de tous les Attributs
        DELETE me->ms_work_data-t_hardcode_attribute
         WHERE attribute_guid_regroup EQ <lfs_s_hardcode_attribute>-attribute_guid_regroup.

      ENDIF.

    ENDIF.

  ENDIF.

ENDMETHOD.


METHOD attribute_exist.
*&---------------------------------------------------------------------*
*& Méthode         : ATTRIBUTE_EXIST                                   *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Attribut - Contrôle existence                     *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Recherche présence de l'Attribut
  " -----------------------------------------------------------

  IF NOT iv_attribute_guid_regroup IS INITIAL.
    " Recherche existence Attribut par son GUID
    IF NOT iv_attribute_guid IS INITIAL.
      " Ligne particulière
      READ TABLE me->ms_work_data-t_hardcode_attribute WITH TABLE KEY attribute_guid_regroup = iv_attribute_guid_regroup
                                                                      attribute_guid         = iv_attribute_guid
                                                         TRANSPORTING NO FIELDS.
    ELSE.
      " Attribut
      READ TABLE me->ms_work_data-t_hardcode_attribute WITH KEY attribute_guid_regroup = iv_attribute_guid_regroup
                                                   TRANSPORTING NO FIELDS BINARY SEARCH.

    ENDIF.

  ELSE.
    " Recherche Attribut par l'ID
    ""  --> Recherche existence du Paramètre
    IF me->parameter_exist( iv_parameter_guid ) NE abap_true.
      " Le Paramètre n'existe pas
      ""  --> Lève une exception
      IF 1 = 2. MESSAGE e201(zhardcode). ENDIF.
      me->__raise_exception(
          iv_msgno = 201
          iv_msgv1 = iv_parameter_guid
      ).

    ENDIF.

    ""  --> Recherche existence Attribut par son Nom
    READ TABLE me->ms_work_data-t_hardcode_attribute WITH TABLE KEY second_key
                                                         COMPONENTS parameter_guid = iv_parameter_guid
                                                                    attribute_name = is_attribute_logical_key-attribute_name
                                                                    attribute_key1 = is_attribute_logical_key-attribute_key1
                                                                    attribute_key2 = is_attribute_logical_key-attribute_key2
                                                                    attribute_key3 = is_attribute_logical_key-attribute_key3
                                                                    attribute_key4 = is_attribute_logical_key-attribute_key4
                                                       TRANSPORTING NO FIELDS.

  ENDIF.

  " Retourne le booléen
  rv_exist = boolc( sy-subrc EQ 0 ). "Vrai si la Version existe

ENDMETHOD.


METHOD attribute_get.
*&---------------------------------------------------------------------*
*& Méthode         : ATTRIBUTE_GET                                     *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Attribut - Récupération données                   *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_attribute_guid TYPE zcl_hardcode_maintain=>ts_hardcode_attribute-attribute_guid.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  CLEAR : es_hardcode_attribute.

  " -----------------------------------------------------------
  " Initialisation variable locale
  " -----------------------------------------------------------

  IF NOT iv_attribute_guid IS INITIAL.
    " Recherche ligne particulière
    lv_attribute_guid = iv_attribute_guid.

  ELSE.
    " Récupération ligne de référence
    lv_attribute_guid = iv_attribute_guid_regroup.

  ENDIF.

  " -----------------------------------------------------------
  " Récupération de l'entrée correspond à l'Attribut
  " -----------------------------------------------------------

  " Retourne les données de l'Attribut
  READ TABLE me->ms_work_data-t_hardcode_attribute WITH TABLE KEY attribute_guid_regroup = iv_attribute_guid_regroup
                                                                  attribute_guid         = lv_attribute_guid
                                                  REFERENCE INTO ro_hardcode_attribute.
  IF sy-subrc NE 0.
    " La version n'existe pas
    ""  --> Lève une Exception
    IF 1 = 2. MESSAGE e301(zhardcode). ENDIF.
    me->__raise_exception(
        iv_msgno = 301
        iv_msgv1 = iv_attribute_guid_regroup
    ).

  ENDIF.

  IF es_hardcode_attribute IS SUPPLIED.
    " Retourne les données (statiques)
    es_hardcode_attribute = ro_hardcode_attribute->*.

  ENDIF.

ENDMETHOD.


METHOD attribute_set.
*&---------------------------------------------------------------------*
*& Méthode         : ATTRIBUTE_SET                                     *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Attribut - Modification donneés                   *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_hc_source_code            TYPE zcl_hardcode_maintain=>ts_attribute_source_code,
    ls_attribute_key             TYPE zcl_hardcode_maintain=>ts_attribute_key,
    ls_hardcode_attribute        TYPE zcl_hardcode_maintain=>ts_hardcode_attribute,
    lo_hardcode_attribute        TYPE REF TO zcl_hardcode_maintain=>ts_hardcode_attribute,
    ls_new_attribute_logical_key TYPE zcl_hardcode_maintain=>ts_attribute_logical_key.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_delta TYPE flag,
    lv_subrc TYPE sy-subrc.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_low>                  TYPE any,
    <lfs_high>                 TYPE any,
    <lfs_sign>                 TYPE ddsign,
    <lfs_option>               TYPE ddoption,
    <lfs_valuex>               TYPE flag,
    <lfs_value_source>         TYPE any,
    <lfs_value_target>         TYPE any,
    <lfs_s_hardcode_attribute> TYPE zcl_hardcode_maintain=>ts_hardcode_attribute.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Récupération des données
  " -----------------------------------------------------------

  " Récupération des données de l'Attribut
  lo_hardcode_attribute = me->attribute_get( iv_attribute_guid_regroup ).

  " Initialisation données Clefs logique
  MOVE-CORRESPONDING lo_hardcode_attribute->* TO ls_new_attribute_logical_key.

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  " Contrôle nécessité de MàJ
  IF is_new_attribute_logical_keyx IS INITIAL
  AND ( ir_new_ranges_value[] IS INITIAL AND iv_replace_ranges_value EQ abap_false ).
    " Aucune données à modifier
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Traitement des modifications à apporter
  " -----------------------------------------------------------

  IF NOT is_new_attribute_logical_keyx IS INITIAL.
    " Contrôle les données à mettre à jour
    ""  --> Contrôle si présence delta entre les données
    WHILE lv_subrc IS INITIAL.

      UNASSIGN : <lfs_value_target>, <lfs_value_source>, <lfs_valuex>.

      " Récupération valeur champ indicateur de modification
      ASSIGN COMPONENT sy-index OF STRUCTURE is_new_attribute_logical_keyx
                                          TO <lfs_valuex>.
      IF sy-subrc NE 0.
        " Pointeur nulle
        ""  --> Arrêt de la boucle
        lv_subrc = 4.
        EXIT.

      ELSEIF <lfs_valuex> NE abap_true.
        " Pas de modification
        ""  --> Passe à l'itération suivante
        CONTINUE.

      ENDIF.

      " Récupération pointeur sur le champ Source
      ASSIGN COMPONENT sy-index OF STRUCTURE is_new_attribute_logical_key
                                          TO <lfs_value_source>.
      IF sy-subrc NE 0.
        " Pointeur nulle
        ""  --> Arrêt de la boucle
        lv_subrc = 4.
        EXIT.

      ENDIF.

      " Récupération pointeur sur le champ Cible
      ASSIGN COMPONENT sy-index OF STRUCTURE ls_new_attribute_logical_key
                                          TO <lfs_value_target>.

      " Comparaison des valeurs
      IF <lfs_value_target> EQ <lfs_value_source>.
        " Aucune modification
        ""  --> Passe à l'itération suivante
        CONTINUE.

      ELSE.
        " Modification
        ""  --> Initialisation Indicateur modification des données
        lv_delta = abap_true.

        ""  --> Initialisation de la nouvelle valeur
        <lfs_value_target> = <lfs_value_source>.

      ENDIF.

    ENDWHILE.

  ENDIF.

  IF NOT is_new_attribute_logical_keyx IS INITIAL
  OR lo_hardcode_attribute->attribute_name NE ls_new_attribute_logical_key-attribute_name.
    " Modificatîon du Nom ou des Clefs
    ""  --> Contrôle si pas de doublon
    IF me->attribute_exist(
          iv_parameter_guid        = iv_parameter_guid
          is_attribute_logical_key = ls_new_attribute_logical_key
      ) EQ abap_true.
      " Un Paramètre avec ce nom existe déjà
      ""  --> Lève une Exception
      IF 1 = 2. MESSAGE e302(zhardcode). ENDIF.
      me->__raise_exception(
          iv_msgno = 302
          iv_msgv1 = ls_new_attribute_logical_key-attribute_name
      ).

    ENDIF.

  ENDIF.

  " -----------------------------------------------------------
  " Contrôle nécessité de poursuivre le traitement
  " -----------------------------------------------------------

  IF  ir_new_ranges_value[]      IS INITIAL
  AND it_new_source_code_value[] IS INITIAL
  AND lv_delta                   EQ abap_false
  AND iv_replace_source_code     EQ abap_false
  AND iv_replace_ranges_value    EQ abap_false.
    " Aucune modification à apporter
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Modification des données
  " -----------------------------------------------------------

  " Modification des données générales
  lo_hardcode_attribute->updated        = abap_true.
  IF NOT is_new_attribute_logical_keyx IS INITIAL.
    lo_hardcode_attribute->attribute_name = ls_new_attribute_logical_key-attribute_name.
    lo_hardcode_attribute->attribute_key1 = ls_new_attribute_logical_key-attribute_key1.
    lo_hardcode_attribute->attribute_key2 = ls_new_attribute_logical_key-attribute_key2.
    lo_hardcode_attribute->attribute_key3 = ls_new_attribute_logical_key-attribute_key3.
    lo_hardcode_attribute->attribute_key4 = ls_new_attribute_logical_key-attribute_key4.

  ENDIF.

  " Initialisation traçabilité
  lo_hardcode_attribute->changed_by = sy-uname.
  GET TIME STAMP FIELD lo_hardcode_attribute->changed_at.

  " -----------------------------------------------------------
  " Modification du Code Source
  " -----------------------------------------------------------

  IF  it_new_source_code_value[] IS INITIAL
  AND iv_replace_source_code     EQ abap_true.
    " Code Source à supprimer
    ""  --> Ajout de l'entrée
    INSERT iv_attribute_guid_regroup INTO TABLE me->ms_deleted_data-t_source_code_guid.

    ""  --> Suppression table de travail
    DELETE me->ms_work_data-t_hc_attribute_source_code WHERE attribute_guid_regroup EQ iv_attribute_guid_regroup.

    ""  --> Réinitialisation Indicateur Code Source
    CLEAR : lo_hardcode_attribute->attribute_as_source_code.

  ELSEIF NOT it_new_source_code_value[] IS INITIAL.
    " Code Source à modifier
    ""  --> Modification Code Source table de travail
    READ TABLE me->ms_work_data-t_hc_attribute_source_code
    WITH TABLE KEY attribute_guid_regroup = iv_attribute_guid_regroup
         ASSIGNING FIELD-SYMBOL(<lfs_s_hc_source_code>).
    IF sy-subrc NE 0.
      " Aucune correspondance
      ""  --> Création nouvelle entrée
      ls_hc_source_code-volatile               = abap_true.
      ls_hc_source_code-attribute_guid_regroup = iv_attribute_guid_regroup.
      INSERT ls_hc_source_code INTO TABLE me->ms_work_data-t_hc_attribute_source_code ASSIGNING <lfs_s_hc_source_code>.

    ELSE.
      " Existe
      ""  --> Initialisation témoin de Modification
      <lfs_s_hc_source_code>-updated = abap_true.

    ENDIF.

    ""  --> Modification du Code Source
    <lfs_s_hc_source_code>-t_source_code[] = it_new_source_code_value[].

    ""  --> Réinitialisation Indicateur Code Source
    lo_hardcode_attribute->attribute_as_source_code = xsdbool( NOT it_new_source_code_value[] IS INITIAL ).

  ENDIF.

  " -----------------------------------------------------------
  " Modification des valeurs de Range
  " -----------------------------------------------------------

  IF ir_new_ranges_value[] IS INITIAL.
    " Valeur à Supprimer
    IF iv_replace_ranges_value EQ abap_true.
      " Remplace les valeurs existantes
      ""  --> Suppression des Valeurs sauf elle-même
      me->attribute_del(
        iv_except_himself         = abap_true
        iv_attribute_guid_regroup = iv_attribute_guid_regroup
      ).

      ""  --> Réinitialisation Valeur de Range de la ligne de référence
      CLEAR : lo_hardcode_attribute->attribute_sign,     lo_hardcode_attribute->attribute_low,
              lo_hardcode_attribute->attribute_opti,     lo_hardcode_attribute->attribute_high,
              lo_hardcode_attribute->attribute_as_range.

    ELSE.
      " Pas de Remplacement et table vide
      ""  --> Rien à faire

    ENDIF.

  ELSE.
    " Valeur à Ajouter / Modifier
    IF iv_replace_ranges_value EQ abap_true.
      " Remplace les valeurs existantes
      ""  --> Suppression des Valeurs existantes sauf elle-même
      me->attribute_del(
        iv_except_himself         = abap_true
        iv_attribute_guid_regroup = iv_attribute_guid_regroup
      ).

      ""  --> Réinitialisation Valeur de Range de la ligne de référence
      CLEAR : lo_hardcode_attribute->attribute_sign, lo_hardcode_attribute->attribute_low,
              lo_hardcode_attribute->attribute_opti, lo_hardcode_attribute->attribute_high.

      ""  --> Initialisation Indicateur données Range
      lo_hardcode_attribute->attribute_as_range = xsdbool( NOT ir_new_ranges_value[] IS INITIAL ).

    ELSEIF lv_delta                EQ abap_true
       AND iv_replace_ranges_value EQ abap_false.
      " Pas de remplacement des anciennes mais Modification clefs logiques
      ""  --> Modification des existantes
      READ TABLE me->ms_work_data-t_hardcode_attribute
        WITH KEY attribute_guid_regroup = iv_attribute_guid_regroup
        TRANSPORTING NO FIELDS BINARY SEARCH.
      IF sy-subrc EQ 0.
        " Parcours l'ensemble des données de cette Attribut
        LOOP AT me->ms_work_data-t_hardcode_attribute ASSIGNING <lfs_s_hardcode_attribute>
                                                           FROM sy-tabix.

          IF <lfs_s_hardcode_attribute>-attribute_guid_regroup NE iv_attribute_guid_regroup.
            " On ne traite plus le même Attribut
            ""  --> Arrêt de la boucle
            EXIT.

          ENDIF.

          IF <lfs_s_hardcode_attribute>-attribute_guid EQ lo_hardcode_attribute->attribute_guid.
            " Ligne de référence déjà modifiée
            ""  --> Passe à l'itération suivante
            CONTINUE.

          ENDIF.

          " Modification indicateur de données non sauvegardées
          <lfs_s_hardcode_attribute>-updated        = abap_true.
          <lfs_s_hardcode_attribute>-changed_at     = lo_hardcode_attribute->changed_at.
          <lfs_s_hardcode_attribute>-changed_by     = lo_hardcode_attribute->changed_by.
          <lfs_s_hardcode_attribute>-attribute_name = lo_hardcode_attribute->attribute_name.
          <lfs_s_hardcode_attribute>-attribute_key1 = lo_hardcode_attribute->attribute_key1.
          <lfs_s_hardcode_attribute>-attribute_key2 = lo_hardcode_attribute->attribute_key2.
          <lfs_s_hardcode_attribute>-attribute_key3 = lo_hardcode_attribute->attribute_key3.
          <lfs_s_hardcode_attribute>-attribute_key4 = lo_hardcode_attribute->attribute_key4.

        ENDLOOP.

      ENDIF.

    ENDIF.

    " Ajout des nouvelles valeurs
    LOOP AT ir_new_ranges_value ASSIGNING FIELD-SYMBOL(<lfs_s_ranges_value>).

      CLEAR    : ls_hardcode_attribute.
      UNASSIGN : <lfs_option>, <lfs_sign>, <lfs_high>, <lfs_low>.

      " Initialisation pointeur sur Signe
      ASSIGN COMPONENT 'SIGN' OF STRUCTURE <lfs_s_ranges_value> "#EC NOTEXT
                                        TO <lfs_sign>.
      IF sy-subrc NE 0.
        " Non trouvé
        ""  --> Récupération 1er composant
        ASSIGN COMPONENT 1 OF STRUCTURE <lfs_s_ranges_value>
                                     TO <lfs_sign>.

      ENDIF.

      " Initialisation pointeur sur l'opérateur
      ASSIGN COMPONENT 'OPTION' OF STRUCTURE <lfs_s_ranges_value> "#EC NOTEXT
                                          TO <lfs_option>.
      IF sy-subrc NE 0.
        " Non trouvé
        ""  --> Récupération Zeme composant
        ASSIGN COMPONENT 2 OF STRUCTURE <lfs_s_ranges_value>
                                     TO <lfs_option>.

      ENDIF.

      " Initialisation pointeur sur la valeur basse
      ASSIGN COMPONENT 3 OF STRUCTURE <lfs_s_ranges_value>  "#EC NOTEXT
                                   TO <lfs_low>.
      IF sy-subrc NE 0.
        " Non trouvé
        ""  --> Récupération 3eme composant
        ASSIGN COMPONENT 3 OF STRUCTURE <lfs_s_ranges_value>
                                     TO <lfs_low>.

      ENDIF.

      " Initialisation pointeur sur la valeur Haute
      ASSIGN COMPONENT 'HIGH' OF STRUCTURE <lfs_s_ranges_value> "#EC NOTEXT
                                        TO <lfs_high>.
      IF sy-subrc NE 0.
        " Non trouvé
        ""  --> Récupération 4eme composant
        ASSIGN COMPONENT 4 OF STRUCTURE <lfs_s_ranges_value>
                                     TO <lfs_high>.

      ENDIF.

      " Initialisation valeur Range
      ls_hardcode_attribute-attribute_low  = <lfs_low>.
      ls_hardcode_attribute-attribute_sign = <lfs_sign>.
      ls_hardcode_attribute-attribute_high = <lfs_high>.
      ls_hardcode_attribute-attribute_opti = <lfs_option>.

      "" Note : Aucun contrôle sur les assignations des FS
      "" afin de provoquer un DUMP en cas de mauvaise utilisation par le développeur !

      " Initialisation des données
      ls_hardcode_attribute-mandt                  = lo_hardcode_attribute->mandt.
      ls_hardcode_attribute-volatile               = abap_true.
      ls_hardcode_attribute-changed_at             = lo_hardcode_attribute->changed_at.
      ls_hardcode_attribute-changed_by             = lo_hardcode_attribute->changed_by.
      ls_hardcode_attribute-attribute_name         = lo_hardcode_attribute->attribute_name.
      ls_hardcode_attribute-attribute_key1         = lo_hardcode_attribute->attribute_key1.
      ls_hardcode_attribute-attribute_key2         = lo_hardcode_attribute->attribute_key2.
      ls_hardcode_attribute-attribute_key3         = lo_hardcode_attribute->attribute_key3.
      ls_hardcode_attribute-attribute_key4         = lo_hardcode_attribute->attribute_key4.
      ls_hardcode_attribute-parameter_guid         = lo_hardcode_attribute->parameter_guid.
      ls_hardcode_attribute-attribute_as_range     = abap_true.
      ls_hardcode_attribute-attribute_guid_regroup = lo_hardcode_attribute->attribute_guid_regroup.

      " Initialisation données traçabilité
      ls_hardcode_attribute-created_by = sy-uname.
      GET TIME STAMP FIELD ls_hardcode_attribute-created_at.

      TRY.
          " Création ID Unique
          ls_hardcode_attribute-attribute_guid = cl_system_uuid=>create_uuid_c32_static( ).

        CATCH cx_uuid_error.
          " Erreur lors de la création du GUID
          ""  --> Génération Nombre aléatoire
          ls_hardcode_attribute-attribute_guid = cl_abap_random=>seed( ).

      ENDTRY.

      " Ajout de l'entrée
      INSERT ls_hardcode_attribute INTO TABLE me->ms_work_data-t_hardcode_attribute.

    ENDLOOP.

  ENDIF.

ENDMETHOD.


METHOD constructor.
*&---------------------------------------------------------------------*
*& Copyright © 13/01/2016, Olivier Véhier                              *
*&                                                                     *
*& Permission is hereby granted, free of charge, to any person         *
*& obtaining a copy of this software and associated documentation      *
*& files (the "Software"), to deal in the Software without restriction *
*& including without limitation the rights to use, copy, modify,       *
*& merge, publish, distribute, sublicense, and/or sell copies of the   *
*& Software, and to permit persons to whom the Software is furnished   *
*& to do so, subject to the following conditions:                      *
*&                                                                     *
*& The above copyright notice and this permission notice shall be      *
*& included in all copies or substantial portions of the Software.     *
*&                                                                     *
*& THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,     *
*& EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES     *
*& OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND            *
*& NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS *
*& BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN  *
*& ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN   *
*& CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE    *
*& SOFTWARE.                                                           *
*&                                                                     *
*& Except as contained in this notice, the name of Olivier Véhier      *
*& shall not be used in advertising or otherwise to promote the sale,  *
*& use or other dealings in this Software without prior written        *
*& authorization from Olivier Véhier.                                  *
*&---------------------------------------------------------------------*
*& Méthode         : CONSTRUCTOR                                       *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Constructeur Instance                             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***
  " -----------------------------------------------------------
  " Initialisation Attribut
  " -----------------------------------------------------------

  me->mv_repid = iv_repid.

  " -----------------------------------------------------------
  " Récupération des données
  " -----------------------------------------------------------

  me->hardcode_data_load( ).

ENDMETHOD.


METHOD guid_renew.
*&---------------------------------------------------------------------*
*& Méthode         : GUID_RENEW                                        *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Regénération des GUIDs                            *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_hardcode_version_new   TYPE zcl_hardcode_maintain=>tt_hardcode_version,
    lt_hardcode_parameter_new TYPE zcl_hardcode_maintain=>tt_hardcode_parameter,
    lt_hardcode_attribute_new TYPE zcl_hardcode_maintain=>tt_hardcode_attribute.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_hc_version     TYPE zcl_hardcode_maintain=>ts_hardcode_version,
    ls_hc_parameter   TYPE zcl_hardcode_maintain=>ts_hardcode_parameter,
    ls_hc_attribute   TYPE zcl_hardcode_maintain=>ts_hardcode_attribute,
    ls_hc_source_code TYPE zcl_hardcode_maintain=>ts_attribute_source_code.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Regénération ID Unique
  " -----------------------------------------------------------

  LOOP AT me->ms_work_data-t_hardcode_version ASSIGNING FIELD-SYMBOL(<lfs_s_hc_version>).

    TRY.
        " Génération nouveau Guid de Version
        ls_hc_version-version_guid = cl_system_uuid=>create_uuid_c32_static( ).

      CATCH cx_uuid_error.
        " Erreur génération GUID
        ""  --> Utilisation de l'Ancien
        ls_hc_version-version_guid = <lfs_s_hc_version>-version_guid.

    ENDTRY.

    " Initialisation données
    ls_hc_version = CORRESPONDING #( BASE ( ls_hc_version ) <lfs_s_hc_version>
      EXCEPT version_guid
    ).

    " Ajout de la Version
    INSERT ls_hc_version INTO TABLE lt_hardcode_version_new.

    IF iv_delete_older EQ abap_true.
      " Ajout GUID Version pour suppression
      APPEND <lfs_s_hc_version>-version_guid TO me->ms_deleted_data-t_version_guid.

    ENDIF.
*-------------------------------------------------------------------------------------

    " Récupération position première itération des Paramètres de la Version
    READ TABLE me->ms_work_data-t_hardcode_parameter WITH KEY second_key
                                                   COMPONENTS version_guid = <lfs_s_hc_version>-version_guid
                                                 TRANSPORTING NO FIELDS.
    IF sy-subrc NE 0.
      " Aucune correspondance
      ""  --> Passe à la Version suivante
      CONTINUE.

    ENDIF.

    " Parcours chaque paramètres de la Version
    LOOP AT me->ms_work_data-t_hardcode_parameter ASSIGNING FIELD-SYMBOL(<lfs_s_hc_parameter>)
                                                       FROM sy-tabix.

      IF <lfs_s_hc_parameter>-version_guid NE <lfs_s_hc_version>-version_guid.
        " Changement de la Version
        ""  --> Arrêt de la boucle
        EXIT.

      ENDIF.

      " Initialisation GUID Version
      ls_hc_parameter-version_guid = ls_hc_version-version_guid.

      TRY.
          " Génération nouveau Guid de Paramètre
          ls_hc_parameter-parameter_guid = cl_system_uuid=>create_uuid_c32_static( ).

        CATCH cx_uuid_error.
          " Erreur génération GUID
          ""  --> Utilisation de l'Ancien
          ls_hc_parameter-parameter_guid = <lfs_s_hc_parameter>-parameter_guid.

      ENDTRY.

      " Initialisation données
      ls_hc_parameter = CORRESPONDING #( BASE ( ls_hc_parameter ) <lfs_s_hc_parameter>
        EXCEPT version_guid parameter_guid
      ).

      " Ajout de la Version
      INSERT ls_hc_parameter INTO TABLE lt_hardcode_parameter_new.

      IF iv_delete_older EQ abap_true.
        " Ajout GUID Paramètre pour suppression
        APPEND <lfs_s_hc_parameter>-parameter_guid TO me->ms_deleted_data-t_parameter_guid.

      ENDIF.
*-------------------------------------------------------------------------------------

      " Récupération position première itération des Paramètres de la Version
      READ TABLE me->ms_work_data-t_hardcode_attribute WITH KEY second_key
                                                     COMPONENTS parameter_guid = <lfs_s_hc_parameter>-parameter_guid
                                                   TRANSPORTING NO FIELDS.
      IF sy-subrc NE 0.
        " Aucune correspondance
        ""  --> Passe au Paramètre suivante
        CONTINUE.

      ENDIF.

      " Parcours chaque Attributs du Paramètre
      LOOP AT me->ms_work_data-t_hardcode_attribute ASSIGNING FIELD-SYMBOL(<lfs_s_hc_attribute>)
                                                         FROM sy-tabix.

        IF <lfs_s_hc_attribute>-parameter_guid NE <lfs_s_hc_parameter>-parameter_guid.
          " Changement du Paramètre
          ""  --> Arrêt de la boucle
          EXIT.

        ENDIF.

        " Initialisation nouveau GUID
        ls_hc_attribute-parameter_guid = ls_hc_parameter-parameter_guid.

        IF <lfs_s_hc_attribute>-attribute_guid_regroup EQ <lfs_s_hc_attribute>-attribute_guid.
          " Entrée de l'Attribut principale
          TRY.
              ""  --> Génération nouveau Guid de Regroupement
              ls_hc_attribute-attribute_guid_regroup = cl_system_uuid=>create_uuid_c32_static( ).

            CATCH cx_uuid_error.
              " Erreur génération GUID
              ""  --> Utilisation de l'Ancien
              ls_hc_attribute-attribute_guid_regroup = <lfs_s_hc_attribute>-attribute_guid_regroup.

          ENDTRY.

          " Initialisation GUID Attribut
          ls_hc_attribute-attribute_guid = ls_hc_attribute-attribute_guid_regroup.

          "" --> Récupération données Code Source associée à l'attribut
          READ TABLE me->ms_work_data-t_hc_attribute_source_code
          WITH TABLE KEY attribute_guid_regroup = <lfs_s_hc_attribute>-attribute_guid_regroup
               ASSIGNING FIELD-SYMBOL(<lfs_s_source_code>).
          IF  sy-subrc EQ 0
          AND <lfs_s_source_code>-attribute_guid_regroup NE ls_hc_attribute-attribute_guid_regroup.
            " Correspondance et modification du GUID de Regroupement
            ""  --> Modification du GUID de regroupement de l'Attribut
            ls_hc_source_code = <lfs_s_source_code>.
            ls_hc_source_code-attribute_guid_regroup = ls_hc_attribute-attribute_guid_regroup.
            INSERT ls_hc_source_code INTO TABLE me->ms_work_data-t_hc_attribute_source_code.

            IF iv_delete_older EQ abap_true.
              ""  --> Ajout GUID Attribut Regroupement pour suppression
              APPEND <lfs_s_source_code>-attribute_guid_regroup TO me->ms_deleted_data-t_source_code_guid.

            ENDIF.

            ""  --> Suppression de l'ancienne entrée
            DELETE TABLE me->ms_work_data-t_hc_attribute_source_code FROM <lfs_s_source_code>.
            UNASSIGN : <lfs_s_source_code>.

          ENDIF.

        ELSE.
          " Entrée secondaire de l'Attribut
          TRY.
              ""  --> Génération nouveau Guid
              ls_hc_attribute-attribute_guid = cl_system_uuid=>create_uuid_c32_static( ).

            CATCH cx_uuid_error.
              " Erreur génération GUID
              ""  --> Utilisation de l'Ancien
              ls_hc_attribute-attribute_guid = <lfs_s_hc_attribute>-attribute_guid.

          ENDTRY.

        ENDIF.

        ""  --> Ajout nouvelle entrée
        ls_hc_attribute = CORRESPONDING #( BASE ( ls_hc_attribute ) <lfs_s_hc_attribute>
          EXCEPT parameter_guid attribute_guid_regroup attribute_guid
        ).
        INSERT ls_hc_attribute INTO TABLE lt_hardcode_attribute_new.

        IF iv_delete_older EQ abap_true.
          ""  --> Ajout GUID Attribut Regroupement pour suppression
          APPEND VALUE #(
            attribute_guid         = <lfs_s_hc_attribute>-attribute_guid
            attribute_guid_regroup = <lfs_s_hc_attribute>-attribute_guid_regroup
          ) TO me->ms_deleted_data-t_attribute_guid.

        ENDIF.

      ENDLOOP.  "Fin Boucle Attribut

    ENDLOOP.    "Fin Boucle Paramètre

  ENDLOOP.      "Fin Boucle Version

  " -----------------------------------------------------------
  " Modification dans les tables de travail
  " -----------------------------------------------------------

  " Modification des tables
  me->ms_work_data-t_hardcode_version[]   = lt_hardcode_version_new[].
  me->ms_work_data-t_hardcode_parameter[] = lt_hardcode_parameter_new[].
  me->ms_work_data-t_hardcode_attribute[] = lt_hardcode_attribute_new[].

  " -----------------------------------------------------------
  " Initialisation témoin de modification
  " -----------------------------------------------------------

  CLEAR : ls_hc_source_code, ls_hc_attribute, ls_hc_parameter, ls_hc_version.

  " Initialisation témoin de MàJ
  ls_hc_version-updated     = ls_hc_version-volatile     = abap_true.
  ls_hc_parameter-updated   = ls_hc_parameter-volatile   = abap_true.
  ls_hc_attribute-updated   = ls_hc_attribute-volatile   = abap_true.
  ls_hc_source_code-updated = ls_hc_source_code-volatile = abap_true.

  " Modification dans les tables
  MODIFY me->ms_work_data-t_hardcode_version         FROM ls_hc_version     TRANSPORTING updated WHERE mandt   = sy-mandt.
  MODIFY me->ms_work_data-t_hardcode_parameter       FROM ls_hc_parameter   TRANSPORTING updated WHERE mandt   = sy-mandt.
  MODIFY me->ms_work_data-t_hardcode_attribute       FROM ls_hc_attribute   TRANSPORTING updated WHERE mandt   = sy-mandt.
  MODIFY me->ms_work_data-t_hc_attribute_source_code FROM ls_hc_source_code TRANSPORTING updated WHERE updated = abap_false.

ENDMETHOD.


METHOD hardcode_copy.
*&---------------------------------------------------------------------*
*& Méthode         : HARDCODE_COPY                                     *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Programme - Copie                                 *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***
  TYPES :
    BEGIN OF lts_attribute_guid_regroup,
      source TYPE ztec_t_hc_attr-attribute_guid_regroup,
      target TYPE ztec_t_hc_attr-attribute_guid_regroup,
    END OF   lts_attribute_guid_regroup.

  TYPES : ltt_attribute_guid_regroup TYPE HASHED TABLE OF lts_attribute_guid_regroup
                                            WITH UNIQUE KEY primary_key COMPONENTS source.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_attribute_guid_regroup TYPE ltt_attribute_guid_regroup.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_hardcode_version       TYPE zcl_hardcode_maintain=>ts_hardcode_version,
    ls_hardcode_parameter     TYPE zcl_hardcode_maintain=>ts_hardcode_parameter,
    ls_hardcode_attribute     TYPE zcl_hardcode_maintain=>ts_hardcode_attribute,
    ls_attribute_guid_regroup TYPE lts_attribute_guid_regroup.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_repid_new TYPE ztec_t_hc_vers-repid.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Détermination Nom du Programme
  " -----------------------------------------------------------

  IF NOT iv_repid_new IS INITIAL.
    " ID spécifié
    ""  --> Utilisation de cet ID
    lv_repid_new = iv_repid_new.

  ELSE.
    " Pas d'ID spécifié
    ""  --> Reprise du Nom de l'ID à copier
    lv_repid_new = |{ me->mv_repid }_COPY|.                 "#EC NOTEXT

  ENDIF.

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  ""  --> Contrôle existence Programme à copier
  SELECT SINGLE mandt FROM ztec_t_hc_vers
                      INTO ls_hardcode_version-mandt
                     WHERE repid EQ me->mv_repid.
  IF sy-subrc NE 0.
    "  Le Programme n'existe pas
    ""  --> Lève une erreur
    IF 1 = 2. MESSAGE e001(zhardcode). ENDIF.
    me->__raise_exception(
      iv_msgno = 001
      iv_msgv1 = me->mv_repid
    ).

  ENDIF.

  ""  --> Contrôle inexistence Programme
  SELECT SINGLE mandt FROM ztec_t_hc_vers
                      INTO ls_hardcode_version-mandt
                     WHERE repid EQ lv_repid_new.
  IF sy-subrc EQ 0.
    "  Le Programme existe déjà
    ""  --> Lève une erreur
    IF 1 = 2. MESSAGE e005(zhardcode). ENDIF.
    me->__raise_exception(
      iv_msgno = 005
      iv_msgv1 = lv_repid_new
    ).

  ENDIF.

  " -----------------------------------------------------------
  " Copie de l'ensemble des données du Programme
  " -----------------------------------------------------------

  ""  --> Création instance MàJ
  CREATE OBJECT ro_hardcode_maintain
    EXPORTING
      iv_repid = lv_repid_new.

  ""  --> Modification des GUIDs
  LOOP AT me->ms_work_data-t_hardcode_version ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode_version>).

    CLEAR : ls_hardcode_version.

    IF <lfs_s_hardcode_version>-volatile EQ abap_true.
      " Version non persistée en DB
      ""  --> Ne pas tenir compte
      CONTINUE.

    ENDIF.

    ""  --> Initialisation données Version
    ls_hardcode_version = <lfs_s_hardcode_version>.

    ""  --> Modification données Version
    ls_hardcode_version-repid      = lv_repid_new.
    ls_hardcode_version-volatile   = abap_true.
    ls_hardcode_version-created_by = sy-uname.
    CLEAR : ls_hardcode_version-changed_at, ls_hardcode_version-changed_by.
    GET TIME STAMP FIELD ls_hardcode_version-created_at.

    TRY.
        " Création ID Unique
        ls_hardcode_version-version_guid = cl_system_uuid=>create_uuid_c32_static( ).

      CATCH cx_uuid_error.
        " Erreur lors de la création du GUID
        ""  --> Génération Nombre aléatoire
        ls_hardcode_version-version_guid = cl_abap_random=>seed( ).

    ENDTRY.

    ""  --> Ajout de la Version
    INSERT ls_hardcode_version INTO TABLE ro_hardcode_maintain->ms_work_data-t_hardcode_version.

    " Récupération position première occurence des Paramètres de la Version
    READ TABLE me->ms_work_data-t_hardcode_parameter WITH KEY second_key
                                                   COMPONENTS version_guid = <lfs_s_hardcode_version>-version_guid
                                                 TRANSPORTING NO FIELDS.
    IF sy-subrc EQ 0.
      " Au moins une occurence trouvée
      ""  --> Parcours l'ensemble des Paramètres
      LOOP AT me->ms_work_data-t_hardcode_parameter ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode_parameter>)
                                                    USING KEY second_key
                                                         FROM sy-tabix.

        CLEAR : ls_hardcode_parameter.

        IF <lfs_s_hardcode_parameter>-version_guid NE <lfs_s_hardcode_version>-version_guid.
          " On ne traite plus la même Version
          ""  --> Arrêt de la boucle
          EXIT.

        ENDIF.

        IF <lfs_s_hardcode_parameter>-volatile EQ abap_true.
          " Paramètre non persisté en DB
          ""  --> Ne pas tenir compte
          CONTINUE.

        ENDIF.

        ""  --> Initialisation données Paramètre
        ls_hardcode_parameter = <lfs_s_hardcode_parameter>.

        ""  --> Modification données Paramètre
        ls_hardcode_parameter-volatile     = abap_true.
        ls_hardcode_parameter-created_by   = sy-uname.
        ls_hardcode_parameter-version_guid = ls_hardcode_version-version_guid.
        CLEAR : ls_hardcode_parameter-changed_at, ls_hardcode_parameter-changed_by.
        GET TIME STAMP FIELD ls_hardcode_parameter-created_at.

        TRY.
            " Création ID Unique
            ls_hardcode_parameter-parameter_guid = cl_system_uuid=>create_uuid_c32_static( ).

          CATCH cx_uuid_error.
            " Erreur lors de la création du GUID
            ""  --> Génération Nombre aléatoire
            ls_hardcode_parameter-parameter_guid = cl_abap_random=>seed( ).

        ENDTRY.

        ""  --> Ajout du Paramètre
        INSERT ls_hardcode_parameter INTO TABLE ro_hardcode_maintain->ms_work_data-t_hardcode_parameter.

        " Récupération position première occurence d'Attribut de la Version
        READ TABLE me->ms_work_data-t_hardcode_attribute WITH KEY second_key
                                                       COMPONENTS parameter_guid = <lfs_s_hardcode_parameter>-parameter_guid
                                                     TRANSPORTING NO FIELDS.
        IF sy-subrc EQ 0.
          " Au moins une occurence trouvée
          ""  --> Parcours l'ensemble des Attributs
          LOOP AT me->ms_work_data-t_hardcode_attribute ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode_attribute>)
                                                        USING KEY second_key
                                                             FROM sy-tabix.

            CLEAR : ls_hardcode_attribute.

            IF <lfs_s_hardcode_attribute>-parameter_guid NE <lfs_s_hardcode_parameter>-parameter_guid.
              " On ne traite plus le même Paramètre
              ""  --> Arrêt de la boucle
              EXIT.

            ENDIF.

            IF <lfs_s_hardcode_attribute>-volatile EQ abap_true.
              " Attribut non persisté en DB
              ""  --> Ne pas tenir compte
              CONTINUE.

            ENDIF.

            ""  --> Récupération du GUID de Référence
            READ TABLE lt_attribute_guid_regroup WITH TABLE KEY source = <lfs_s_hardcode_attribute>-attribute_guid_regroup
                                                      ASSIGNING FIELD-SYMBOL(<lfs_s_attribute_guid_regroup>).
            IF sy-subrc NE 0.
              " Aucune occurence
              TRY.
                  ""  --> Création ID Unique
                  ls_attribute_guid_regroup-target = cl_system_uuid=>create_uuid_c32_static( ).

                CATCH cx_uuid_error.
                  " Erreur lors de la création du GUID
                  ""  --> Génération Nombre aléatoire
                  ls_attribute_guid_regroup-target = cl_abap_random=>seed( ).

              ENDTRY.

              ""  --> Ajout de l'entrée
              ls_attribute_guid_regroup-source = <lfs_s_hardcode_attribute>-attribute_guid_regroup.
              INSERT ls_attribute_guid_regroup INTO TABLE lt_attribute_guid_regroup ASSIGNING <lfs_s_attribute_guid_regroup>.

            ENDIF.

            ""  --> Initialisation données Attributs
            ls_hardcode_attribute = <lfs_s_hardcode_attribute>.

            ""  --> Modification données Attributs
            ls_hardcode_attribute-volatile               = abap_true.
            ls_hardcode_attribute-created_by             = sy-uname.
            ls_hardcode_attribute-parameter_guid         = ls_hardcode_parameter-parameter_guid.
            ls_hardcode_attribute-attribute_guid_regroup = <lfs_s_attribute_guid_regroup>-target.
            CLEAR : ls_hardcode_attribute-changed_at, ls_hardcode_attribute-changed_by.
            GET TIME STAMP FIELD ls_hardcode_attribute-created_at.

            IF <lfs_s_hardcode_attribute>-attribute_guid_regroup EQ <lfs_s_hardcode_attribute>-attribute_guid.
              " Attribut de référence
              ""  --> Initialisation à la même valeur
              ls_hardcode_attribute-attribute_guid = ls_hardcode_attribute-attribute_guid_regroup.

            ELSE.
              " Ligne d'Attribut
              TRY.
                  ""  --> Création ID Unique
                  ls_hardcode_attribute-attribute_guid = cl_system_uuid=>create_uuid_c32_static( ).

                CATCH cx_uuid_error.
                  " Erreur lors de la création du GUID
                  ""  --> Génération Nombre aléatoire
                  ls_hardcode_attribute-attribute_guid = cl_abap_random=>seed( ).

              ENDTRY.

            ENDIF.

            ""  --> Ajout de l'Attribut
            INSERT ls_hardcode_attribute INTO TABLE ro_hardcode_maintain->ms_work_data-t_hardcode_attribute.

          ENDLOOP.    "Fin parcours Attributs

        ENDIF.        "Fin de test présencce Attributs

      ENDLOOP.        "Fin parcours Paramètres

    ENDIF.            "Fin de test présence Paramètres

  ENDLOOP.

ENDMETHOD.


METHOD hardcode_data_get.
*&---------------------------------------------------------------------*
*& Méthode         : HARDCODE_DATA_GET                                 *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Données - Récupération                            *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_join TYPE zvtec_t_hc.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***


  IF et_join    IS SUPPLIED
  OR et_version IS SUPPLIED.
    " -----------------------------------------------------------
    " Initialisation des Versions
    " -----------------------------------------------------------
    et_version[] = CORRESPONDING #( me->ms_work_data-t_hardcode_version[] ).

  ENDIF.

  IF et_join      IS SUPPLIED
  OR et_parameter IS SUPPLIED.
    " -----------------------------------------------------------
    " Initialisation des Paramètres
    " -----------------------------------------------------------
    et_parameter[] = CORRESPONDING #( me->ms_work_data-t_hardcode_parameter[] ).

  ENDIF.

  IF et_join        IS SUPPLIED
  OR et_attribute   IS SUPPLIED
  OR et_source_code IS SUPPLIED.
    " -----------------------------------------------------------
    " Initialisation des Attributs
    " -----------------------------------------------------------

    " Initialisation des données
    et_attribute[] = CORRESPONDING #( me->ms_work_data-t_hardcode_attribute[] ).

  ENDIF.

  IF et_source_code IS SUPPLIED.
    " -----------------------------------------------------------
    " Initialisation des Codes Sources
    " -----------------------------------------------------------
    " Il n'est pas possible de faire un FAE sur une table cluster
    " -----------------------------------------------------------

    " Récupération des Codes Sources (brut)
    LOOP AT me->ms_work_data-t_hc_attribute_source_code
      ASSIGNING FIELD-SYMBOL(<lfs_s_source_code>).

      INSERT VALUE #(
        attribute_guid_regroup = <lfs_s_source_code>-attribute_guid_regroup
        source_code            = <lfs_s_source_code>-t_source_code
      ) INTO TABLE et_source_code.

    ENDLOOP.

  ENDIF.

  IF et_join IS SUPPLIED.
    " -----------------------------------------------------------
    " Initialisation aggrégations
    " -----------------------------------------------------------

    SORT et_parameter BY version_guid.
    SORT et_attribute BY parameter_guid.

    LOOP AT et_version ASSIGNING FIELD-SYMBOL(<lfs_s_version>).

      CLEAR : ls_join.

      " Récupération position première occurence des Paramètres de la Version
      READ TABLE et_parameter WITH KEY version_guid = <lfs_s_version>-version_guid
                          TRANSPORTING NO FIELDS BINARY SEARCH.
      IF sy-subrc EQ 0.
        " Au moins un Paramètre trouvé
        ""  --> Parcours l'ensemble des Paramètres associés à la Version
        LOOP AT et_parameter ASSIGNING FIELD-SYMBOL(<lfs_s_parameter>)
                                  FROM sy-tabix.

          CLEAR : ls_join.

          IF <lfs_s_parameter>-version_guid NE <lfs_s_version>-version_guid.
            " On ne traite plus la même Version
            ""  --> Arrêt de la boucle
            EXIT.

          ENDIF.

          " Récupération position première occurence des Attributs du Paramètre
          READ TABLE et_attribute WITH KEY parameter_guid = <lfs_s_parameter>-parameter_guid
                              TRANSPORTING NO FIELDS BINARY SEARCH.
          IF sy-subrc EQ 0.
            " Au moins un Attribut trouvé
            ""  --> Parcours l'ensemble des Attribut associés au Paramètre
            LOOP AT et_attribute ASSIGNING FIELD-SYMBOL(<lfs_s_attribute>)
                                      FROM sy-tabix.

              CLEAR : ls_join.

              IF <lfs_s_attribute>-parameter_guid NE <lfs_s_parameter>-parameter_guid.
                " On ne traite plus le même Attribut
                EXIT.

              ENDIF.

              " Initialisation données Version
              MOVE-CORRESPONDING <lfs_s_version> TO ls_join.

              " Initialisation des données de Paramètres
              MOVE-CORRESPONDING <lfs_s_parameter> TO ls_join.

              " Initialisation des données d'Attribut
              MOVE-CORRESPONDING <lfs_s_attribute> TO ls_join.

              " Ajout de l'entrée
              APPEND ls_join TO et_join.

            ENDLOOP.

          ELSE.
            " Aucun Attribut
            ""  --> Initialisation données Version
            MOVE-CORRESPONDING <lfs_s_version> TO ls_join.

            ""  --> Initialisation des données de Paramètres
            MOVE-CORRESPONDING <lfs_s_parameter> TO ls_join.

            "" --> Ajout de l'entrée
            APPEND ls_join TO et_join.

          ENDIF.            " Fin de test présence d'Attribut

        ENDLOOP.            "Fin parcours des Paramètres

      ELSE.
        " Aucun Paramètre
        ""  --> Initialisation données Version
        MOVE-CORRESPONDING <lfs_s_version> TO ls_join.

        "" --> Ajout de l'entrée
        APPEND ls_join TO et_join.

      ENDIF.                "Fin de test présence de Paramètres

    ENDLOOP.                "Fin parcours des Versions

  ENDIF.

ENDMETHOD.


METHOD HARDCODE_DATA_LOAD.
*&---------------------------------------------------------------------*
*& Méthode         : HARDCODE_DATA_LOAD                                *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Données - Chargement depuis DB                    *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Chargement des Versions
  " -----------------------------------------------------------

  SELECT * FROM ztec_t_hc_vers
     INTO TABLE me->ms_work_data-t_hardcode_version
          WHERE repid EQ me->mv_repid.
  IF sy-subrc EQ 0.
    " -----------------------------------------------------------
    " Chargement des Paramètres
    " -----------------------------------------------------------

    SELECT * FROM ztec_t_hc_param
       INTO TABLE me->ms_work_data-t_hardcode_parameter
          FOR ALL ENTRIES IN me->ms_work_data-t_hardcode_version
            WHERE version_guid EQ me->ms_work_data-t_hardcode_version-version_guid.

  ENDIF.

  IF NOT me->ms_work_data-t_hardcode_parameter[] IS INITIAL.
    " -----------------------------------------------------------
    " Chargement des Attributs
    " -----------------------------------------------------------

    SELECT * FROM ztec_t_hc_attr
       INTO TABLE me->ms_work_data-t_hardcode_attribute
          FOR ALL ENTRIES IN me->ms_work_data-t_hardcode_parameter
                       WHERE parameter_guid EQ me->ms_work_data-t_hardcode_parameter-parameter_guid.

  ENDIF.

  IF NOT me->ms_work_data-t_hardcode_attribute[] IS INITIAL.
    " -----------------------------------------------------------
    " Chargement des Textes des Attributs
    " -----------------------------------------------------------

    LOOP AT me->ms_work_data-t_hardcode_attribute
      ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode_attribute>)
       GROUP BY <lfs_s_hardcode_attribute>-attribute_guid_regroup.

      IF <lfs_s_hardcode_attribute>-attribute_as_source_code EQ abap_true.
        INSERT VALUE #(
          attribute_guid_regroup = <lfs_s_hardcode_attribute>-attribute_guid_regroup
          t_source_code          = zcl_hardcode_cluster=>source_code_get( <lfs_s_hardcode_attribute>-attribute_guid_regroup )
        ) INTO TABLE me->ms_work_data-t_hc_attribute_source_code.

      ENDIF.

    ENDLOOP.

  ENDIF.

ENDMETHOD.


METHOD integrity_check.
*&---------------------------------------------------------------------*
*& Méthode         : INTEGRITY_CHECK                                   *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Contrôle d'Intégrité                              *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Suppression des Paramètres isolés
  " -----------------------------------------------------------

  " Récupération de tous les Paramètres dont l'Identifiant de Version n'existe pas
  SELECT * FROM ztec_t_hc_param
          WHERE version_guid NOT IN ( SELECT version_guid FROM ztec_t_hc_vers )
     INTO TABLE @DATA(lt_ztec_t_hc_param).

  IF NOT lt_ztec_t_hc_param[] IS INITIAL.
    " Suppression des Paramètres
    DELETE ztec_t_hc_param FROM TABLE lt_ztec_t_hc_param.

  ENDIF.

  " -----------------------------------------------------------
  " Suppression des Attributs isolés
  " -----------------------------------------------------------

  " Récupération de tous les Attributs dont l'Identifiant de Paramètre n'existe pas
  SELECT * FROM ztec_t_hc_attr
          WHERE parameter_guid NOT IN ( SELECT parameter_guid FROM ztec_t_hc_param )
     INTO TABLE @DATA(lt_ztec_t_hc_attr).

  IF NOT lt_ztec_t_hc_attr[] IS INITIAL.
    " Suppression des Attributs
    DELETE ztec_t_hc_attr FROM TABLE lt_ztec_t_hc_attr.

  ENDIF.

ENDMETHOD.


METHOD is_changed.
*&---------------------------------------------------------------------*
*& Méthode         : IS_CHANGED                                        *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Contrôle Modification sur HC                      *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Recherche élèments supprimées
  " -----------------------------------------------------------

  IF NOT me->ms_deleted_data IS INITIAL.
    " Données persistentes supprimées
    ""  --> Retourne indicateur données modifiées
    rv_changed = abap_true.
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Recherche attributs modifiées
  " -----------------------------------------------------------

  TRY.
      " Présence données Attributs modifiée ?
      rv_changed = me->ms_work_data-t_hardcode_attribute[ volatile = abap_true ]-volatile.
      RETURN.

    CATCH cx_sy_itab_line_not_found.

  ENDTRY.

  TRY.
      " Présence données Attributs modifiée ?
      rv_changed = me->ms_work_data-t_hardcode_attribute[ updated = abap_true ]-updated.
      RETURN.

    CATCH cx_sy_itab_line_not_found.

  ENDTRY.

  " -----------------------------------------------------------
  " Recherche Paramètres modifiées
  " -----------------------------------------------------------

  TRY.
      " Présence données Paramètres modifiée ?
      rv_changed = me->ms_work_data-t_hardcode_parameter[ volatile = abap_true ]-volatile.
      RETURN.

    CATCH cx_sy_itab_line_not_found.

  ENDTRY.

  TRY.
      " Présence données Paramètres modifiée ?
      rv_changed = me->ms_work_data-t_hardcode_parameter[ updated = abap_true ]-updated.
      RETURN.

    CATCH cx_sy_itab_line_not_found.

  ENDTRY.

  " -----------------------------------------------------------
  " Recherche Version modifiées
  " -----------------------------------------------------------

  TRY.
      " Présence données Version modifiée ?
      rv_changed = me->ms_work_data-t_hardcode_version[ volatile = abap_true ]-volatile.
      RETURN.

    CATCH cx_sy_itab_line_not_found.

  ENDTRY.

  TRY.
      " Présence données Version modifiée ?
      rv_changed = me->ms_work_data-t_hardcode_version[ updated = abap_true ]-updated.
      RETURN.

    CATCH cx_sy_itab_line_not_found.

  ENDTRY.

ENDMETHOD.


METHOD parameter_add.
*&---------------------------------------------------------------------*
*& Méthode         : PARAMETER_ADD                                     *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Paramètre - Création                              *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_hardcode_parameter TYPE ts_hardcode_parameter.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  CLEAR : es_parameter_data.

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF me->parameter_exist(
      iv_version_guid   = iv_version_guid
      iv_parameter_name = iv_parameter_name
  ) EQ abap_true.
    " L'entrée existe déjà
    ""  --> Lève une Exception
    IF 1 = 2. MESSAGE e202(zhardcode). ENDIF.
    me->__raise_exception(
        iv_msgno = 202
        iv_msgv1 = iv_parameter_name
    ).

  ENDIF.

  " -----------------------------------------------------------
  " Ajout du nouveau Paramètre
  " -----------------------------------------------------------

  " Initialisation des données
  ls_hardcode_parameter-mandt          = sy-mandt.
  ls_hardcode_parameter-volatile       = abap_true.
  ls_hardcode_parameter-version_guid   = iv_version_guid.
  ls_hardcode_parameter-parameter_name = iv_parameter_name.

  " Initialisation donnés tracabilité
  ls_hardcode_parameter-created_by      = sy-uname.
  GET TIME STAMP FIELD ls_hardcode_parameter-created_at.

  TRY.
      " Création ID Unique
      ls_hardcode_parameter-parameter_guid = cl_system_uuid=>create_uuid_c32_static( ).

    CATCH cx_uuid_error.
      " Erreur lors de la création du GUID
      ""  --> Génération Nombre aléatoire
      ls_hardcode_parameter-version_guid = cl_abap_random=>seed( ).

  ENDTRY.

  " Ajout dans la table interne
  rv_parameter_guid = ls_hardcode_parameter-parameter_guid.
  INSERT ls_hardcode_parameter INTO TABLE me->ms_work_data-t_hardcode_parameter.

  IF es_parameter_data IS SUPPLIED.
    " -----------------------------------------------------------
    " Initialisation données
    " -----------------------------------------------------------

    " Retourne les données
    MOVE-CORRESPONDING ls_hardcode_parameter TO es_parameter_data.

  ENDIF.

ENDMETHOD.


METHOD parameter_copy.
*&---------------------------------------------------------------------*
*& Méthode         : PARAMETER_COPY                                    *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Paramètre - Copie                                 *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_attribute_data             TYPE ztec_t_hc_attr_tt,
    lt_attribute_range_data       TYPE zcl_hardcode_maintain=>tt_attribute_range_data,
    lt_attribute_source_code_data TYPE zcl_hardcode_maintain=>tt_attribute_source_code_data.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_parameter_data     TYPE ztec_t_hc_param,
    ls_hardcode_parameter TYPE ts_hardcode_parameter.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        lo_cx_hardcode_maintain TYPE REF TO zcx_hardcode_maintain.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
        lv_parameter_name_new TYPE ztec_t_hc_param-parameter_name.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  CLEAR   : es_parameter_data.
  REFRESH : et_attribute_source_code_data, et_attribute_range_data, et_parameter_data.

  IF NOT iv_parameter_guid_copy IS INITIAL.
    " -----------------------------------------------------------
    " Copie d'un Paramètre
    " -----------------------------------------------------------

    " Récupération Entrée correspondante
    READ TABLE me->ms_work_data-t_hardcode_parameter WITH TABLE KEY parameter_guid = iv_parameter_guid_copy
                                                          ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode_parameter>).
    IF sy-subrc NE 0.
      " Aucune correspondance
      ""  --> Lève une Exception
      IF 1 = 2. MESSAGE e201(zhardcode). ENDIF.
      me->__raise_exception(
          iv_msgno = 201
          iv_msgv1 = iv_parameter_guid_copy
      ).

    ENDIF.

    " Copie du Paramètre
    IF NOT iv_parameter_name_new IS INITIAL.
      " Utilisation Nom transmis
      lv_parameter_name_new = iv_parameter_name_new.

    ELSE.
      TRY.
          " Copie du Nom
          lv_parameter_name_new = |{ <lfs_s_hardcode_parameter>-parameter_name }_COPY|. "#EC NOTEXT

        CATCH cx_sy_itab_line_not_found.
          " Entrée non trouvée
          ""  --> Initialisation Nom alétoire
          lv_parameter_name_new = |{ cl_abap_random=>seed( ) }_COPY|. "#EC NOTEXT

      ENDTRY.

    ENDIF.

    ""  --> Contrôle la non existence du Nouveau Paramètre
    IF me->parameter_exist(
        iv_version_guid   = <lfs_s_hardcode_parameter>-version_guid
        iv_parameter_name = lv_parameter_name_new
    ) EQ abap_true.
      " L'entrée existe déjà
      ""  --> Lève une Exception
      me->__raise_exception(
          iv_msgno = 202
          iv_msgv1 = lv_parameter_name_new
      ).

    ENDIF.

    TRY.
        " -----------------------------------------------------------
        " Création du Paramètre
        " -----------------------------------------------------------

        " Création d'un nouveau Paramètre
        rv_parameter_guid = me->parameter_add(
          EXPORTING
            iv_version_guid   = <lfs_s_hardcode_parameter>-version_guid
            iv_parameter_name = lv_parameter_name_new
          IMPORTING
            es_parameter_data = es_parameter_data
        ).

      CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
        " Erreur lors de la création du Paramètre
        ""  --> Lève l'exception
        me->__raise_exception( io_exception = lo_cx_hardcode_maintain ).

    ENDTRY.

    IF iv_copy_children EQ abap_true.
      " -----------------------------------------------------------
      " Copie des Enfants
      " -----------------------------------------------------------

      TRY.
          IF et_attribute_data             IS SUPPLIED
          OR et_attribute_range_data       IS SUPPLIED
          OR et_attribute_source_code_data IS SUPPLIED.
            " Copie des Attributs
            me->attribute_copy(
              EXPORTING
                iv_parameter_guid_copy        = iv_parameter_guid_copy
                iv_parameter_guid_new         = es_parameter_data-parameter_guid
              IMPORTING
                et_attribute_data             = et_attribute_data
                et_attribute_range_data       = et_attribute_range_data
                et_attribute_source_code_data = et_attribute_source_code_data
            ).

          ELSE.
            " Copie des Attributs
            me->attribute_copy(
                iv_parameter_guid_copy = iv_parameter_guid_copy
                iv_parameter_guid_new  = es_parameter_data-parameter_guid
            ).

          ENDIF.

        CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
          " Erreur lors de la copie des Attributs
          ""  --> Tant pis ...

      ENDTRY.

    ENDIF.

  ELSEIF NOT iv_version_guid_copy IS INITIAL
     AND NOT iv_version_guid_new  IS INITIAL.
    " -----------------------------------------------------------
    " Copie de l'ensemble des Paramètres de la Version
    " -----------------------------------------------------------

    " Copie des Paramètres de la Version
    ""  --> Contrôle l'existence de la Version à copier
    IF me->version_exist( iv_version_guid_copy ) NE abap_true.
      " La Version n'existe pas
      ""  --> Lève une Exception
      IF 1 = 2. MESSAGE e102(zhardcode). ENDIF.
      me->__raise_exception(
          iv_msgno = 102
          iv_msgv1 = iv_version_guid_copy
          iv_msgv2 = me->mv_repid
      ).

    ENDIF.

    ""  --> Contrôle l'existence de la Version cible
    IF me->version_exist( iv_version_guid_new ) NE abap_true.
      " La Version n'existe pas
      ""  --> Lève une Exception
      IF 1 = 2. MESSAGE e102(zhardcode). ENDIF.
      me->__raise_exception(
          iv_msgno = 102
          iv_msgv1 = iv_version_guid_new
          iv_msgv2 = me->mv_repid
      ).

    ENDIF.

    " -----------------------------------------------------------
    " Copies des Paramètres
    " -----------------------------------------------------------

    " Récupération position première occurence des Paramètres de la Version
    READ TABLE me->ms_work_data-t_hardcode_parameter WITH KEY second_key
                                                   COMPONENTS version_guid = iv_version_guid_copy
                                                 TRANSPORTING NO FIELDS.
    IF sy-subrc NE 0.
      " Aucune occurence
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Parcours l'ensemble des Paramètres de la Version
    LOOP AT me->ms_work_data-t_hardcode_parameter ASSIGNING <lfs_s_hardcode_parameter>
                                                  USING KEY second_key
                                                       FROM sy-tabix.

      CLEAR : ls_parameter_data.

      IF <lfs_s_hardcode_parameter>-version_guid NE iv_version_guid_copy.
        " On ne traite plus la même Version
        ""  --> Arrêt du traitement
        EXIT.

      ENDIF.

      TRY.
          " -----------------------------------------------------------
          " Création du Paramètre
          " -----------------------------------------------------------

          " Création d'un nouveau Paramètre
          rv_parameter_guid = me->parameter_add(
            EXPORTING
              iv_version_guid   = iv_version_guid_new
              iv_parameter_name = <lfs_s_hardcode_parameter>-parameter_name
            IMPORTING
              es_parameter_data = ls_parameter_data
          ).
          IF et_parameter_data IS SUPPLIED.
            " Alimentation table des Paramètres
            APPEND ls_parameter_data TO et_parameter_data.

          ENDIF.

          IF iv_copy_children EQ abap_true.
            " -----------------------------------------------------------
            " Copie des Enfants
            " -----------------------------------------------------------

            TRY.
                IF et_attribute_data             IS SUPPLIED
                OR et_attribute_range_data       IS SUPPLIED
                OR et_attribute_source_code_data IS SUPPLIED.
                  " Copie des Attributs + Récupération table des Attributs
                  me->attribute_copy(
                    EXPORTING
                      iv_parameter_guid_copy        = <lfs_s_hardcode_parameter>-parameter_guid
                      iv_parameter_guid_new         = rv_parameter_guid
                    IMPORTING
                      et_attribute_data             = lt_attribute_data
                      et_attribute_range_data       = lt_attribute_range_data
                      et_attribute_source_code_data = lt_attribute_source_code_data
                  ).

                  " Alimentation table des Attributs
                  APPEND LINES OF lt_attribute_data                     TO et_attribute_data.
                  INSERT LINES OF lt_attribute_range_data       INTO TABLE et_attribute_range_data.
                  INSERT LINES OF lt_attribute_source_code_data INTO TABLE et_attribute_source_code_data.

                ELSE.
                  " Copie des Attributs
                  me->attribute_copy(
                      iv_parameter_guid_copy = <lfs_s_hardcode_parameter>-parameter_guid
                      iv_parameter_guid_new  = rv_parameter_guid
                  ).

                ENDIF.

              CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
                " Erreur lors de la création du Paramètre
                ""  --> Passe à l'itération suivante // Erreur non bloquante
                CONTINUE.

            ENDTRY.

          ENDIF.

        CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
          " Erreur lors de la création du Paramètre
          ""  --> Passe à l'itération suivante // Erreur non bloquante
          CONTINUE.

      ENDTRY.

    ENDLOOP.

  ELSE.
    " -----------------------------------------------------------
    " Pas assez de paramètre
    " -----------------------------------------------------------

    IF 1 = 2. MESSAGE e501(zhardcode). ENDIF.
    me->__raise_exception( iv_msgno = 501 ).                "#EC NOTEXT

  ENDIF.

ENDMETHOD.


METHOD parameter_del.
*&---------------------------------------------------------------------*
*& Méthode         : PARAMETER_DEL                                     *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Paramètre - Suppression                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  IF NOT iv_version_guid IS INITIAL.
    " -----------------------------------------------------------
    " Suppression par Version
    " -----------------------------------------------------------

    IF me->version_exist( iv_version_guid ) EQ abap_false.
      " La Version n'exise pas
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Récupération position première occurence des Paramètres
    READ TABLE me->ms_work_data-t_hardcode_parameter WITH KEY second_key
                                                   COMPONENTS version_guid = iv_version_guid
                                                 TRANSPORTING NO FIELDS.
    IF sy-subrc EQ 0.
      " Parcours l'ensemble des Paramètres de la Version
      LOOP AT me->ms_work_data-t_hardcode_parameter USING KEY second_key
                                                    ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode_parameter>)
                                                         FROM sy-tabix.

        IF <lfs_s_hardcode_parameter>-version_guid NE iv_version_guid.
          " On ne traite plus la même Version
          ""  --> Arrêt de la boucle
          EXIT.

        ENDIF.

        " Suppression des Attributs
        me->attribute_del( iv_parameter_guid = <lfs_s_hardcode_parameter>-parameter_guid ).

        IF <lfs_s_hardcode_parameter>-volatile EQ abap_false.
          " Ajout du GUID du Paramètre pour suppression en DB
          APPEND <lfs_s_hardcode_parameter>-parameter_guid TO me->ms_deleted_data-t_parameter_guid.

        ENDIF.

        " Suppression du Paramètre
        DELETE me->ms_work_data-t_hardcode_parameter USING KEY loop_key.

      ENDLOOP.

    ENDIF.

  ELSEIF NOT iv_parameter_guid IS INITIAL.
    " -----------------------------------------------------------
    " Suppression par Paramètre
    " -----------------------------------------------------------

    IF me->parameter_exist( iv_parameter_guid ) EQ abap_false.
      " Le Paramètre n'existe pas
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Suppression du Paramètre
    " -----------------------------------------------------------

    " Suppression des Attributs
    me->attribute_del( iv_parameter_guid = iv_parameter_guid ).

    IF me->ms_work_data-t_hardcode_parameter[
        parameter_guid = iv_parameter_guid
       ]-volatile EQ abap_false.
      " Ajout du GUID du Paramètre
      APPEND iv_parameter_guid TO me->ms_deleted_data-t_parameter_guid.

    ENDIF.

    " Suppression de l'entrée
    DELETE me->ms_work_data-t_hardcode_parameter WHERE parameter_guid EQ iv_parameter_guid.

  ELSE.
    " Aucun paramètre
    RETURN.

  ENDIF.

ENDMETHOD.


METHOD parameter_exist.
*&---------------------------------------------------------------------*
*& Méthode         : PARAMETER_EXIST                                   *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Paramètre - Contrôle existence                    *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Recherche présence du Paramètre
  " -----------------------------------------------------------

  IF NOT iv_parameter_guid IS INITIAL.
    " Recherche présence du Paramètre via son GUID
    READ TABLE me->ms_work_data-t_hardcode_parameter WITH TABLE KEY parameter_guid = iv_parameter_guid
                                                       TRANSPORTING NO FIELDS.

  ELSE.
    " Recherche présence du Paramètre via son ID / Version
    ""  --> Contrôle existence de la version
    IF me->version_exist( iv_version_guid ) NE abap_true.
      " La Version n'existe pas
      ""  --> Lève une exception
      IF 1 = 2. MESSAGE e102(zhardcode). ENDIF.
      me->__raise_exception(
          iv_msgno = 102
          iv_msgv1 = me->mv_repid
          iv_msgv2 = iv_version_guid
      ).

    ENDIF.

    ""  --> Recherche existence du Paramètre via son Nom
    READ TABLE me->ms_work_data-t_hardcode_parameter WITH TABLE KEY second_key
                                                         COMPONENTS version_guid   = iv_version_guid
                                                                    parameter_name = iv_parameter_name
                                                       TRANSPORTING NO FIELDS.

  ENDIF.

  " Retourne le booléen
  rv_exist = boolc( sy-subrc EQ 0 ). "Vrai si la Version existe

ENDMETHOD.


METHOD parameter_get.
*&---------------------------------------------------------------------*
*& Méthode         : PARAMETER_GET                                     *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Paramètre - Récupération                          *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  CLEAR : es_hardcode_parameter.

  " -----------------------------------------------------------
  " Récupération de l'entrée correspond au Paramètre
  " -----------------------------------------------------------

  " Retourne les données du Paramètre
  READ TABLE me->ms_work_data-t_hardcode_parameter WITH TABLE KEY parameter_guid = iv_parameter_guid
                                                  REFERENCE INTO ro_hardcode_parameter.
  IF sy-subrc NE 0.
    " La version n'existe pas
    ""  --> Lève une Exception
    IF 1 = 2. MESSAGE e201(zhardcode). ENDIF.
    me->__raise_exception(
        iv_msgno = 201
        iv_msgv1 = iv_parameter_guid
        iv_msgv2 = me->mv_repid
    ).

  ENDIF.

  IF es_hardcode_parameter IS SUPPLIED.
    " Retourne les données (statiques)
    es_hardcode_parameter = ro_hardcode_parameter->*.

  ENDIF.

ENDMETHOD.


METHOD parameter_set.
*&---------------------------------------------------------------------*
*& Méthode         : PARAMETER_SET                                     *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Paramètre - Modification données                  *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    lo_hardcode_parameter TYPE REF TO ts_hardcode_parameter.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Récupération des données
  " -----------------------------------------------------------

  lo_hardcode_parameter = me->parameter_get( iv_parameter_guid ).

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  " Contrôle nécessité de MàJ
  IF iv_new_parameter_name IS INITIAL.
    " Aucune données à modifier
    ""  --> Arrêt du traitement
    RETURN.

  ELSEIF lo_hardcode_parameter->parameter_name EQ iv_new_parameter_name.
    " Aucune modification
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  IF iv_new_parameter_name IS SUPPLIED.
    " Contrôle que le Nom n'existe pas déjà
    IF me->parameter_exist(
         iv_version_guid       = lo_hardcode_parameter->version_guid
         iv_parameter_name     = iv_new_parameter_name
     ) EQ abap_true.
      " Un Paramètre avec ce nom existe déjà
      ""  --> Lève une Exception
      IF 1 = 2. MESSAGE e202(zhardcode). ENDIF.
      me->__raise_exception(
          iv_msgno = 202
          iv_msgv1 = iv_new_parameter_name
      ).

    ENDIF.

  ENDIF.

  " -----------------------------------------------------------
  " Modification des données
  " -----------------------------------------------------------

  " Initialisation Indicateur données non sauvegardée
  lo_hardcode_parameter->updated = abap_true.

  " Initialisation traçabilité
  lo_hardcode_parameter->changed_by = sy-uname.
  GET TIME STAMP FIELD lo_hardcode_parameter->changed_at.

  IF iv_new_parameter_name IS SUPPLIED.
    " Modification du Nom du Paramètre
    lo_hardcode_parameter->parameter_name = iv_new_parameter_name.

  ENDIF.

ENDMETHOD.


METHOD save_to_db.
*&---------------------------------------------------------------------*
*& Méthode         : SAVE_TO_DB                                        *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Sauvegarde HC en DB                               *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_ztec_t_hc_vers           TYPE ztec_t_hc_vers_tt,
    lt_ztec_t_hc_attr           TYPE ztec_t_hc_attr_tt,
    lt_ztec_t_hc_param          TYPE ztec_t_hc_param_tt,
    lt_hc_attribute_source_code TYPE zcl_hardcode_maintain=>tt_attribute_source_code.

  DATA :
    lt_hardcode_version   TYPE zcl_hardcode_maintain=>tt_hardcode_version,
    lt_hardcode_parameter TYPE zcl_hardcode_maintain=>tt_hardcode_parameter,
    lt_hardcode_attribute TYPE zcl_hardcode_maintain=>tt_hardcode_attribute.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_ztec_t_hc_vers  TYPE ztec_t_hc_vers,
    ls_ztec_t_hc_attr  TYPE ztec_t_hc_attr,
    ls_ztec_t_hc_param TYPE ztec_t_hc_param.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_subrc TYPE sy-subrc.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  IF NOT me->ms_deleted_data-t_attribute_guid[] IS INITIAL.
    " -----------------------------------------------------------
    " Suppression des Attributs
    " -----------------------------------------------------------

    " Extractions des GUIDs des Attributs
    LOOP AT me->ms_deleted_data-t_attribute_guid ASSIGNING FIELD-SYMBOL(<lfs_s_attribute_guid>).

      CLEAR : ls_ztec_t_hc_attr.

      " Initialisation des données
      ls_ztec_t_hc_attr-mandt                  = sy-mandt.
      ls_ztec_t_hc_attr-attribute_guid         = <lfs_s_attribute_guid>-attribute_guid.
      ls_ztec_t_hc_attr-attribute_guid_regroup = <lfs_s_attribute_guid>-attribute_guid_regroup.

      " Ajout de l'entrée
      APPEND ls_ztec_t_hc_attr TO lt_ztec_t_hc_attr.

    ENDLOOP.

    " Suppression des Attributs
    DELETE ztec_t_hc_attr FROM TABLE lt_ztec_t_hc_attr.

  ENDIF.

  IF NOT me->ms_deleted_data-t_parameter_guid[] IS INITIAL.
    " -----------------------------------------------------------
    " Suppression des Paramètres
    " -----------------------------------------------------------

    " Extractions des GUIDs des Paramètres
    LOOP AT me->ms_deleted_data-t_parameter_guid ASSIGNING FIELD-SYMBOL(<lfs_s_parameter_guid>).

      CLEAR : ls_ztec_t_hc_param.

      " Initialisation des données
      ls_ztec_t_hc_param-mandt          = sy-mandt.
      ls_ztec_t_hc_param-parameter_guid = <lfs_s_parameter_guid>.

      " Ajout de l'entrée
      APPEND ls_ztec_t_hc_param TO lt_ztec_t_hc_param.

    ENDLOOP.

    " Suppression des Paramètres
    DELETE ztec_t_hc_param FROM TABLE lt_ztec_t_hc_param.

  ENDIF.

  IF NOT me->ms_deleted_data-t_version_guid[] IS INITIAL.
    " -----------------------------------------------------------
    " Suppression des Versions
    " -----------------------------------------------------------

    " Extractions des GUIDs des Attributs
    LOOP AT me->ms_deleted_data-t_version_guid ASSIGNING FIELD-SYMBOL(<lfs_s_version_guid>).

      CLEAR : ls_ztec_t_hc_vers.

      " Initialisation des données
      ls_ztec_t_hc_vers-mandt        = sy-mandt.
      ls_ztec_t_hc_vers-version_guid = <lfs_s_version_guid>.

      " Ajout de l'entrée
      APPEND ls_ztec_t_hc_vers TO lt_ztec_t_hc_vers.

    ENDLOOP.

    " Suppression des Versions
    DELETE ztec_t_hc_vers FROM TABLE lt_ztec_t_hc_vers.

  ENDIF.

  IF NOT me->ms_deleted_data-t_source_code_guid[] IS INITIAL.
    " -----------------------------------------------------------
    " Suppression des Codes Sources
    " -----------------------------------------------------------

    LOOP AT me->ms_deleted_data-t_source_code_guid ASSIGNING
      FIELD-SYMBOL(<lfs_s_source_code_guid>).

      " Suppression du Code Source
      zcl_hardcode_cluster=>source_code_del( <lfs_s_source_code_guid> ).

    ENDLOOP.

  ENDIF.

  IF iv_commit EQ abap_true.
    " Supprime définitivement les données
    CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
      EXPORTING
        wait = abap_true.

  ENDIF.

  " Réinitialisation des tables de Travail
  FREE : me->ms_deleted_data, lt_ztec_t_hc_param, lt_ztec_t_hc_attr, lt_ztec_t_hc_vers.

  IF NOT me->ms_work_data-t_hardcode_version[] IS INITIAL.
    " -----------------------------------------------------------
    " Ajout des Versions
    " -----------------------------------------------------------

    " Initialisation des données
    lt_hardcode_version[] = me->ms_work_data-t_hardcode_version[].

    " Suppression des entrées non modifiées
    DELETE lt_hardcode_version WHERE updated  EQ abap_false
                                 AND volatile EQ abap_false.
    IF NOT lt_hardcode_version[] IS INITIAL.
      " Récupération des données
      lt_ztec_t_hc_vers[] = CORRESPONDING #( lt_hardcode_version[] ).

      TRY.
          " Ajout des données
          MODIFY ztec_t_hc_vers FROM TABLE lt_ztec_t_hc_vers.

        CATCH cx_root.
          " Une erreur grave est survenue
          lv_subrc = 4.

      ENDTRY.

    ENDIF.

  ENDIF.

  IF NOT me->ms_work_data-t_hardcode_parameter[] IS INITIAL.
    " -----------------------------------------------------------
    " Ajout des Versions
    " -----------------------------------------------------------

    " Initialisation des données
    lt_hardcode_parameter[] = me->ms_work_data-t_hardcode_parameter[].

    " Suppression des entrées non modifiées
    DELETE lt_hardcode_parameter WHERE updated  EQ abap_false
                                   AND volatile EQ abap_false.
    IF NOT lt_hardcode_parameter[] IS INITIAL.
      " Récupération des données
      lt_ztec_t_hc_param[] = CORRESPONDING #( lt_hardcode_parameter ).

      TRY.
          " Ajout des données
          MODIFY ztec_t_hc_param FROM TABLE lt_ztec_t_hc_param.

        CATCH cx_root.
          " Une erreur grave est survenue
          lv_subrc = 5.

      ENDTRY.

    ENDIF.

  ENDIF.

  IF NOT me->ms_work_data-t_hardcode_attribute[] IS INITIAL.
    " -----------------------------------------------------------
    " Modification des Attributs
    " -----------------------------------------------------------

    " Initialisation des données
    lt_hardcode_attribute[] = me->ms_work_data-t_hardcode_attribute[].

    " Suppression des entrées non modifiées
    DELETE lt_hardcode_attribute WHERE updated  EQ abap_false
                                   AND volatile EQ abap_false.
    IF NOT lt_hardcode_attribute[] IS INITIAL.
      " Récupération des données
      lt_ztec_t_hc_attr[] = CORRESPONDING #( lt_hardcode_attribute[] ).

      TRY.
          " Modification des données
          MODIFY ztec_t_hc_attr FROM TABLE lt_ztec_t_hc_attr.

        CATCH cx_root.
          " Une erreur grave est survenue
          lv_subrc = 6.

      ENDTRY.

    ENDIF.

  ENDIF.

  IF NOT me->ms_work_data-t_hc_attribute_source_code[] IS INITIAL.
    " -----------------------------------------------------------
    " Modification des Codes Sources
    " -----------------------------------------------------------

    " Initialisation des données
    DELETE me->ms_work_data-t_hc_attribute_source_code WHERE t_source_code IS INITIAL.
    lt_hc_attribute_source_code[] = me->ms_work_data-t_hc_attribute_source_code[].

    " Suppression des entrées non modifiées
    DELETE lt_hc_attribute_source_code WHERE updated  EQ abap_false
                                         AND volatile EQ abap_false.

    LOOP AT lt_hc_attribute_source_code
      ASSIGNING FIELD-SYMBOL(<lfs_s_attr_source_code>).

      " Vérifie que l'Attribut existe
      READ TABLE me->ms_work_data-t_hardcode_attribute
          WITH KEY attribute_guid_regroup = <lfs_s_attr_source_code>-attribute_guid_regroup
          TRANSPORTING NO FIELDS BINARY SEARCH.
      IF sy-subrc NE 0.
        " Aucune correspondance
        ""  --> Passe à l'itération suivante
        CONTINUE.

      ENDIF.

      " Ajout du Texte dans table Cluster
      zcl_hardcode_cluster=>source_code_add(
        iv_attribute_guid_regroup = <lfs_s_attr_source_code>-attribute_guid_regroup
        it_source_code            = <lfs_s_attr_source_code>-t_source_code
        iv_commit                 = abap_false
      ).

    ENDLOOP.

  ENDIF.

  IF iv_commit EQ abap_true.
    " -----------------------------------------------------------
    " Commit des données
    " -----------------------------------------------------------

    IF lv_subrc IS INITIAL.
      " Aucune erreur grave
      ""  --> Commit des données
      CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
        EXPORTING
          wait = abap_true.

    ELSE.
      " Une erreur est survenue
      ""  --> Annulation des des modifications
      CALL FUNCTION 'BAPI_TRANSACTION_ROLLBACK'.

      ""  --> Lève une Exception
      IF 1 = 2. MESSAGE e020(brain_dev). ENDIF.
      me->__raise_exception(
        iv_msgid = 'BRAIN_DEV'                              "#EC NOTEXT
        iv_msgno = 020
      ).

    ENDIF.

  ENDIF.

  IF lv_subrc IS INITIAL.
    " -----------------------------------------------------------
    " Réinitialisation Indicateur de MàJ
    " -----------------------------------------------------------

    " Versions
    LOOP AT me->ms_work_data-t_hardcode_version ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode_version>).

      " Réinitialisation témoin de MàJ
      CLEAR : <lfs_s_hardcode_version>-updated, <lfs_s_hardcode_version>-volatile.

    ENDLOOP.

    " Paramètres
    LOOP AT me->ms_work_data-t_hardcode_parameter ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode_parameter>).

      " Réinitialisation témoin de MàJ
      CLEAR : <lfs_s_hardcode_parameter>-updated, <lfs_s_hardcode_parameter>-volatile.

    ENDLOOP.

    " Attributs
    LOOP AT me->ms_work_data-t_hardcode_attribute ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode_attribute>).

      " Réinitialisation témoin de MàJ
      CLEAR : <lfs_s_hardcode_attribute>-updated, <lfs_s_hardcode_attribute>-volatile.

    ENDLOOP.

    " Code Source
    LOOP AT me->ms_work_data-t_hc_attribute_source_code ASSIGNING <lfs_s_attr_source_code>.

      " Réinitialisation témoin de MàJ
      CLEAR : <lfs_s_attr_source_code>-updated, <lfs_s_attr_source_code>-volatile.

    ENDLOOP.

  ENDIF.

  " -----------------------------------------------------------
  " Traitement sur SHM
  " -----------------------------------------------------------

  " Récupération information sur l'Instance de la SHM
  READ TABLE zcl_hardcode_shm_area=>get_instance_infos( CONV shm_inst_name( me->mv_repid ) ) INDEX 1 INTO DATA(ls_instance_infos).
  IF sy-subrc EQ 0 AND
  ls_instance_infos-versions_active GT 0.
    " Entrée récupérée et au moins une Version Active
    ""  --> Recharge l'Instance
    zcl_hardcode_shm=>get_instance( me->mv_repid )->hardcode_reload( ).

  ENDIF.

ENDMETHOD.


METHOD transport_request_create.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_e071  TYPE e071_t,
    lt_e071k TYPE e071k_t,
    lt_ko200 TYPE skwf_ko200s.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_e070     TYPE e070,
    ls_hc_trans TYPE ztec_t_hc_trans.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_task TYPE trkorr.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation du contenu de l'OT
  " -----------------------------------------------------------

  " Initialisation des données interface CTS - Transport
  lt_ko200 = VALUE #( (
      pgmid    = if_zdm_cc_trobj_constants=>gc_pgmid_r3tr
      object   = if_zdm_cc_trobj_constants=>gc_trobjtype_tabu
      objfunc  = cl_drf_filter_criteria=>gc_objfunc
      obj_name = zcl_hardcode=>mc_transport-register_table
  ) ).

  " Initialisation entrée de table Registre de Transport
  lt_e071k = VALUE #( (
      pgmid      = if_zdm_cc_trobj_constants=>gc_pgmid_r3tr
      object     = if_zdm_cc_trobj_constants=>gc_trobjtype_tabu
      objfunc    = if_cns_con=>update
      mastertype = cl_drf_filter_criteria=>gc_object
      objname    = zcl_hardcode=>mc_transport-register_table
      mastername = zcl_hardcode=>mc_transport-register_table
      tabkey     = |{ iv_repid }{ /spe/if_cons_constants_mvc=>c_range_wildcard }|
  ) ).

  " -----------------------------------------------------------
  " Création / Sélection de l'OT
  " -----------------------------------------------------------

  " Contrôle les élèments
  CALL FUNCTION 'TR_OBJECTS_CHECK'
    EXPORTING
      iv_no_show_option = abap_true
    TABLES
      wt_ko200          = lt_ko200
      wt_e071k          = lt_e071k
    EXCEPTIONS
      OTHERS            = 1.
  IF sy-subrc EQ 0.
    " Sélection / Création de l'OT
    CALL FUNCTION 'TR_OBJECTS_INSERT'
      EXPORTING
        wi_order          = rv_trkorr
        iv_no_show_option = abap_true
      IMPORTING
        we_order          = rv_trkorr
        we_task           = lv_task
      TABLES
        wt_ko200          = lt_ko200
        wt_e071k          = lt_e071k
      EXCEPTIONS
        OTHERS            = 1.

  ENDIF.
  IF sy-subrc NE 0.
    " Une erreur est survenue // Utilisateur interrompt la création
    ""  --> Réinitialisation Numéro d'OT
    CLEAR : rv_trkorr.

    ""  --> Retourne le message d'erreur
    RAISE EXCEPTION TYPE zcx_hardcode_maintain
      EXPORTING
        textid = VALUE #(
          msgid = sy-msgid msgno = sy-msgno
          attr1 = sy-msgv1 attr2 = sy-msgv2
          attr3 = sy-msgv3 attr4 = sy-msgv4
        ).

  ENDIF.

  " -----------------------------------------------------------
  " Ajout entrée XPRA
  " -----------------------------------------------------------
  " Je ne parviens pas à l'ajouter en même temps que le reste
  " -----------------------------------------------------------

  " Récupération entrée E071 existante
  SELECT * FROM e071 WHERE trkorr EQ @rv_trkorr INTO TABLE @lt_e071.
  READ TABLE lt_e071 WITH KEY pgmid    = if_zdm_cc_trobj_constants=>gc_pgmid_r3tr
                              object   = if_zdm_cc_trobj_constants=>gc_trobjtype_xpra
                              obj_name = zcl_hardcode=>mc_transport-xpra_program
                 TRANSPORTING NO FIELDS.
  IF sy-subrc NE 0.
    " Entrée XPRA non existante dans l'OT
    ""  --> Ajout entrée XPRA
    lt_e071 = VALUE #( (
        trkorr   = rv_trkorr
        pgmid    = if_zdm_cc_trobj_constants=>gc_pgmid_r3tr
        object   = if_zdm_cc_trobj_constants=>gc_trobjtype_xpra
        obj_name = zcl_hardcode=>mc_transport-xpra_program
    ) ).

    ""  --> Ajout de l'entrée XPRA
    CALL FUNCTION 'TRINT_UPDATE_COMM'
      EXPORTING
        wi_trkorr   = rv_trkorr
        wi_e070     = ls_e070
        wi_sel_e071 = abap_true
      TABLES
        wt_e071     = lt_e071
      EXCEPTIONS
        OTHERS      = 1.
    IF sy-subrc NE 0.
      " Une erreur est survenue
      ""  --> Réinitialisation Numéro d'OT
      CLEAR : rv_trkorr.

      ""  --> Retourne le message d'erreur
      RAISE EXCEPTION TYPE zcx_hardcode_maintain
        EXPORTING
          textid = VALUE #(
            msgid = sy-msgid msgno = sy-msgno
            attr1 = sy-msgv1 attr2 = sy-msgv2
            attr3 = sy-msgv3 attr4 = sy-msgv4
          ).

    ENDIF.

  ENDIF.

  " -----------------------------------------------------------
  " Ajout entrée Table Registre Transport HC
  " -----------------------------------------------------------

  " Récupération Chemin RFC du système
  SELECT SINGLE logsys FROM t000 WHERE mandt EQ @sy-mandt INTO @ls_hc_trans-system_source.
  IF sy-subrc NE 0 OR ls_hc_trans-system_source IS INITIAL.
    " Erreur ou Vide
    ""  --> Initialisation manuelle du chemin RFC
    ls_hc_trans-system_source = |{ sy-sysid }CLNT{ sy-mandt }|. ##NO_TEXT

  ENDIF.

  " Initialisation autres données
  ls_hc_trans-repid        = iv_repid.
  ls_hc_trans-trkorr       = rv_trkorr.
  ls_hc_trans-asked_by     = sy-uname.
  ls_hc_trans-mandt_target = /spe/if_cons_constants_mvc=>c_range_wildcard.
  GET TIME STAMP FIELD ls_hc_trans-asked_at.

  " Alimentation table Registre de Transport
  MODIFY ztec_t_hc_trans FROM ls_hc_trans.

  " Commit
  COMMIT WORK.

ENDMETHOD.


METHOD version_add.
*&---------------------------------------------------------------------*
*& Méthode         : VERSION_ADD                                       *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Version - Création                                *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_hardcode_version TYPE zcl_hardcode_maintain=>ts_hardcode_version.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  CLEAR : es_version_data.

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  " Contrôle que la version n'existe pas déjà
  IF me->version_exist( iv_version_id = iv_version_id ) EQ abap_true.
    " La version existe déjà
    ""  --> Lève une Exception
    IF 1 = 2. MESSAGE e101(zhardcode). ENDIF.
    me->__raise_exception(
        iv_msgno = 101
        iv_msgv1 = iv_version_id
        iv_msgv2 = me->mv_repid
    ).

  ENDIF.

  IF iv_is_primary EQ abap_true.
    " -----------------------------------------------------------
    " Modification de la Version primaire existante
    " -----------------------------------------------------------

    TRY.
        " Modification de l'indicateur Primaire de la version
        me->ms_work_data-t_hardcode_version[ version_primary = abap_true ]-version_primary = abap_false.

      CATCH cx_sy_itab_line_not_found.
        " Aucune Version Primaire

    ENDTRY.

  ENDIF.

  " -----------------------------------------------------------
  " Ajout d'une nouvelle version
  " -----------------------------------------------------------

  " Initialisation des données
  ls_hardcode_version-mandt           = sy-mandt.
  ls_hardcode_version-repid           = me->mv_repid.
  ls_hardcode_version-volatile        = abap_true.
  ls_hardcode_version-version_id      = iv_version_id.
  ls_hardcode_version-version_primary = iv_is_primary.

  " Initialisation donnés tracabilité
  ls_hardcode_version-created_by      = sy-uname.
  GET TIME STAMP FIELD ls_hardcode_version-created_at.

  TRY.
      " Création ID Unique
      ls_hardcode_version-version_guid = cl_system_uuid=>create_uuid_c32_static( ).

    CATCH cx_uuid_error.
      " Erreur lors de la création du GUID
      ""  --> Génération Nombre aléatoire
      ls_hardcode_version-version_guid = cl_abap_random=>seed( ).

  ENDTRY.

  " Ajout dans la table interne
  rv_version_guid = ls_hardcode_version-version_guid.
  INSERT ls_hardcode_version INTO TABLE me->ms_work_data-t_hardcode_version.

  IF es_version_data IS SUPPLIED.
    " -----------------------------------------------------------
    " Initialisation données
    " -----------------------------------------------------------

    " Retourne les données
    MOVE-CORRESPONDING ls_hardcode_version TO es_version_data.

  ENDIF.

ENDMETHOD.


METHOD version_copy.
*&---------------------------------------------------------------------*
*& Méthode         : VERSION_COPY                                      *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Version - Copie                                   *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_cx_hardcode_maintain TYPE REF TO zcx_hardcode_maintain.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_version_id_new TYPE ztec_t_hc_vers-version_id.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  CLEAR   : es_version_data.
  REFRESH : et_attribute_range_data,       et_parameter_data,
            et_attribute_source_code_data, et_attribute_data.

  " -----------------------------------------------------------
  " Copie de la Versionn
  " -----------------------------------------------------------

  IF NOT iv_version_id_new IS INITIAL.
    " ID spécifié
    ""  --> Utilisation de cet ID
    IF iv_version_id_new CS sy-abcde.
      " ID Version invalide
      ""  --> Reprise du Nom de l'ID à copier
      lv_version_id_new = |{ me->ms_work_data-t_hardcode_version[
          version_guid = iv_version_guid_copy
        ]-version_id + cl_abap_random=>seed( ) }|.

    ELSE.
      " ID Version valide
      lv_version_id_new = iv_version_id_new.

    ENDIF.

  ELSE.
    " Pas d'ID spécifié
    TRY.
        ""  --> Reprise du Nom de l'ID à copier
        lv_version_id_new = |{ me->ms_work_data-t_hardcode_version[
            version_guid = iv_version_guid_copy
         ]-version_id + cl_abap_random=>seed( ) }|.

      CATCH cx_root.
        " Aucune correspondance
        ""  --> Initialisation ID Aléatoire
        lv_version_id_new = |{ cl_abap_random=>seed( ) }|.  "#EC NOTEXT

    ENDTRY.

  ENDIF.

  TRY.
      " -----------------------------------------------------------
      " Ajout d'une nouvelle version
      " -----------------------------------------------------------

      rv_version_guid = me->version_add(
        EXPORTING
          iv_version_id   = iv_version_id_new
          iv_is_primary   = abap_false
        IMPORTING
          es_version_data = es_version_data
      ).

    CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
      " Une erreur est survenue
      ""  --> Lève l'exception
      me->__raise_exception( io_exception = lo_cx_hardcode_maintain ).

  ENDTRY.

  IF iv_copy_children EQ abap_true.

    TRY.
        " -----------------------------------------------------------
        " Copie des Paramètres
        " -----------------------------------------------------------

        IF et_parameter_data             IS SUPPLIED
        OR et_attribute_range_data       IS SUPPLIED
        OR et_attribute_source_code_data IS SUPPLIED.
          " Copie des Paramètres + Restitution Paramètre créé
          me->parameter_copy(
            EXPORTING
              iv_version_guid_copy          = iv_version_guid_copy
              iv_version_guid_new           = rv_version_guid
              iv_copy_children              = iv_copy_children
            IMPORTING
              et_parameter_data             = et_parameter_data
              et_attribute_data             = et_attribute_data
              et_attribute_range_data       = et_attribute_range_data
              et_attribute_source_code_data = et_attribute_source_code_data
          ).

        ELSE.
          " Copie des Paramètres
          me->parameter_copy(
              iv_version_guid_copy  = iv_version_guid_copy
              iv_copy_children      = iv_copy_children
          ).

        ENDIF.

      CATCH zcx_hardcode_maintain INTO lo_cx_hardcode_maintain.
        " Une erreur est survenue lors de la Copie
        ""  --> Tant pis ...

    ENDTRY.

  ENDIF.

ENDMETHOD.


METHOD version_del.
*&---------------------------------------------------------------------*
*& Méthode         : VERSION_DEL                                       *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Version - Suppression Version et dépendances      *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_hardcode_version TYPE zcl_hardcode_maintain=>ts_hardcode_version.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
        <lfs_s_hardcode_version> TYPE zcl_hardcode_maintain=>ts_hardcode_version.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  IF NOT iv_version_guid IS INITIAL.
    " -----------------------------------------------------------
    " Récupération des données de Version
    " -----------------------------------------------------------

    me->version_get(
      EXPORTING
        iv_version_guid     = iv_version_guid
      IMPORTING
        es_hardcode_version = ls_hardcode_version
    ).
*    CATCH zcx_hardcode_maintain.    "L'Exception est automatiquement levé au niveau au-dessus

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF ls_hardcode_version-version_primary EQ abap_true.
      " Il s'agit de la Version Primaire
      ""  --> Contrôle présence d'au moins une autre Version
      LOOP AT me->ms_work_data-t_hardcode_version ASSIGNING <lfs_s_hardcode_version>
                                                  USING KEY second_key
                                                      WHERE repid      EQ me->mv_repid
                                                        AND version_id NE ls_hardcode_version-version_id.
        " Réinitialisation code retour (dans le doute)
        CLEAR : sy-subrc.

      ENDLOOP.
      IF <lfs_s_hardcode_version> IS ASSIGNED.
        " Appose le caractère "Primaire" à la dernière version lue
        <lfs_s_hardcode_version>-version_primary = abap_true.

      ELSE.
        " Aucune autre Version
        ""  --> Lève une Exception
        IF 1 = 2. MESSAGE e103(zhardcode). ENDIF.
        me->__raise_exception( iv_msgno = 103 ).

      ENDIF.

    ENDIF.

    " -----------------------------------------------------------
    " Traitement sur les Paramètres
    " -----------------------------------------------------------

    me->parameter_del( iv_version_guid = ls_hardcode_version-version_guid ).

    " -----------------------------------------------------------
    " Traitement sur les données d'entête
    " -----------------------------------------------------------

    " Suppression de l'entrée dans la table de Travail
    DELETE me->ms_work_data-t_hardcode_version WHERE version_guid EQ ls_hardcode_version-version_guid.

    IF ls_hardcode_version-volatile EQ abap_false.
      " Récupération des GUIDs d'entête à supprimer
      APPEND ls_hardcode_version-version_guid TO me->ms_deleted_data-t_version_guid.

    ENDIF.

  ELSE.
    " -----------------------------------------------------------
    " Suppression par Programme
    " -----------------------------------------------------------

    " Récupération position première occurence des Version
    READ TABLE me->ms_work_data-t_hardcode_version WITH KEY second_key
                                                 COMPONENTS repid = me->mv_repid
                                               TRANSPORTING NO FIELDS.
    IF sy-subrc EQ 0.
      " Parcours l'ensemble des Paramètres de la Version
      LOOP AT me->ms_work_data-t_hardcode_version USING KEY second_key
                                                  ASSIGNING <lfs_s_hardcode_version>
                                                       FROM sy-tabix.

        IF <lfs_s_hardcode_version>-repid NE me->mv_repid.
          " On ne traite plus le même Programme
          ""  --> Arrêt de la boucle
          EXIT.

        ENDIF.

        " Suppression des Paramètres
        me->parameter_del( iv_version_guid = <lfs_s_hardcode_version>-version_guid ).

        IF <lfs_s_hardcode_version>-volatile EQ abap_false.
          " Ajout du GUID du Paramètre pour suppression en DB
          APPEND <lfs_s_hardcode_version>-version_guid TO me->ms_deleted_data-t_version_guid.

        ENDIF.

      ENDLOOP.

      " -----------------------------------------------------------
      " Traitement sur les données d'entête
      " -----------------------------------------------------------

      " Suppression de l'entrée dans la table de Travail
      DELETE me->ms_work_data-t_hardcode_version USING KEY second_key WHERE repid = me->mv_repid.

    ENDIF.

  ENDIF.

ENDMETHOD.


METHOD version_exist.
*&---------------------------------------------------------------------*
*& Méthode         : VERSION_EXIST                                     *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Version - Contrôle existence                      *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Recherche présence de la Version
  " -----------------------------------------------------------

  IF NOT iv_version_id IS INITIAL.
    " Recherche par ID
    READ TABLE me->ms_work_data-t_hardcode_version WITH TABLE KEY second_key
                                                       COMPONENTS repid      = me->mv_repid
                                                                  version_id = iv_version_id
                                                     TRANSPORTING NO FIELDS.

  ELSEIF NOT iv_version_guid IS INITIAL.
    " Recherche par GUID
    READ TABLE me->ms_work_data-t_hardcode_version WITH TABLE KEY version_guid = iv_version_guid
                                                     TRANSPORTING NO FIELDS.

  ELSE.
    " Aucun paramètre
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " Retourne le booléen
  rv_exist = boolc( sy-subrc EQ 0 ). "Vrai si la Version existe

ENDMETHOD.


METHOD version_get.
*&---------------------------------------------------------------------*
*& Méthode         : VERSION_GET                                       *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Version - Récupération données                    *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  CLEAR : es_hardcode_version.

  " -----------------------------------------------------------
  " Récupération de l'entrée correspond à la Version
  " -----------------------------------------------------------

  " Retourne les données de la Version
  READ TABLE me->ms_work_data-t_hardcode_version WITH TABLE KEY version_guid = iv_version_guid
                                                 REFERENCE INTO ro_hardcode_version.
  IF sy-subrc NE 0.
    " La version n'existe pas
    ""  --> Lève une Exception
    IF 1 = 2. MESSAGE e102(zhardcode). ENDIF.
    me->__raise_exception(
        iv_msgno = 102
        iv_msgv1 = iv_version_guid
        iv_msgv2 = me->mv_repid
    ).

  ENDIF.

  IF es_hardcode_version IS SUPPLIED.
    " Retourne les données (statiques)
    es_hardcode_version = ro_hardcode_version->*.

  ENDIF.

ENDMETHOD.


METHOD version_get_next.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Détermine prochain numéro de Version
  " -----------------------------------------------------------

  " Récupération du dernier numéro de Version
  READ TABLE me->ms_work_data-t_hardcode_version
       INDEX lines( me->ms_work_data-t_hardcode_version )
   USING KEY second_key ASSIGNING FIELD-SYMBOL(<lfs_s_hardcode_version>).
  IF sy-subrc NE 0.
    " Pas de Version défini
    ""  --> N° de Version = 1
    MOVE 1 TO rv_version.

  ELSE.
    " Version défini
    ""  --> Incrémenation de la Version
    rv_version = <lfs_s_hardcode_version>-version_id + 1.

  ENDIF.

ENDMETHOD.


METHOD version_primary_set.
*&---------------------------------------------------------------------*
*& Méthode         : VERSION_PRIMARY_SET                               *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Version - Modification Primarité                  *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Récupération de l'entrée correspondant à la Version
  " -----------------------------------------------------------

  " Récupération
  DATA(lo_hardcode_version) = me->version_get( iv_version_guid ).
*  CATCH zcx_hardcode_maintain. "L'exception est directement levé au niveau au-dessus

  " -----------------------------------------------------------
  " Supprime le caractère Primaire de l'ancienne Version
  " -----------------------------------------------------------

  TRY.
      " Modification de l'indicateur Primaire de la version
      me->ms_work_data-t_hardcode_version[ version_primary = abap_true ]-version_primary = abap_false.

    CATCH cx_sy_itab_line_not_found.
      " Aucune Version Primaire

  ENDTRY.

  " -----------------------------------------------------------
  " Appose le caractère Primaire sur la Version
  " -----------------------------------------------------------

  lo_hardcode_version->version_primary = abap_true.

ENDMETHOD.


METHOD version_set.
*&---------------------------------------------------------------------*
*& Méthode         : VERSION_SET                                       *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Version - Modification données                    *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    lo_hardcode_version TYPE REF TO zcl_hardcode_maintain=>ts_hardcode_version.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Récupération des données
  " -----------------------------------------------------------

  lo_hardcode_version = me->version_get( iv_version_guid ).

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  " Contrôle nécessité de MàJ
  IF  iv_new_version_id IS INITIAL
  AND NOT iv_new_version_primary IS SUPPLIED.
    " Aucune données à modifier
    ""  --> Arrêt du traitement
    RETURN.

  ELSEIF lo_hardcode_version->version_id      EQ iv_new_version_id
     AND lo_hardcode_version->version_primary EQ iv_new_version_primary.
    " Aucune modification
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  IF iv_new_version_id IS SUPPLIED.
    " Contrôle que le Nom n'existe pas déjà
    IF me->version_exist( iv_version_id = iv_new_version_id ) EQ abap_true.
      " Une version avec ce nom existe déjà
      ""  --> Lève une Exception
      IF 1 = 2. MESSAGE e101(zhardcode). ENDIF.
      me->__raise_exception(
          iv_msgno = 101
          iv_msgv1 = iv_version_guid
          iv_msgv2 = me->mv_repid
      ).

    ENDIF.

  ENDIF.

  " -----------------------------------------------------------
  " Modification des données
  " -----------------------------------------------------------

  " Initialisation Indicateur données non sauvegardée
  lo_hardcode_version->updated = abap_true.

  " Initialisation traçabilité
  lo_hardcode_version->changed_by = sy-uname.
  GET TIME STAMP FIELD lo_hardcode_version->changed_at.

  IF iv_new_version_id IS SUPPLIED.
    " Modification de l'ID de Version
    lo_hardcode_version->version_id = iv_new_version_id.

  ENDIF.

  IF iv_new_version_primary IS SUPPLIED.
    " Modification de la Primarité da la Verison
    lo_hardcode_version->version_primary = iv_new_version_primary.

  ENDIF.

ENDMETHOD.


METHOD __raise_exception.
*&---------------------------------------------------------------------*
*& Méthode         : __RAISE_EXCEPTION                                 *
*& Classe          : ZCL_HARDCODE_MAINTAIN                             *
*& Description     : Lève une Exception                                *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 11/05/2016                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_text_id TYPE scx_t100key.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Génération de l'Exception
  " -----------------------------------------------------------

  IF io_exception IS BOUND.
    " Lève l'exception
    RAISE EXCEPTION TYPE zcx_hardcode_maintain
      EXPORTING
        previous = io_exception.

  ELSE.
    " Initialisation structure
    ls_text_id-msgid = iv_msgid.
    ls_text_id-msgno = iv_msgno.
    ls_text_id-attr1 = iv_msgv1.
    ls_text_id-attr2 = iv_msgv2.
    ls_text_id-attr3 = iv_msgv3.
    ls_text_id-attr4 = iv_msgv4.

    " Lève l'exception
    RAISE EXCEPTION TYPE zcx_hardcode_maintain
      EXPORTING
        textid = ls_text_id.

  ENDIF.

ENDMETHOD.
ENDCLASS.
