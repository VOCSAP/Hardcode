PROCESS BEFORE OUTPUT.
  MODULE status.
  CALL SUBSCREEN subscreen_selection_criteria
   INCLUDING sy-repid '2100' ##NO_TEXT.

PROCESS AFTER INPUT.
  MODULE user_command.
  CALL SUBSCREEN subscreen_selection_criteria.
