class ZCL_DYNAMIC_SOURCE_CODE definition
  public
  final
  create public .

public section.

  types:
    BEGIN OF ts_syntax_properties,
      syntax_error TYPE xsdboolean,
      t_syntax_check_result TYPE TAB_RSLINLMSG,
    END OF   ts_syntax_properties .
  types:
    BEGIN OF ts_execution_properties,
      execution_error TYPE xsdboolean,
      timestamp_begin TYPE timestamp,
      timestamp_end TYPE timestamp,
      execution_duration TYPE i,
      message TYPE string,
    END OF   ts_execution_properties .
  types:
    BEGIN OF ts_result,
          syntax_properties    TYPE zcl_dynamic_source_code=>ts_syntax_properties,
          execution_properties TYPE zcl_dynamic_source_code=>ts_execution_properties,
        END OF   ts_result .

  class-methods EXECUTE
    importing
      !IT_SOURCE_CODE type STRINGTAB
    returning
      value(RS_RESULT) type ZCL_DYNAMIC_SOURCE_CODE=>TS_RESULT .
  class-methods EXECUTE_SELECT_DYNAMIC
    importing
      !IV_SELECT type STRING
    changing
      !COT_RESULT type ref to DATA .
  class-methods EXECUTION_LOG_SOURCE_CODE_GET
    importing
      !IV_SRTFD type ZTB_DYNAMIC_EXEC-SRTFD
    returning
      value(RT_SOURCE_CODE) type STRINGTAB .
protected section.
private section.

  types:
    BEGIN OF ts_work_area_private,
      t_source_code TYPE stringtab,
      t_syntax_check TYPE TAB_RSLINLMSG,
    END OF   ts_work_area_private .

  class-data MS_WORK_AREA_PRIVATE type ZCL_DYNAMIC_SOURCE_CODE=>TS_WORK_AREA_PRIVATE .

  class-methods _SYNTAX_CHECK
    returning
      value(RV_SUBRC) type SY-SUBRC .
  class-methods _EXECUTION_LOG
    returning
      value(RV_SUBRC) type SY-SUBRC .
  class-methods _MANDATORY_INSTRUCTION_CHECK .
  class-methods _AUTORIZATION_CHECK
    returning
      value(RV_AUTHORIZED) type XSDBOOLEAN .
  class-methods _SOURCE_CODE_FORMAT
    importing
      !IT_SOURCE_CODE type STRINGTAB .
ENDCLASS.



CLASS ZCL_DYNAMIC_SOURCE_CODE IMPLEMENTATION.


METHOD execute.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_name  TYPE string,
    lv_class TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Préparation Code Source
  " -----------------------------------------------------------

  " Préparation du Code Source
  zcl_dynamic_source_code=>_source_code_format( it_source_code[] ).

  " -----------------------------------------------------------
  " Contrôle autorisation des instructions
  " -----------------------------------------------------------

  " Contrôle des autorisation
  IF zcl_dynamic_source_code=>_autorization_check( )
    EQ abap_false.
    " Instruction non autorisé
    rs_result-execution_properties-execution_error = abap_true.
    rs_result-execution_properties-message = 'Instruction(s) / Utilisateur non autorisé'. "#EC NOTEXT
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Ajout des Instructions obligatoires
  " -----------------------------------------------------------

  " Contrôle et ajout instruction obligatoire
  zcl_dynamic_source_code=>_mandatory_instruction_check( ).

  " -----------------------------------------------------------
  " Contrôle syntaxique
  " -----------------------------------------------------------

  IF NOT zcl_dynamic_source_code=>_syntax_check( )
    IS INITIAL.
    " Contrôle syntaxique en erreur
    ""  --> Retourne Syntaxe en erreur
    rs_result-syntax_properties-syntax_error = abap_true.

    ""  --> Transmet le retour du contrôle syntaxique
    rs_result-syntax_properties-t_syntax_check_result[] = zcl_dynamic_source_code=>ms_work_area_private-t_syntax_check[].

    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  TRY.
      " -----------------------------------------------------------
      " Génération Code Source sous forme de routine
      " -----------------------------------------------------------

      " Génération Routine avec le code source
      GENERATE SUBROUTINE POOL zcl_dynamic_source_code=>ms_work_area_private-t_source_code
                          NAME lv_name
                       MESSAGE rs_result-execution_properties-message
                  SHORTDUMP-ID DATA(lv_sid).

      " -----------------------------------------------------------
      " Exécution du Code Source
      " -----------------------------------------------------------

      " Suivant le code retour
      CASE sy-subrc.

        WHEN 0.
          " Ok !
          " --> Récupération TS début traitement
          GET TIME STAMP FIELD rs_result-execution_properties-timestamp_begin.

          TRY.
              ""  --> Exécute le traitement
              lv_class = |\\PROGRAM=| && lv_name && |\\CLASS=LCL_MAIN|. "#EC NOTEXT
              CALL METHOD (lv_class)=>main.

*              PERFORM main IN PROGRAM (lv_name).

              ""  --> Log le traitement
              zcl_dynamic_source_code=>_execution_log( ).

            CATCH cx_root INTO DATA(lo_cx_root).
              " Une erreur est survenue
              ""  --> Renvoi l'erreur
              rs_result-execution_properties-execution_error = abap_true.
              rs_result-execution_properties-message =
                |Erreur exécution : { lo_cx_root->if_message~get_longtext( ) }|. "#EC NOTEXT

          ENDTRY.

        WHEN 4.
          " Pas Ok
*      MESSAGE lv_message TYPE if_msg_output=>msgtype_success DISPLAY LIKE if_msg_output=>msgtype_warning.

        WHEN 8.
          " Pas Ok
*      MESSAGE lv_sid TYPE if_msg_output=>msgtype_success DISPLAY LIKE if_msg_output=>msgtype_warning.

        WHEN OTHERS.

      ENDCASE.

    CATCH cx_root INTO lo_cx_root.
      " Une erreur est survenue
      ""  --> Retourne erreur
      rs_result-execution_properties-execution_error = abap_true.
      rs_result-execution_properties-message = lo_cx_root->if_message~get_longtext( ).

  ENDTRY.

  " -----------------------------------------------------------
  " Post-Traitement
  " -----------------------------------------------------------

  " Récupération TS fin traitement
  GET TIME STAMP FIELD rs_result-execution_properties-timestamp_end.

  " Calcul la durée d'exécution
  rs_result-execution_properties-execution_duration =
    rs_result-execution_properties-timestamp_end - rs_result-execution_properties-timestamp_begin.

ENDMETHOD.


METHOD execute_select_dynamic.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_result    TYPE REF TO cl_sql_result_set,
    lo_statement TYPE REF TO cl_sql_statement.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF NOT cot_result IS BOUND.
    " Données non activées
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.


  TRY.
      " -----------------------------------------------------------
      " Exécution de la requête
      " -----------------------------------------------------------

      " Création connexion HDB & Exécution de la requêtes
      lo_result = cl_db6_con=>get_connection( )->create_statement( )->execute_query( iv_select ).

      " Initialisation table de retour
      lo_result->set_param_table( cot_result ).

      " Récupération données
      lo_result->next_package( ).

      " Fermeture connexion HDB
      lo_result->close( ).

    CATCH cx_sql_exception INTO DATA(lo_cx_exception).
      " Une erreur est survenue
      ""  --> Retourne l'Exception
*        RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
*          EXPORTING
*            previous = lo_cx_exception.

    CLEANUP.
      " Contexte
      IF lo_result IS BOUND.
        " Fermeture connexion HDB
        lo_result->close( ).

      ENDIF.

  ENDTRY.

ENDMETHOD.


METHOD execution_log_source_code_get.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_log TYPE ztb_dynamic_exec.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_source_code TYPE xstring.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Récupération du Code Source
      " -----------------------------------------------------------

      " Import du Code Source
      IMPORT source_code = lv_source_code
        FROM DATABASE ztb_dynamic_exec(td)
                   TO ls_log
                   ID iv_srtfd.
      IF sy-subrc NE 0.
        " Le Type n'existe pas
        ""  --> Arrêt du traitement
        RETURN.

      ENDIF.

      " -----------------------------------------------------------
      " Conversion XSTRING en table Code Source
      " -----------------------------------------------------------

      " Sérialization du Code Source
      CALL TRANSFORMATION id
               SOURCE XML lv_source_code
                   RESULT source_code = rt_source_code.

    CATCH cx_root.                                      "#EC NO HANDLER
      " Erreur conversion en XML
      ""  --> Tant pis; on ne pourra pas afficher le code source

  ENDTRY.

ENDMETHOD.


METHOD _autorization_check.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
      lt_val_checked TYPE string_hashed_table.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_source_code         TYPE string,
    lv_source_code_checked TYPE string.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle autorisation
  " -----------------------------------------------------------

  " Vérifie que l'utilisateur puisse exécuter l'éditeur
  CALL FUNCTION 'AUTHORITY_CHECK_TCODE'
    EXPORTING
      tcode  = 'SE38' "#EC NOTEXT
    EXCEPTIONS
      ok     = 1
      not_ok = 2
      OTHERS = 3.
  IF sy-subrc EQ 1.
    " Utilisateur autorisé
    ""  --> Vérifie les autorisations de développement local
    AUTHORITY-CHECK OBJECT 'S_DEVELOP'                      "#EC NOTEXT
      ID 'DEVCLASS' FIELD '$TMP'                            "#EC NOTEXT
      ID 'OBJTYPE'  FIELD 'PROG'                            "#EC NOTEXT
      ID 'OBJNAME'  DUMMY                                   "#EC NOTEXT
      ID 'P_GROUP'  DUMMY                                   "#EC NOTEXT
      ID 'ACTVT'    FIELD '02'.                             "#EC NOTEXT

  ENDIF.
  IF NOT sy-subrc IS INITIAL.
    " Pas accès SE38 || Développement local non autorisé
    ""  --> Retourne en erreur
    rv_authorized = abap_false.
    RETURN.

  ELSE.
    " Utilisateur autorisée
    rv_authorized = abap_true.

  ENDIF.

*  " -----------------------------------------------------------
*  " Contrôle instructions
*  " -----------------------------------------------------------
*
*  " Concaténe les lignes
*  lv_source_code = concat_lines_of( zcl_dynamic_source_code=>ms_work_area_private-t_source_code ).
*
*  TRY.
*      ToDo : Utiliser table ZTB_DYNAMIC_AUTH pour lister instruction
*      " Contrôle instruction
*      lv_source_code_checked = cl_abap_dyn_prg=>check_whitelist_tab(
*        val       = lv_source_code
*        whitelist = lt_val_checked
*      ).
*
*      " Autorisé ?
*      rv_authorized = xsdbool( lv_source_code_checked = lv_source_code ).
*
*    CATCH cx_abap_not_in_whitelist.
*      " Pas autorisé
*      rv_authorized = abap_false.
*
*  ENDTRY.

ENDMETHOD.


METHOD _execution_log.
***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
      lt_source_code TYPE stringtab.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_log TYPE ztb_dynamic_exec.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
        lv_source_code TYPE xstring.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Modification Code Source pour supprimer le superflus
      " -----------------------------------------------------------

      " Initialisation table Code Source local
      lt_source_code[] = zcl_dynamic_source_code=>ms_work_area_private-t_source_code[].

      " Suppression des lignes ajoutées (PROGRAM. et CLASS LCL_MAIN.)
      DELETE lt_source_code INDEX 1.

      " Suppression dernière ligne (ENDCLASS.)
      DELETE lt_source_code INDEX lines( lt_source_code ).

      " -----------------------------------------------------------
      " Conversion table Code Source en XSTRING
      " -----------------------------------------------------------

      " Sérialization du Code Source
      CALL TRANSFORMATION id
                   SOURCE source_code = lt_source_code
               RESULT XML lv_source_code.

    CATCH cx_root.                                      "#EC NO HANDLER
      " Erreur conversion en XML
      ""  --> Tant pis; on ne pourra pas afficher le code source

  ENDTRY.

  " -----------------------------------------------------------
  " Enregistre l'exécution
  " -----------------------------------------------------------

  " Initialisation données
  ls_log-mandt          = sy-mandt.
  ls_log-launch_user    = sy-uname.
  ls_log-launch_at_date = sy-datum.
  ls_log-launch_at_time = sy-uzeit.

  TRY.
      " Génération ID Unique
      ls_log-srtfd = cl_system_uuid=>create_uuid_c32_static( ).

    CATCH cx_uuid_error.
      " Une erreur est survenue
      ""  --> Génération nombre aléatoire
      ls_log-srtfd = cl_abap_random=>seed( ) * cl_abap_random=>seed( ).

  ENDTRY.

  TRY.
      " Export du Code Source
      EXPORT source_code = lv_source_code
          TO DATABASE ztb_dynamic_exec(td)
                 FROM ls_log
                   ID ls_log-srtfd.

    CATCH cx_root.
      " Erreur ajout dans la DB
      ""  --> Bon tant pis ...
      rv_subrc = 9.
      RETURN.

  ENDTRY.

ENDMETHOD.


METHOD _mandatory_instruction_check.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
        lt_result TYPE match_result_tab.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
        lv_regex TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Recherche des Instructions obligatoires
  " -----------------------------------------------------------

  " Recherche Instruction "PROGRAM"
  FIND REGEX |({ if_kaizen_keywords_c=>gc_program }).*(\\.)| "#EC NOTEXT
    IN zcl_dynamic_source_code=>ms_work_area_private-t_source_code[ 1 ]
    IGNORING CASE RESULTS lt_result.
  IF sy-subrc EQ 0.
    " Correspondance trouvée
    ""  --> On considère que toutes les instructions obligatoires sont présentes
    RETURN.

  ENDIF.

  ""  --> Encapsulation pour appel dynamique via méthode - Début
  DATA(lt_mandatory_instruction) = VALUE stringtab(
    ( |{ if_kaizen_keywords_c=>gc_program }.|     )         "#EC NOTEXT
    ( |CLASS LCL_MAIN DEFINITION.|     )                    "#EC NOTEXT
    ( |  PUBLIC SECTION.|              )                    "#EC NOTEXT
    ( |    CLASS-METHODS MAIN.|        )                    "#EC NOTEXT
    ( |ENDCLASS.|                      )                    "#EC NOTEXT
    ( |CLASS LCL_MAIN IMPLEMENTATION.| )                    "#EC NOTEXT
    ( |  METHOD MAIN.|                 )                    "#EC NOTEXT
    ).
  INSERT concat_lines_of( lt_mandatory_instruction )
    INTO zcl_dynamic_source_code=>ms_work_area_private-t_source_code INDEX 1.

  " Encapsulation pour appel dynamique via méthode - Fin
  lt_mandatory_instruction = VALUE stringtab(
    ( |  ENDMETHOD.| )                                      "#EC NOTEXT
    ( |ENDCLASS.|    )                                      "#EC NOTEXT
   ).
  APPEND concat_lines_of( lt_mandatory_instruction )
      TO zcl_dynamic_source_code=>ms_work_area_private-t_source_code.

ENDMETHOD.


METHOD _source_code_format.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_source_code TYPE string.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Préparation du Code Source
  " -----------------------------------------------------------

  " Initalisation table Source Code
  zcl_dynamic_source_code=>ms_work_area_private-t_source_code[] = it_source_code[].

*  " Suppression lignes vide
*  DELETE zcl_dynamic_source_code=>ms_work_area_private-t_source_code
*   WHERE table_line IS INITIAL.

  " Mise en Majuscule (pour vérif. instructions)
  LOOP AT zcl_dynamic_source_code=>ms_work_area_private-t_source_code
    ASSIGNING FIELD-SYMBOL(<lfs_s_source_code>).

    TRANSLATE <lfs_s_source_code> TO UPPER CASE.
    CONDENSE : <lfs_s_source_code>.

  ENDLOOP.

*  " Initialisation variable de travail
*  lv_source_code = concat_lines_of( table = it_source_code[] sep = space ).
*
*  " Mise en majuscule (pour contrôle vérif instruction)
*  TRANSLATE lv_source_code TO UPPER CASE.
*
*  " Suppression des espaces inutiles
*  CONDENSE lv_source_code.
*
*  " Découpage par fin d'instruction
*  SPLIT lv_source_code AT '.' INTO TABLE zcl_dynamic_source_code=>ms_work_area_private-t_source_code.
*
*  " Suppression des espaces inutiles et rajout de l'instruction de fin de ligne
*  LOOP AT zcl_dynamic_source_code=>ms_work_area_private-t_source_code
*    ASSIGNING FIELD-SYMBOL(<lfs_s_source_code>).
*
*    IF strlen( <lfs_s_source_code> ) GE 1
*      AND ( <lfs_s_source_code>(1) EQ |'| OR <lfs_s_source_code>(1) EQ '|' ). "#EC NOTEXT
*      " Caractère fin de littéral était disposé après un '.'
*      ""  --> Repositionne le caractère à la ligne précédente
*      zcl_dynamic_source_code=>ms_work_area_private-t_source_code[ sy-tabix - 1 ] =
*        zcl_dynamic_source_code=>ms_work_area_private-t_source_code[ sy-tabix - 1 ] && <lfs_s_source_code> && '.'.
*      DELETE zcl_dynamic_source_code=>ms_work_area_private-t_source_code USING KEY loop_key.
*      CONTINUE.
*
*    ENDIF.
*
*    CONDENSE : <lfs_s_source_code>.
*    <lfs_s_source_code> = <lfs_s_source_code> && '.'.       "#EC NOTEXT
*
*  ENDLOOP.

*  " Suppression lignes vide
*  DELETE zcl_dynamic_source_code=>ms_work_area_private-t_source_code
*   WHERE table_line IS INITIAL.

ENDMETHOD.


METHOD _syntax_check.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_warning     TYPE tab_rslinlmsg,
    lt_error_descr TYPE tab_rslinlmsg.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_line    TYPE i,
    lv_word    TYPE string,
    lv_message TYPE string.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle syntaxique
  " -----------------------------------------------------------

  " Contrôle syntaxique
  SYNTAX-CHECK FOR zcl_dynamic_source_code=>ms_work_area_private-t_source_code
           MESSAGE lv_message
              LINE lv_line
              WORD lv_word
*                ID 'MSG'  TABLE lt_warning                  "#EC NOTEXT
                ID 'ERR'  TABLE zcl_dynamic_source_code=>ms_work_area_private-t_syntax_check "#EC NOTEXT
*                ID 'LTXT' TABLE lt_error_descr
                        PROGRAM 'Z_BC_HC_SOURCE_EXEC'.      "#EC NOTEXT

  " Retourne code retour
  rv_subrc = sy-subrc.

ENDMETHOD.
ENDCLASS.
