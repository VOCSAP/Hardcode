class ZCL_HARDCODE_SHM definition
  public
  final
  create private .

public section.

  class-methods CLASS_CONSTRUCTOR .
  class-methods GET_INSTANCE
    importing
      !IV_REPID type SY-REPID
    returning
      value(RO_INSTANCE) type ref to ZCL_HARDCODE_SHM
    raising
      ZCX_HARDCODE_SHM .
  methods HARDCODE_GET
    importing
      !IV_VERSION_PRIMARY_ONLY type XSDBOOLEAN
    returning
      value(RT_HARDCODE) type ZCL_HARDCODE=>TT_HARDCODE
    raising
      ZCX_HARDCODE_SHM .
  methods HARDCODE_RELOAD
    importing
      !IV_ONLY_THIS_AS type XSDBOOLEAN default ABAP_FALSE .
  methods HARDCODE_FINISH
    raising
      ZCX_HARDCODE_SHM .
  class-methods HARDCODE_UNLOAD
    importing
      !IV_REPID type SY-REPID
    raising
      ZCX_HARDCODE_SHM .
  class-methods HARDCODE_IS_LOAD
    importing
      !IV_REPID type SY-REPID
    returning
      value(RV_IN_SHM) type XSDBOOLEAN .
  methods HARDCODE_VALIDITY_CHECK
    returning
      value(RV_VALID) type XSDBOOLEAN .
protected section.
private section.

  types:
    BEGIN OF ts_instance,
      repid    TYPE sy-repid,
      instance TYPE REF TO zcl_hardcode_shm,
    END OF   ts_instance .
  types:
    tt_instance TYPE SORTED TABLE OF ts_instance
          WITH UNIQUE KEY primary_key COMPONENTS repid .
  types:
    BEGIN OF ts_persistent_data,
      t_instance TYPE zcl_hardcode_shm=>tt_instance,
      t_server_list TYPE msxxlist_t,
    END OF   ts_persistent_data .

  class-data MS_PERSISTENT_DATA type TS_PERSISTENT_DATA .
  data MV_KEY type SY-REPID .
  data MO_ATTACH_READ type ref to ZCL_HARDCODE_SHM_AREA .

  methods _HARDCODE_RELOAD .
  methods CONSTRUCTOR
    importing
      !IV_REPID type CLIKE
    raising
      ZCX_HARDCODE_SHM .
  class-methods __RAISE_EXCEPTION
    importing
      !IO_PREVIOUS type ref to CX_ROOT optional
      !IV_MSGID type SY-MSGID optional
      !IV_MSGNO type SY-MSGNO optional
      !IV_MSGV1 type ANY optional
      !IV_MSGV2 type ANY optional
      !IV_MSGV3 type ANY optional
      !IV_MSGV4 type ANY optional
    preferred parameter IO_PREVIOUS
    raising
      ZCX_HARDCODE_SHM .
  methods _RELOAD
    raising
      ZCX_HARDCODE_SHM .
ENDCLASS.



CLASS ZCL_HARDCODE_SHM IMPLEMENTATION.


METHOD class_constructor.
*&---------------------------------------------------------------------*
*& Méthode         : CLASS_CONSTRUCTOR                                 *
*& Classe          : ZCL_HARDCODE_SHM                                  *
*& Description     : Constructeur Statique                             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  IF zcl_hardcode_shm=>ms_persistent_data-t_server_list[] IS INITIAL.
    " -----------------------------------------------------------
    " Récupération Liste des Serveurs
    " -----------------------------------------------------------

    " Récupération de la Liste des Serveurs
    CALL FUNCTION 'TH_SERVER_LIST'
      TABLES
        list           = zcl_hardcode_shm=>ms_persistent_data-t_server_list
      EXCEPTIONS
        no_server_list = 1
        OTHERS         = 2.

  ENDIF.

ENDMETHOD.


METHOD constructor.
*&---------------------------------------------------------------------*
*& Copyright © 13/01/2016, Olivier Véhier                              *
*&                                                                     *
*& Permission is hereby granted, free of charge, to any person         *
*& obtaining a copy of this software and associated documentation      *
*& files (the "Software"), to deal in the Software without restriction *
*& including without limitation the rights to use, copy, modify,       *
*& merge, publish, distribute, sublicense, and/or sell copies of the   *
*& Software, and to permit persons to whom the Software is furnished   *
*& to do so, subject to the following conditions:                      *
*&                                                                     *
*& The above copyright notice and this permission notice shall be      *
*& included in all copies or substantial portions of the Software.     *
*&                                                                     *
*& THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,     *
*& EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES     *
*& OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND            *
*& NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS *
*& BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN  *
*& ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN   *
*& CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE    *
*& SOFTWARE.                                                           *
*&                                                                     *
*& Except as contained in this notice, the name of Olivier Véhier      *
*& shall not be used in advertising or otherwise to promote the sale,  *
*& use or other dealings in this Software without prior written        *
*& authorization from Olivier Véhier.                                  *
*&---------------------------------------------------------------------*
*& Méthode         : CONSTRUCTOR                                       *
*& Classe          : ZCL_HARDCODE_SHM                                  *
*& Description     : Constructeur                                      *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_cx_exception  TYPE REF TO cx_root,
    lo_attach_write  TYPE REF TO zcl_hardcode_shm_area,
    lo_hardcode_root TYPE REF TO zcl_hardcode_shm_root.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
        lv_retry_count TYPE i.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Récupération version courante
      " -----------------------------------------------------------

      " Initialisation Attribut
      me->mv_key = |{ sy-mandt }{ iv_repid }|.

      " Lecture de la version courante
      me->mo_attach_read = zcl_hardcode_shm_area=>attach_for_read( CONV shm_inst_name( me->mv_key ) ).

    CATCH cx_shm_no_active_version INTO lo_cx_exception.
      " Aucune version existante
      TRY.
          ""  --> Création instance d'écriture
          lo_attach_write = zcl_hardcode_shm_area=>attach_for_write( CONV shm_inst_name( me->mv_key  ) ).

          ""  --> Création d'une nouvelle version
          CREATE OBJECT lo_hardcode_root AREA HANDLE lo_attach_write
            EXPORTING
              iv_repid = iv_repid.

          ""  --> Initialisation de la version
          lo_attach_write->set_root( lo_hardcode_root ).

          ""  --> Sauvegarde la version
          lo_attach_write->detach_commit( ).

          ""  --> Récupère l'instance de lecture
          me->mo_attach_read = zcl_hardcode_shm_area=>attach_for_read( CONV shm_inst_name( me->mv_key ) ).

        CATCH cx_root INTO lo_cx_exception.
          " Une erreur est survenue
          ""  --> Lève l'exception
          me->__raise_exception( lo_cx_exception ).

      ENDTRY.

    CATCH cx_shm_inconsistent INTO lo_cx_exception.
      " Mauvaise gestion version
      TRY.
          ""  --> Réinitialisation Instance lecture
          CLEAR : me->mo_attach_read.

          ""  --> Invalide l'instance
          zcl_hardcode_shm_area=>invalidate_instance( CONV shm_inst_name( me->mv_key ) ).

          ""  --> Suppression de l'Instance
          zcl_hardcode_shm_area=>free_instance( CONV shm_inst_name( me->mv_key ) ).

        CATCH cx_shm_parameter_error.

      ENDTRY.

      IF lv_retry_count GT 1.
        " Le traitement a déjà été relancé
        ""  --> Lève une Exception
        me->__raise_exception( lo_cx_exception ).

      ENDIF.

      ""  --> Relance traitement
      ADD 1 TO lv_retry_count.
      RETRY.

    CATCH cx_root INTO lo_cx_exception.
      " Erreur lors de la récupération du Token de Lecture
      ""  --> Lève l'exception
      me->__raise_exception( lo_cx_exception ).

  ENDTRY.

ENDMETHOD.


METHOD get_instance.
*&---------------------------------------------------------------------*
*& Méthode         : GET_INSTANCE                                      *
*& Classe          : ZCL_HARDCODE_SHM                                  *
*& Description     : Récupération Instance                             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        lo_cx_exception TYPE REF TO cx_root.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  TRY.

      " -----------------------------------------------------------
      " Retourne l'Instance
      " -----------------------------------------------------------

      ro_instance = zcl_hardcode_shm=>ms_persistent_data-t_instance[ repid = iv_repid ]-instance.
      IF NOT ro_instance->mo_attach_read IS BOUND
      OR ro_instance->hardcode_validity_check( ) EQ abap_false.
        " Instance ne pointant pas sur la dernière version
        ro_instance->_reload( ).

      ENDIF.

    CATCH cx_sy_itab_line_not_found.
      " Aucune correspondance
      TRY.
          " -----------------------------------------------------------
          " Création d'une nouvelle entrée
          " -----------------------------------------------------------

          ""  --> Génération de l'Instance
          CREATE OBJECT ro_instance
            EXPORTING
              iv_repid = iv_repid.

          ""  --> Création de l'entrée
          INSERT VALUE #(
            repid    = iv_repid
            instance = ro_instance
          ) INTO TABLE zcl_hardcode_shm=>ms_persistent_data-t_instance.

        CATCH zcx_hardcode_shm INTO lo_cx_exception.
          " Une erreur est survenue
          ""  --> Lève l'Exception
          zcl_hardcode_shm=>__raise_exception( lo_cx_exception ).

      ENDTRY.

  ENDTRY.

ENDMETHOD.


METHOD hardcode_finish.
*&---------------------------------------------------------------------*
*& Méthode         : HARDCODE_FINISH                                   *
*& Classe          : ZCL_HARDCODE_SHM                                  *
*& Description     : Libération des Tokens                             *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***
*
  TRY.
      " -----------------------------------------------------------
      " Libération des Tokens sur l'Instance
      " -----------------------------------------------------------

      me->mo_attach_read->detach( ).

    CATCH cx_shm_already_detached.
      " Token lecture déjà libéré

  ENDTRY.

ENDMETHOD.


METHOD hardcode_get.
*&---------------------------------------------------------------------*
*& Méthode         : CONSTRUCTOR                                       *
*& Classe          : ZCL_HARDCODE_SHM                                  *
*& Description     : Récupération Hardcode depuis la SHM               *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_cx_exception TYPE REF TO cx_root.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  TRY.
      IF me->hardcode_validity_check( ) EQ abap_false.
        " Token de Lecture invalide
        ""  --> Libère Token de Lecture
        me->hardcode_finish( ).

        ""  --> Récupération nouvelle version
        me->mo_attach_read = zcl_hardcode_shm_area=>attach_for_read( CONV shm_inst_name( me->mv_key ) ).

      ENDIF.

      " Retourne les Hardcodes
      rt_hardcode = me->mo_attach_read->root->hardcode_get( iv_version_primary_only ).

    CATCH cx_root INTO lo_cx_exception.
      " Une erreur est survenue
      me->__raise_exception( lo_cx_exception ).

  ENDTRY.

ENDMETHOD.


METHOD hardcode_is_load.
*&---------------------------------------------------------------------*
*& Méthode         : HARDCODE_IS_LOAD                                  *
*& Classe          : ZCL_HARDCODE_SHM                                  *
*& Description     : Hardcode chargé en SHM ?                          *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle présence des Hardcodes en SHM
  " -----------------------------------------------------------

  " Retourne Indicateur Vrai si les Informations d'Instance sont non vides
  rv_in_shm = xsdbool( NOT zcl_hardcode_shm_area=>get_instance_infos(
      |{ sy-mandt }{ iv_repid }| ) IS INITIAL ).

ENDMETHOD.


METHOD hardcode_reload.
*&---------------------------------------------------------------------*
*& Méthode         : HARDCODE_RELOAD                                   *
*& Classe          : ZCL_HARDCODE_SHM                                  *
*& Description     : Recharge Hardcode dans la SHM                     *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  IF iv_only_this_as EQ abap_true
  OR lines( zcl_hardcode_shm=>ms_persistent_data-t_server_list ) LE 1.
    " Uniquement sur cet AS ou 1 seul As
    ""  --> Recharge les Hardcodes sur cet AS
    me->_hardcode_reload( ).

  ELSE.
    " Tous les AS
    ""  --> Recharge les Hardcodes sur tous les AS
    LOOP AT zcl_hardcode_shm=>ms_persistent_data-t_server_list ASSIGNING FIELD-SYMBOL(<lfs_s_server_list>).

      TRY.
          " Recharge les Hardcodes sur l'AS spécifié
          CALL FUNCTION 'Z_HC_SHM_RELOAD'
            DESTINATION <lfs_s_server_list>-name
            EXPORTING
              iv_repid = CONV repid( me->mv_key+3 ). "On se positionne après le mandant

        CATCH cx_root.

      ENDTRY.

    ENDLOOP.

  ENDIF.

ENDMETHOD.


METHOD hardcode_unload.
*&---------------------------------------------------------------------*
*& Méthode         : HARDCODE_UNLOAD                                   *
*& Classe          : ZCL_HARDCODE_SHM                                  *
*& Description     : Suppression Hardcode de la SHM                    *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Libération de l'Instance
      " -----------------------------------------------------------

      zcl_hardcode_shm_area=>invalidate_instance(
          inst_name         = CONV shm_inst_name( |{ sy-mandt }{ iv_repid }| )
          terminate_changer = abap_true
      ).

    CATCH cx_root INTO DATA(lo_cx_exception).
      " Erreur suppression de l'Instance
      zcl_hardcode_shm=>__raise_exception( lo_cx_exception ).

  ENDTRY.

ENDMETHOD.


METHOD hardcode_validity_check.
*&---------------------------------------------------------------------*
*& Méthode         : HARDCODE_VALIDITY_CHECK                           *
*& Classe          : ZCL_HARDCODE_SHM                                  *
*& Description     : Hardcode Valide ?                                 *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle validité de l'instance SHM
  " -----------------------------------------------------------

  IF NOT me->mo_attach_read IS BOUND
  OR me->mo_attach_read->is_valid( ) EQ abap_false
  OR me->mo_attach_read->is_active_version( ) EQ abap_false.
    " Instance SHM non valide
    rv_valid = abap_false.

  ELSE.
    " Instance SHM valide
    rv_valid = abap_true.

  ENDIF.

ENDMETHOD.


METHOD _hardcode_reload.
*&---------------------------------------------------------------------*
*& Méthode         : _HARDCODE_RELOAD                                  *
*& Classe          : ZCL_HARDCODE_SHM                                  *
*& Description     : Usage Interne : Recharge Hardcode dans la SHM     *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_cx_exception  TYPE REF TO cx_root,
    lo_attach_write  TYPE REF TO zcl_hardcode_shm_area,
    lo_hardcode_root TYPE REF TO zcl_hardcode_shm_root.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  IF me->mo_attach_read IS BOUND.
    TRY.
        " -----------------------------------------------------------
        " Libère le Token de Lecture courant
        " -----------------------------------------------------------

        " Libération Token de Lecture
        me->hardcode_finish( ).

      CATCH zcx_hardcode_shm.
        " Erreur survenue

    ENDTRY.

  ENDIF.

  " -----------------------------------------------------------
  " Modification des Hardcodes dans la SHM
  " -----------------------------------------------------------

  " Création instance d'écriture
  lo_attach_write = zcl_hardcode_shm_area=>attach_for_write( CONV shm_inst_name( me->mv_key ) ).

  " Création d'une nouvelle version
  CREATE OBJECT lo_hardcode_root AREA HANDLE lo_attach_write
    EXPORTING
      iv_repid = me->mv_key+3. "On se positionne après le mandant

  " Initialisation de la version
  lo_attach_write->set_root( lo_hardcode_root ).

  " Sauvegarde la version
  lo_attach_write->detach_commit( ).

  " Récupère l'instance de lecture
  me->mo_attach_read = zcl_hardcode_shm_area=>attach_for_read( CONV shm_inst_name( me->mv_key ) ).

ENDMETHOD.


METHOD _reload.
*&---------------------------------------------------------------------*
*& Méthode         : _RELOAD                                           *
*& Classe          : ZCL_HARDCODE_SHM                                  *
*& Description     : Recharge Token Instance SHM                       *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *
***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        lo_cx_exception TYPE REF TO cx_root.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
        lv_create TYPE xsdboolean.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  TRY.

      IF NOT me->mo_attach_read IS BOUND
      OR me->hardcode_validity_check( ) EQ abap_false.

        IF NOT me->mo_attach_read IS BOUND.
          " Aucune Instance de Lecture
          TRY.
              ""  --> Récupération Token de Lecture
              me->mo_attach_read = zcl_hardcode_shm_area=>attach_for_read( ).
              lv_create = xsdbool( NOT me->mo_attach_read->get_root( ) IS BOUND ).

            CATCH cx_root.                               "#EC CATCH_ALL
              " Erreur récupération Token Lecture ou pas d'entité Root défini
              ""  --> Initialisation indicateur création
              lv_create = abap_true.

          ENDTRY.

        ELSEIF me->mo_attach_read->is_valid( )          EQ abap_false
            OR me->mo_attach_read->is_active_version( ) EQ abap_false.
          " Instance existante mais sans canal de lecture ou pas dans la version active
          TRY.
              ""  --> Libère les Tokens existant sur cette version
              me->mo_attach_read->detach( ).

            CATCH cx_root.                "#EC CATCH_ALL #EC NO_HANDLER
              " Erreur libération Token Lecture

          ENDTRY.

          TRY.
              ""  --> Récupération Token de Lecture Valide
              me->mo_attach_read = zcl_hardcode_shm_area=>attach_for_read( ).
              lv_create = xsdbool( NOT me->mo_attach_read->get_root( ) IS BOUND ).

            CATCH cx_root.                               "#EC CATCH_ALL
              " Erreur libération Token Lecture
              ""  --> Initialisation indicateur création
              lv_create = abap_true.

          ENDTRY.

        ENDIF.

        IF lv_create EQ abap_true.
          ""  --> Libération de l'instance
*          FREE : zcl_hardcode_shm=>mo_instance.

          ""  --> Création nouvelle instance
*          CREATE OBJECT zcl_hardcode_shm=>mo_instance.

        ENDIF.

      ENDIF.

    CATCH zcx_hardcode_shm INTO lo_cx_exception.
      " Une erreur est survenue
      ""  --> Lève l'Exception
      zcl_hardcode_shm=>__raise_exception( lo_cx_exception ).

  ENDTRY.

ENDMETHOD.


METHOD __raise_exception.
*&---------------------------------------------------------------------*
*& Méthode         : __RAISE_EXCEPTION                                 *
*& Classe          : ZCL_HARDCODE_SHM                                  *
*& Description     : Usage Interne : Lève une Exception                *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_text_id TYPE scx_t100key.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Génération de l'Exception
  " -----------------------------------------------------------

  IF io_previous IS BOUND.
    " Lève l'exception
    RAISE EXCEPTION TYPE zcx_hardcode_shm
      EXPORTING
        previous = io_previous.

  ELSE.
    " Initialisation structure
    ls_text_id-msgid = iv_msgid.
    ls_text_id-msgno = iv_msgno.
    ls_text_id-attr1 = iv_msgv1.
    ls_text_id-attr2 = iv_msgv2.
    ls_text_id-attr3 = iv_msgv3.
    ls_text_id-attr4 = iv_msgv4.

    " Lève l'exception
    RAISE EXCEPTION TYPE zcx_hardcode_shm
      EXPORTING
        textid = ls_text_id.

  ENDIF.

ENDMETHOD.
ENDCLASS.
